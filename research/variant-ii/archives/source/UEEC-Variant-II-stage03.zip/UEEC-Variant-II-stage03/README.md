# UEEC — Variant II (stages 00–03)

Research workspace, not a released product version. The source of the migrated information utility is the existing Variant I implementation. Stage 00 is retained unchanged from the preceding package.

## Research rationale — Variant II

During experimental development of Variant I, a structural ambiguity was identified: the section-header format was stored per node, while physical sections can be shared by multiple nodes. Nodes declaring different formats could therefore disagree on the interpretation of the same section header. Variant II moves the 16-bit format field to the global header, increasing its size from 8 to 10 bytes and reducing the node header from 6 to 4 bytes. The three-byte magic and remaining structure layouts are retained. The global endian indicator governs decoding of multibyte header fields. The wire discriminator 2 distinguishes incompatible layouts; it is not a released product version. Variant I and its research results remain unchanged.

## Commands

From the root or any included stage directory: `make`, `make all`, `make build`, `make test`, `make sanitize`, `make clean`, `make help`, or `make x86_64` (any architecture from `mk/architectures.mk`). Root commands cover all four included stages. Cross-compilers and QEMU are required; missing dependencies fail the test. Sanitizers run on native x86-64 only.

Stage 01 uses Python 3 to generate deterministic UEEC fixtures from the shared binary resources. The optional NASM example is retained but is not used by the automated test and was not assembled here. See `01_ueec_info/README.md`.

## Validation and scope

User logs confirm stages 00–02 pass on all twelve architecture targets (204 information cases and 1212 loader cases). GCC 14.3 with Binutils 2.46 emitted four LoongArch64 assembler warnings in stages 01–02. The user's clean GCC 15.2 retest passed all three LoongArch64 targets without warnings; the common toolchain now selects GCC 15. No C workaround or warning suppression was applied.

Stage 03 migrates the existing SECTION_FLAT relocation example to the Variant II global SH16 header. The generator builds one container containing 12 nodes, 36 node-section references and 26 sections, including one shared data section. Native x86-64 tests verify structure and execute monolithic and scattered modes; optimized and ASan/UBSan runs passed. Cross execution of stage 03 is pending. This stage is intentionally limited to the original SH16 / little-endian container / SECTION_FLAT fixture, with architecture-specific code encoding; further widths, container byte orders and relocation designs are not covered by this checkpoint. Sanitizer leak detection is disabled for the legacy stage; tests are not exhaustive security validation. No GitHub changes. Stages 04 onward and import are not included.
