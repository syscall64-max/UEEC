# UEEC — Variant II (stages 00–01)

Research workspace, not a released product version. The source of the migrated information utility is the existing Variant I implementation. Stage 00 is retained unchanged from the preceding package.

## Research rationale — Variant II

During experimental development of Variant I, a structural ambiguity was identified: the section-header format was stored per node, while physical sections can be shared by multiple nodes. Nodes declaring different formats could therefore disagree on the interpretation of the same section header. Variant II moves the 16-bit format field to the global header, increasing its size from 8 to 10 bytes and reducing the node header from 6 to 4 bytes. The three-byte magic and remaining structure layouts are retained. The global endian indicator governs decoding of multibyte header fields. The wire discriminator 2 distinguishes incompatible layouts; it is not a released product version. Variant I and its research results remain unchanged.

## Commands

From the root or either stage directory: `make`, `make all`, `make build`, `make test`, `make sanitize`, `make clean`, `make help`, or `make x86_64` (any architecture from `mk/architectures.mk`). Root commands cover both included stages. Cross-compilers and QEMU are required; missing dependencies fail the test. Sanitizers run on native x86-64 only.

Stage 01 uses Python 3 to generate deterministic UEEC fixtures from the shared binary resources. The optional NASM example is retained but is not used by the automated test and was not assembled here. See `01_ueec_info/README.md`.

## Validation and scope

Stage 00: user supplied a successful 12/12 architecture test transcript (native x86-64 and 11 QEMU runs, no skipped or failed targets). Stage 01: native x86-64 passed all 17 cases in optimized and ASan/UBSan builds. Six ordinary and six shared-section fixtures cover SH16/32/64 and both metadata byte orders. Five invalid fixtures must be rejected. Cross-execution of stage 01 remains pending; the current environment lacks cross tools. No GitHub changes. Stages 02 onward and import are not included in this checkpoint. Tests are not exhaustive security validation.
