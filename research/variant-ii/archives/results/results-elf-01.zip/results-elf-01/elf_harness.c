#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
extern unsigned char slots[],payload[];
extern int payload_entry(const void *);
int main(void) {
 int result=payload_entry(slots); if(result!=40) return 1;
 unsigned long sum=0; const char *access=getenv("UEEC_FULL_ACCESS");
 if(access && access[0]=='1') { volatile const unsigned char *p=payload; for(size_t k=1;k<64UL*1024*1024;k+=4096) sum+=p[k]; if(sum!=16384) return 2; }
 for(size_t i=0;i<100000;i++){uintptr_t p; memcpy(&p,slots+(i?800096+8*(i-1):32),8); if(p!=(uintptr_t)slots+40) return 3;}
 for(size_t j=4;j<10000;j++){uintptr_t p; int v; memcpy(&p,slots+96+8*(j-4),8); if(!p) return 4; memcpy(&v,(void*)p,4); if(v!=(int)j) return 5;}
 printf("PAGE_SUM=%lu\nPROGRAM_RESULT=%d\n",sum,result); return 0;
}