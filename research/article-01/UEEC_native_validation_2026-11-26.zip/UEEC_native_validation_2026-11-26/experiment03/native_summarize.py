import pandas as pd
x=pd.read_csv('native_results.csv')
y=x[x.repeat>0].groupby(['scenario','n','design','hit']).agg(bytes=('bytes','first'),width=('width','first'),ns=('mean_ns','median'),comparisons=('mean_comparisons','mean')).reset_index()
y.to_csv('native_summary.csv',index=False)
