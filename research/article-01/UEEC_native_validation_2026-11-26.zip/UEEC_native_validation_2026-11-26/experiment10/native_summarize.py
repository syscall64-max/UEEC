import pandas as pd
import numpy as np
out=[]
keys=['count','stride','page','width','endian','mixed']
for level in ['O2','O3']:
 d=pd.read_csv('native_'+level+'.csv'); d=d[d.repeat>0]; g=d.groupby(keys+['variant']).ns_per_reloc.agg(['median','mean','std','size']).reset_index(); g['ci95_mean_halfwidth']=1.984*g['std']/np.sqrt(g['size']); g['optimization']=level; out.append(g)
 p=g.pivot(index=keys,columns='variant',values='median'); print(level,'configs',len(p)); print('ratios',[(i,round((p[0]/p[i]).median(),4),int((p[i]<p[0]).sum())) for i in range(1,4)]); print(p.loc[(1024,512,slice(None),slice(None),0,0)].to_string()); print('endian-specific ratios',[(en,i,round((q[0]/q[i]).median(),4)) for en,q in p.groupby(level='endian') for i in range(1,4)])
pd.concat(out).to_csv('native_summary.csv',index=False)
