	.file	"bench.c"
# GNU C23 (Ubuntu 15.2.0-16ubuntu1) version 15.2.0 (x86_64-linux-gnu)
#	compiled by GNU C version 15.2.0, GMP version 6.3.0, MPFR version 4.2.2, MPC version 1.3.1, isl version isl-0.27-GMP

# GGC heuristics: --param ggc-min-expand=100 --param ggc-min-heapsize=131072
# options passed: -D_FORTIFY_SOURCE=3 -mtune=generic -march=x86-64 -O2 -fasynchronous-unwind-tables -fstack-protector-strong -fstack-clash-protection -fcf-protection -fzero-init-padding-bits=all
	.text
	.section	.rodata.str1.1,"aMS",@progbits,1
.LC0:
	.string	"ABS64"
.LC1:
	.string	"ABS32"
	.section	.rodata.str1.8,"aMS",@progbits,1
	.align 8
.LC2:
	.string	"  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n"
	.text
	.p2align 4
	.type	apply_reloc, @function
apply_reloc:
.LFB57:
	.cfi_startproc
# loader.c:55:     void *target_addr = (uint8_t *)local_base[target] + patch_offset;
	movslq	%esi, %rax	# target, _1
# loader.c:56:     unsigned long source_base = (unsigned long)local_base[source];
	movslq	%edx, %r10	# source, _5
# loader.c:55:     void *target_addr = (uint8_t *)local_base[target] + patch_offset;
	movq	(%rdi,%rax,8), %r11	# *_3, target_addr
# loader.c:56:     unsigned long source_base = (unsigned long)local_base[source];
	movq	(%rdi,%r10,8), %rdi	# *_7, source_base
# loader.c:55:     void *target_addr = (uint8_t *)local_base[target] + patch_offset;
	addq	%rcx, %r11	# patch_offset, target_addr
# loader.c:57:     if (type == 1) { // ABS64
	cmpl	$1, %r8d	#, type
	je	.L11	#,
# loader.c:63:         uint32_t patched = (uint32_t)(source_base + addend);
	addl	%edi, (%r11)	# source_base, MEM <unsigned int> [(char * {ref-all})target_addr_19]
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	testl	%r9d, %r9d	# trace
	je	.L1	#,
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	testl	%r8d, %r8d	# type
	jne	.L3	#,
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	leaq	.LC1(%rip), %r9	#, iftmp.36_12
.L5:
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:118:   return __printf_chk (__USE_FORTIFY_LEVEL - 1, __fmt, __va_arg_pack ());
	movl	%edx, %r8d	# source,
	movl	$2, %edi	#,
	movl	%esi, %edx	# target,
	xorl	%eax, %eax	#
	leaq	.LC2(%rip), %rsi	#,
	jmp	__printf_chk@PLT	#
	.p2align 4,,10
	.p2align 3
.L11:
# loader.c:59:         uint64_t patched = source_base + addend;
	addq	%rdi, (%r11)	# source_base, MEM <unsigned long> [(char * {ref-all})target_addr_19]
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	testl	%r9d, %r9d	# trace
	jne	.L3	#,
.L1:
# loader.c:68: }
	ret	
	.p2align 4,,10
	.p2align 3
.L3:
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	leaq	.LC0(%rip), %r9	#, iftmp.36_12
	jmp	.L5	#
	.cfi_endproc
.LFE57:
	.size	apply_reloc, .-apply_reloc
	.p2align 4
	.type	process_reloc_section, @function
process_reloc_section:
.LFB61:
	.cfi_startproc
# loader.c:97:     if (len < 8) return -1;
	cmpq	$7, %rsi	#, len
	jbe	.L83	#,
# loader.c:96:                                  void **base, const size_t *sizes, int n, int trace) {
	pushq	%r15	#
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	movq	%rsi, %r10	# len, len
	movq	%rcx, %r11	# base, base
	pushq	%r14	#
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13	#
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12	#
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp	#
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	movl	%edx, %ebp	# endian, endian
	pushq	%rbx	#
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$56, %rsp	#,
	.cfi_def_cfa_offset 112
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movzwl	(%rdi), %edx	# MEM <unsigned short> [(char * {ref-all})rp_37(D)], _74
	movzwl	6(%rdi), %r13d	# MEM <unsigned short> [(char * {ref-all})rp_37(D) + 6B],
	movzwl	2(%rdi), %eax	# MEM <unsigned short> [(char * {ref-all})rp_37(D) + 2B],
	movzwl	4(%rdi), %ebx	# MEM <unsigned short> [(char * {ref-all})rp_37(D) + 4B], _66
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	testl	%ebp, %ebp	# endian
	jne	.L84	#,
.L16:
	movl	%ebx, %r15d	# _66, _85
# loader.c:100:     int target = couple & 31, source = (couple >> 5) & 31;
	movl	%ebx, %r12d	# _66, target
# loader.c:100:     int target = couple & 31, source = (couple >> 5) & 31;
	shrl	$5, %ebx	#, _3
# loader.c:100:     int target = couple & 31, source = (couple >> 5) & 31;
	andl	$31, %r12d	#, target
# loader.c:100:     int target = couple & 31, source = (couple >> 5) & 31;
	andl	$31, %ebx	#, source
	andl	$31, %r15d	#, _85
# loader.c:101:     if (target >= n || source >= n) return -1;
	movl	%ebx, %esi	# source, _83
	cmpl	%ebx, %r12d	# source, target
	cmovge	%r12d, %esi	# target,, _83
	cmpl	%esi, %r9d	# _83, n
	jle	.L26	#,
	movq	%r11, %rsi	# base, base
# loader.c:99:     unsigned couple = rd16(rp+4, endian), count = rd16(rp+6, endian);
	movzwl	%r13w, %ecx	# _40, count
# loader.c:102:     rp += 8; len -= 8;
	leaq	-8(%r10), %r11	#, len
# loader.c:103:     if (design == 0) {
	testl	%eax, %eax	# design
	jne	.L18	#,
# loader.c:104:         if (format != 0 || count > len/2) return -1;
	testw	%dx, %dx	# _74
	jne	.L26	#,
# loader.c:104:         if (format != 0 || count > len/2) return -1;
	movq	%r11, %rax	# len, len
	shrq	%rax	# len
# loader.c:104:         if (format != 0 || count > len/2) return -1;
	cmpq	%r13, %rax	# _5, _6
	jb	.L26	#,
# loader.c:105:         for (unsigned e = 0; e < count; ++e) {
	testl	%ecx, %ecx	# count
	je	.L23	#,
# loader.c:109:             if (type > 1 || offset > sizes[target] || bytes > sizes[target]-offset) return -1;
	movzwl	%r15w, %r15d	# _85, _12
	leal	-1(%rcx), %eax	#, _275
	movl	%ebx, (%rsp)	# source, %sfp
	leaq	8(%rdi), %rbx	#, ivtmp.88
	leaq	(%r8,%r15,8), %r13	#, _14
	leaq	10(%rdi,%rax,2), %r14	#, _271
	movq	%rsi, %r15	# base, base
	jmp	.L22	#
	.p2align 4,,10
	.p2align 3
.L85:
# loader.c:109:             if (type > 1 || offset > sizes[target] || bytes > sizes[target]-offset) return -1;
	ja	.L26	#,
# loader.c:109:             if (type > 1 || offset > sizes[target] || bytes > sizes[target]-offset) return -1;
	movq	0(%r13), %rdx	# *_14, _15
# loader.c:107:             size_t offset = v & 0xFFF; unsigned type = v >> 12;
	andl	$4095, %ecx	#, offset
	movl	$4, %esi	#, bytes
# loader.c:109:             if (type > 1 || offset > sizes[target] || bytes > sizes[target]-offset) return -1;
	cmpq	%rcx, %rdx	# offset, _15
	jb	.L26	#,
.L86:
# loader.c:109:             if (type > 1 || offset > sizes[target] || bytes > sizes[target]-offset) return -1;
	subq	%rcx, %rdx	# offset, _16
# loader.c:109:             if (type > 1 || offset > sizes[target] || bytes > sizes[target]-offset) return -1;
	cmpq	%rsi, %rdx	# bytes, _16
	jb	.L26	#,
# loader.c:110:             apply_reloc(base, target, source, offset, type, trace);
	movl	112(%rsp), %r9d	# trace,
	movl	(%rsp), %edx	# %sfp,
	andl	$15, %r8d	#,
	movl	%r12d, %esi	# target,
	movq	%r15, %rdi	# base,
# loader.c:105:         for (unsigned e = 0; e < count; ++e) {
	addq	$2, %rbx	#, ivtmp.88
# loader.c:110:             apply_reloc(base, target, source, offset, type, trace);
	call	apply_reloc	#
# loader.c:105:         for (unsigned e = 0; e < count; ++e) {
	cmpq	%rbx, %r14	# ivtmp.88, _271
	je	.L23	#,
.L22:
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movzwl	(%rbx), %ecx	# MEM <unsigned short> [(char * {ref-all})_278], _77
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	movl	%ecx, %edx	# _77, tmp295
	rolw	$8, %dx	#, tmp295
	testl	%ebp, %ebp	# endian
	cmovne	%edx, %ecx	# tmp295,, _77
# loader.c:107:             size_t offset = v & 0xFFF; unsigned type = v >> 12;
	movl	%ecx, %r8d	# _77, _11
	shrw	$12, %r8w	#, _11
# loader.c:108:             size_t bytes = type == 1 ? 8 : 4;
	cmpw	$1, %r8w	#, _11
	jne	.L85	#,
# loader.c:109:             if (type > 1 || offset > sizes[target] || bytes > sizes[target]-offset) return -1;
	movq	0(%r13), %rdx	# *_14, _15
# loader.c:107:             size_t offset = v & 0xFFF; unsigned type = v >> 12;
	andl	$4095, %ecx	#, offset
# loader.c:108:             size_t bytes = type == 1 ? 8 : 4;
	movl	$8, %esi	#, bytes
# loader.c:109:             if (type > 1 || offset > sizes[target] || bytes > sizes[target]-offset) return -1;
	cmpq	%rcx, %rdx	# offset, _15
	jnb	.L86	#,
.L26:
# loader.c:121: }
	addq	$56, %rsp	#,
	.cfi_remember_state
	.cfi_def_cfa_offset 56
# loader.c:97:     if (len < 8) return -1;
	movl	$-1, %eax	#, <retval>
# loader.c:121: }
	popq	%rbx	#
	.cfi_def_cfa_offset 48
	popq	%rbp	#
	.cfi_def_cfa_offset 40
	popq	%r12	#
	.cfi_def_cfa_offset 32
	popq	%r13	#
	.cfi_def_cfa_offset 24
	popq	%r14	#
	.cfi_def_cfa_offset 16
	popq	%r15	#
	.cfi_def_cfa_offset 8
	ret	
	.p2align 4,,10
	.p2align 3
.L84:
	.cfi_restore_state
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	rolw	$8, %ax	#, _72
	movl	%r13d, %ecx	# _40, _40
	rolw	$8, %dx	#, _74
	rolw	$8, %cx	#, _40
# loader.c:98:     unsigned format = rd16(rp, endian), design = rd16(rp+2, endian);
	movzwl	%ax, %eax	# _72, design
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	rolw	$8, %bx	#, _66
	movzwl	%cx, %r13d	# _40,
	jmp	.L16	#
	.p2align 4,,10
	.p2align 3
.L18:
# loader.c:114:     if (design != 1 && design != 2) return -1;
	subl	$1, %eax	#, _18
# loader.c:114:     if (design != 1 && design != 2) return -1;
	cmpl	$1, %eax	#, _18
	ja	.L26	#,
# loader.c:102:     rp += 8; len -= 8;
	leaq	8(%rdi), %rax	#, rp
# loader.c:115:     switch (format) {
	cmpw	$1, %dx	#, _74
	je	.L24	#,
	cmpw	$2, %dx	#, _74
	je	.L25	#,
	testw	%dx, %dx	# _74
	jne	.L26	#,
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	testl	%ecx, %ecx	# count
	je	.L23	#,
# loader.c:116:         case 0: return process_blocks16(rp,len,endian,count,base,target,source,sizes[target],trace);
	movzwl	%r15w, %r15d	# _85, _19
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	movl	%r12d, 12(%rsp)	# target, %sfp
	xorl	%r10d, %r10d	# b
	movq	%rsi, %r14	# base, base
	movq	(%r8,%r15,8), %r13	# *_21, _22
	movl	%ecx, 44(%rsp)	# count, %sfp
	movq	%r11, %rcx	# len, len
	movl	%ebx, 40(%rsp)	# source, %sfp
	movl	%ebp, %ebx	# endian, endian
.L33:
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	cmpq	$3, %rcx	#, len
	jbe	.L26	#,
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movzwl	(%rax), %r11d	# MEM <unsigned short> [(char * {ref-all})p_226], _88
	movzwl	2(%rax), %esi	# MEM <unsigned short> [(char * {ref-all})p_226 + 2B],
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	movzwl	%r11w, %r12d	# _88, index
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	testl	%ebx, %ebx	# endian
	je	.L28	#,
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	movl	%r11d, %edx	# _88, _88
	rolw	$8, %dx	#, _88
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	movzwl	%dx, %r12d	# _88, index
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	movl	%esi, %edx	# _97, _97
	rolw	$8, %dx	#, _97
	movzwl	%dx, %esi	# _97,
.L28:
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	leaq	-4(%rcx), %r8	#, len
	movq	%r8, %r9	# len, _101
	shrq	%r9	# _101
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	cmpq	%rsi, %r9	# count, _101
	jb	.L26	#,
	cmpq	%r12, %r13	# index, _22
	jb	.L26	#,
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	testq	%rsi, %rsi	# count
	je	.L48	#,
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	xorl	%ebp, %ebp	# e
	movq	%r14, (%rsp)	# base, %sfp
	leaq	4(%rax), %r14	#, p
	movq	%rbp, %r15	# e, e
	movq	%rax, 16(%rsp)	# rp, %sfp
	movq	%r12, %rbp	# index, index
	movq	%rsi, %r12	# count, count
	movq	%rcx, 24(%rsp)	# len, %sfp
	movl	%r10d, 32(%rsp)	# b, %sfp
	jmp	.L32	#
	.p2align 4,,10
	.p2align 3
.L88:
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	ja	.L26	#,
	movl	$4, %esi	#, bytes
.L31:
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	movq	%r13, %rdx	# _22, _114
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	andl	$4095, %ecx	#, delta
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	subq	%rbp, %rdx	# index, _114
	cmpq	%rcx, %rdx	# delta, _114
	jb	.L26	#,
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	subq	%rcx, %rdx	# delta, _115
	cmpq	%rsi, %rdx	# bytes, _115
	jb	.L26	#,
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	movl	112(%rsp), %r9d	# trace,
	movl	40(%rsp), %edx	# %sfp,
	addq	%rbp, %rcx	# index, _118
	andl	$15, %r8d	#,
	movl	12(%rsp), %esi	# %sfp,
	movq	(%rsp), %rdi	# %sfp,
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	addq	$1, %r15	#, e
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	addq	$2, %r14	#, p
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	call	apply_reloc	#
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	cmpq	%r15, %r12	# e, count
	je	.L87	#,
.L32:
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movzwl	(%r14), %ecx	# MEM <unsigned short> [(char * {ref-all})p_227], _104
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	movl	%ecx, %edx	# _104, tmp297
	rolw	$8, %dx	#, tmp297
	testl	%ebx, %ebx	# endian
	cmovne	%edx, %ecx	# tmp297,, _104
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	movl	%ecx, %r8d	# _104, _113
	shrw	$12, %r8w	#, _113
	cmpw	$1, %r8w	#, _113
	jne	.L88	#,
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	movl	$8, %esi	#, bytes
	jmp	.L31	#
.L87:
	movq	%r14, %r15	# p, p
	movq	16(%rsp), %rax	# %sfp, rp
	addq	24(%rsp), %rax	# %sfp, _269
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	subq	%r15, %rax	# p, _269
	movl	32(%rsp), %r10d	# %sfp, b
	movq	(%rsp), %r14	# %sfp, base
	movq	%rax, %rcx	# _269, len
	movq	%r15, %rax	# p, rp
.L29:
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	addl	$1, %r10d	#, b
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	cmpl	%r10d, 44(%rsp)	# b, %sfp
	jne	.L33	#,
	.p2align 4
	.p2align 3
.L23:
# loader.c:112:         return 0;
	xorl	%eax, %eax	# <retval>
.L93:
# loader.c:121: }
	addq	$56, %rsp	#,
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx	#
	.cfi_def_cfa_offset 48
	popq	%rbp	#
	.cfi_def_cfa_offset 40
	popq	%r12	#
	.cfi_def_cfa_offset 32
	popq	%r13	#
	.cfi_def_cfa_offset 24
	popq	%r14	#
	.cfi_def_cfa_offset 16
	popq	%r15	#
	.cfi_def_cfa_offset 8
	ret	
	.p2align 4,,10
	.p2align 3
.L25:
	.cfi_restore_state
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	testl	%ecx, %ecx	# count
	je	.L23	#,
# loader.c:118:         case 2: return process_blocks64(rp,len,endian,count,base,target,source,sizes[target],trace);
	movzwl	%r15w, %r15d	# _85, _27
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	movl	$0, 16(%rsp)	#, %sfp
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	movq	%rsi, %r14	# base, base
# loader.c:118:         case 2: return process_blocks64(rp,len,endian,count,base,target,source,sizes[target],trace);
	movq	(%r8,%r15,8), %rdx	# *_29, _30
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	movl	%ecx, 44(%rsp)	# count, %sfp
	movl	%r12d, 12(%rsp)	# target, %sfp
	movl	%ebx, 40(%rsp)	# source, %sfp
	movq	%rdx, %r13	# _30, _30
	movl	%ebp, %ebx	# endian, endian
	movq	%rax, %rdx	# rp, rp
	movq	%r11, %rax	# len, len
.L46:
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	cmpq	$15, %rax	#, len
	jbe	.L26	#,
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movq	(%rdx), %r12	# MEM <unsigned long> [(char * {ref-all})p_242], _161
	movq	8(%rdx), %rdi	# MEM <unsigned long> [(char * {ref-all})p_242 + 8B], pretmp_56
# loader.c:51:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap64(v);
	testl	%ebx, %ebx	# endian
# loader.c:51:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap64(v);
	movq	%r12, %rsi	# _161, tmp306
	bswap	%rsi		# tmp306
	cmovne	%rsi, %r12	# _161,, tmp306, _161
	movq	%rdi, %rsi	# pretmp_56, tmp308
	bswap	%rsi		# tmp308
	cmovne	%rsi, %rdi	# pretmp_56,, tmp308, pretmp_56
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	leaq	-16(%rax), %rsi	#, len
	movq	%rsi, %r8	# len, _168
	shrq	$3, %r8	#, _168
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	cmpq	%rdi, %r8	# pretmp_56, _168
	jb	.L26	#,
	cmpq	%r12, %r13	# _161, _30
	jb	.L26	#,
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	testq	%rdi, %rdi	# pretmp_56
	je	.L52	#,
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	xorl	%ebp, %ebp	# e
	movq	%r14, (%rsp)	# base, %sfp
	leaq	16(%rdx), %r14	#, p
	movq	%rbp, %r15	# e, e
	movq	%rdx, 24(%rsp)	# rp, %sfp
	movq	%r12, %rbp	# _161, _161
	movq	%rdi, %r12	# pretmp_56, pretmp_56
	movq	%rax, 32(%rsp)	# len, %sfp
	jmp	.L45	#
	.p2align 4,,10
	.p2align 3
.L90:
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	ja	.L26	#,
	movl	$4, %esi	#, bytes
.L44:
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	movabsq	$1152921504606846975, %rax	#, tmp418
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	movq	%r13, %rdx	# _30, _180
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	andq	%rax, %rcx	# tmp418, delta
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	subq	%rbp, %rdx	# _161, _180
	cmpq	%rcx, %rdx	# delta, _180
	jb	.L26	#,
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	subq	%rcx, %rdx	# delta, _181
	cmpq	%rsi, %rdx	# bytes, _181
	jb	.L26	#,
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	movl	112(%rsp), %r9d	# trace,
	movl	40(%rsp), %edx	# %sfp,
	addq	%rbp, %rcx	# _161, _184
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	addq	$1, %r15	#, e
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	movl	12(%rsp), %esi	# %sfp,
	movq	(%rsp), %rdi	# %sfp,
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	addq	$8, %r14	#, p
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	call	apply_reloc	#
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	cmpq	%r15, %r12	# e, pretmp_56
	je	.L89	#,
.L45:
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movq	(%r14), %rcx	# MEM <unsigned long> [(char * {ref-all})p_243], _172
# loader.c:51:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap64(v);
	testl	%ebx, %ebx	# endian
	movq	%rcx, %rdx	# _172, tmp309
	bswap	%rdx		# tmp309
	cmovne	%rdx, %rcx	# tmp309,, _172
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	movq	%rcx, %r8	# _172, _179
	shrq	$60, %r8	#, _179
	cmpq	$1, %r8	#, _179
	jne	.L90	#,
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	movl	$8, %esi	#, bytes
	jmp	.L44	#
	.p2align 4,,10
	.p2align 3
.L24:
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	testl	%ecx, %ecx	# count
	je	.L23	#,
# loader.c:117:         case 1: return process_blocks32(rp,len,endian,count,base,target,source,sizes[target],trace);
	movzwl	%r15w, %r15d	# _85, _23
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	movl	%r12d, 12(%rsp)	# target, %sfp
	xorl	%edx, %edx	# b
	movq	%rsi, %r14	# base, base
	movq	(%r8,%r15,8), %r13	# *_25, _26
	movl	%ecx, 44(%rsp)	# count, %sfp
	movq	%r11, %rcx	# len, len
	movl	%ebx, 40(%rsp)	# source, %sfp
	movl	%ebp, %ebx	# endian, endian
.L40:
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	cmpq	$7, %rcx	#, len
	jbe	.L26	#,
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movl	(%rax), %r11d	# MEM <unsigned int> [(char * {ref-all})p_234], _126
	movl	4(%rax), %esi	# MEM <unsigned int> [(char * {ref-all})p_234 + 4B], _133
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	movl	%r11d, %r12d	# _126, index
# loader.c:47:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap32(v);
	testl	%ebx, %ebx	# endian
	je	.L35	#,
# loader.c:47:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap32(v);
	bswap	%r11d		# _129
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	movl	%r11d, %r12d	# _129, index
# loader.c:47:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap32(v);
	bswap	%esi		# _133
.L35:
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	leaq	-8(%rcx), %r8	#, len
	movl	%esi, %esi	# _133, count
	movq	%r8, %r9	# len, _137
	shrq	$2, %r9	#, _137
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	cmpq	%rsi, %r9	# count, _137
	jb	.L26	#,
	cmpq	%r12, %r13	# index, _26
	jb	.L26	#,
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	testq	%rsi, %rsi	# count
	je	.L50	#,
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	xorl	%ebp, %ebp	# e
	movq	%r14, (%rsp)	# base, %sfp
	leaq	8(%rax), %r14	#, p
	movq	%rbp, %r15	# e, e
	movq	%rax, 16(%rsp)	# rp, %sfp
	movq	%r12, %rbp	# index, index
	movq	%rsi, %r12	# count, count
	movq	%rcx, 24(%rsp)	# len, %sfp
	movl	%edx, 32(%rsp)	# b, %sfp
	jmp	.L39	#
	.p2align 4,,10
	.p2align 3
.L92:
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	ja	.L26	#,
	movl	$4, %esi	#, bytes
.L38:
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	movq	%r13, %rdx	# _26, _149
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	andl	$268435455, %ecx	#, delta
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	subq	%rbp, %rdx	# index, _149
	cmpq	%rcx, %rdx	# delta, _149
	jb	.L26	#,
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	subq	%rcx, %rdx	# delta, _150
	cmpq	%rsi, %rdx	# bytes, _150
	jb	.L26	#,
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	movl	112(%rsp), %r9d	# trace,
	movl	40(%rsp), %edx	# %sfp,
	addq	%rbp, %rcx	# index, _153
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	addq	$1, %r15	#, e
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	movl	12(%rsp), %esi	# %sfp,
	movq	(%rsp), %rdi	# %sfp,
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	addq	$4, %r14	#, p
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	call	apply_reloc	#
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	cmpq	%r15, %r12	# e, count
	je	.L91	#,
.L39:
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movl	(%r14), %ecx	# MEM <unsigned int> [(char * {ref-all})p_235], _140
# loader.c:47:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap32(v);
	testl	%ebx, %ebx	# endian
	movl	%ecx, %edx	# _140, tmp299
	bswap	%edx		# tmp299
	cmovne	%edx, %ecx	# tmp299,, _140
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	movl	%ecx, %r8d	# _140, type
	shrl	$28, %r8d	#, type
	cmpl	$1, %r8d	#, type
	jne	.L92	#,
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	movl	$8, %esi	#, bytes
	jmp	.L38	#
.L91:
	movq	%r14, %r15	# p, p
	movq	16(%rsp), %rax	# %sfp, rp
	addq	24(%rsp), %rax	# %sfp, _263
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	subq	%r15, %rax	# p, _263
	movl	32(%rsp), %edx	# %sfp, b
	movq	(%rsp), %r14	# %sfp, base
	movq	%rax, %rcx	# _263, len
	movq	%r15, %rax	# p, rp
.L36:
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	addl	$1, %edx	#, b
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	cmpl	%edx, 44(%rsp)	# b, %sfp
	jne	.L40	#,
# loader.c:112:         return 0;
	xorl	%eax, %eax	# <retval>
	jmp	.L93	#
	.p2align 4,,10
	.p2align 3
.L89:
	movq	%r14, %r15	# p, p
	movq	32(%rsp), %rax	# %sfp, len
	movq	(%rsp), %r14	# %sfp, base
	addq	24(%rsp), %rax	# %sfp, _81
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	movq	%r15, %rdx	# p, rp
	subq	%r15, %rax	# p, len
.L42:
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	addl	$1, 16(%rsp)	#, %sfp
	movl	16(%rsp), %edi	# %sfp, b
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	cmpl	%edi, 44(%rsp)	# b, %sfp
	jne	.L46	#,
# loader.c:112:         return 0;
	xorl	%eax, %eax	# <retval>
	jmp	.L93	#
.L50:
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	movq	%r8, %rcx	# len, len
	addq	$8, %rax	#, rp
	jmp	.L36	#
.L52:
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	movq	%rsi, %rax	# len, len
	addq	$16, %rdx	#, rp
	jmp	.L42	#
.L48:
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	movq	%r8, %rcx	# len, len
	addq	$4, %rax	#, rp
	jmp	.L29	#
.L83:
	.cfi_def_cfa_offset 8
	.cfi_restore 3
	.cfi_restore 6
	.cfi_restore 12
	.cfi_restore 13
	.cfi_restore 14
	.cfi_restore 15
# loader.c:97:     if (len < 8) return -1;
	movl	$-1, %eax	#, <retval>
# loader.c:121: }
	ret	
	.cfi_endproc
.LFE61:
	.size	process_reloc_section, .-process_reloc_section
	.p2align 4
	.type	generic.constprop.0, @function
generic.constprop.0:
.LFB68:
	.cfi_startproc
	movq	%rsi, %r9	# len, len
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	cmpq	$7, %rsi	#, len
	jbe	.L136	#,
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	pushq	%r15	#
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	movl	%edx, %esi	# en, en
	movq	%rcx, %r15	# base, base
	pushq	%r14	#
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13	#
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12	#
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp	#
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx	#
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$88, %rsp	#,
	.cfi_def_cfa_offset 144
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movzwl	(%rdi), %r13d	# MEM <unsigned short> [(char * {ref-all})p_2(D)],
	movzwl	2(%rdi), %edx	# MEM <unsigned short> [(char * {ref-all})p_2(D) + 2B],
	movzwl	6(%rdi), %ebx	# MEM <unsigned short> [(char * {ref-all})p_2(D) + 6B], _24
	movzwl	4(%rdi), %eax	# MEM <unsigned short> [(char * {ref-all})p_2(D) + 4B], _26
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	testl	%esi, %esi	# en
	jne	.L137	#,
.L98:
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movl	%eax, %r14d	# _26, _29
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movl	%eax, %ecx	# _26, target
	movl	%eax, %r11d	# _26, _27
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	shrl	$5, %r14d	#, _29
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	andl	$31, %ecx	#, target
	andl	$31, %r11d	#, _27
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movl	%r14d, %r10d	# _29, _29
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movl	%ecx, %eax	# target, _32
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movl	%ecx, 40(%rsp)	# target, %sfp
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	andl	$31, %r10d	#, _29
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	cmpl	%r10d, %ecx	# source, target
	cmovl	%r10d, %eax	# _32,, source, _32
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	cmpl	$1, %eax	#, _32
	jg	.L99	#,
	cmpl	$2, %r13d	#, fmt
	ja	.L99	#,
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	subl	$1, %edx	#, _35
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	cmpl	$1, %edx	#, _35
	ja	.L99	#,
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movzwl	%bx, %eax	# _24, blocks
	movl	%eax, 76(%rsp)	# blocks, %sfp
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	testl	%eax, %eax	# blocks
	je	.L119	#,
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movl	%r13d, %ecx	# fmt, tmp272
	movl	$2, %eax	#, tmp190
	movq	%r9, %rdx	# len, len
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movzwl	%r11w, %r11d	# _27, _41
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	sall	%cl, %eax	# tmp272, w
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movq	$-1, %r9	#, tmp194
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movq	(%r8,%r11,8), %r14	# *_44, target_size
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movl	%r13d, %ebp	# fmt, fmt
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	leal	-4(,%rax,8), %ebx	#, shift
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movl	%r10d, 44(%rsp)	# source, %sfp
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	leaq	-8(%rdx), %r8	#, len
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movl	%ebx, %ecx	# shift, tmp238
	movq	%r15, 32(%rsp)	# base, %sfp
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	leal	(%rax,%rax), %r11d	#, _49
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movq	%r14, %r12	# target_size, target_size
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	negl	%ecx	# tmp238
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movl	$0, 72(%rsp)	#, %sfp
	movl	%esi, %r15d	# en, en
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	shrq	%cl, %r9	# tmp238, tmp194
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movl	%ebx, 12(%rsp)	# shift, %sfp
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	leaq	8(%rdi), %rbx	#, p
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movq	%r9, 16(%rsp)	# tmp194, %sfp
.L118:
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	cmpq	%r11, %r8	# _49, len
	jb	.L99	#,
# bench.c:8: static uint64_t readw(const uint8_t *p,unsigned w,unsigned en){switch(w){case 2:return rd16(p,en);case 4:return rd32(p,en);default:return rd64(p,en);}}
	testl	%ebp, %ebp	# fmt
	je	.L101	#,
	cmpl	$1, %ebp	#, fmt
	jne	.L138	#,
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movl	(%rbx), %r14d	# MEM <unsigned int> [(char * {ref-all})p_54],
	movl	4(%rbx), %edi	# MEM <unsigned int> [(char * {ref-all})p_54 + 4B], _92
# loader.c:47:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap32(v);
	testl	%r15d, %r15d	# en
	je	.L107	#,
# loader.c:47:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap32(v);
	bswap	%r14d		# _122
# bench.c:8: static uint64_t readw(const uint8_t *p,unsigned w,unsigned en){switch(w){case 2:return rd16(p,en);case 4:return rd32(p,en);default:return rd64(p,en);}}
	movl	%r14d, %r14d	# _122, _140
# loader.c:47:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap32(v);
	bswap	%edi		# _92
.L107:
# bench.c:8: static uint64_t readw(const uint8_t *p,unsigned w,unsigned en){switch(w){case 2:return rd16(p,en);case 4:return rd32(p,en);default:return rd64(p,en);}}
	movl	%edi, %edi	# _92, _89
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movl	$4, %r9d	#, _136
.L108:
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	subq	%r11, %r8	# _49, len
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	xorl	%edx, %edx	# tmp203
	movq	%r8, %rax	# len, _58
	divq	%r9	# _136
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	cmpq	%rdi, %rax	# _89, _58
	jb	.L99	#,
	cmpq	%r14, %r12	# _140, target_size
	jb	.L99	#,
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	leaq	(%rbx,%r11), %rdx	#, p
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	testq	%rdi, %rdi	# _89
	je	.L121	#,
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movq	%r12, (%rsp)	# target_size, %sfp
	movq	%r14, %rbx	# _140, _140
	xorl	%r12d, %r12d	# e
	movq	%rdx, %r13	# p, p
	movq	%r8, 48(%rsp)	# len, %sfp
	movq	%rdi, %r14	# _89, _89
	movq	%r11, 56(%rsp)	# _49, %sfp
	movq	%rdx, 64(%rsp)	# p, %sfp
	movq	%r9, 24(%rsp)	# _136, %sfp
	jmp	.L117	#
	.p2align 4,,10
	.p2align 3
.L140:
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	ja	.L99	#,
	movl	$4, %esi	#, bytes
.L116:
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movq	(%rsp), %rcx	# %sfp, _67
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	andq	16(%rsp), %rdx	# %sfp, delta
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	subq	%rbx, %rcx	# _140, _67
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	cmpq	%rdx, %rcx	# delta, _67
	jb	.L99	#,
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	subq	%rdx, %rcx	# delta, _68
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	cmpq	%rsi, %rcx	# bytes, _68
	jb	.L99	#,
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	leaq	(%rdx,%rbx), %rcx	#, _71
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movl	40(%rsp), %esi	# %sfp,
	movl	44(%rsp), %edx	# %sfp,
	xorl	%r9d, %r9d	#
	movq	32(%rsp), %rdi	# %sfp,
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	addq	$1, %r12	#, e
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	addq	24(%rsp), %r13	# %sfp, p
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	call	apply_reloc	#
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	cmpq	%r14, %r12	# _89, e
	je	.L139	#,
.L117:
# bench.c:8: static uint64_t readw(const uint8_t *p,unsigned w,unsigned en){switch(w){case 2:return rd16(p,en);case 4:return rd32(p,en);default:return rd64(p,en);}}
	testl	%ebp, %ebp	# fmt
	je	.L110	#,
	cmpl	$1, %ebp	#, fmt
	je	.L111	#,
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movq	0(%r13), %rdx	# MEM <unsigned long> [(char * {ref-all})p_53], _113
# loader.c:51:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap64(v);
	testl	%r15d, %r15d	# en
	movq	%rdx, %rcx	# _113, tmp217
	bswap	%rcx		# tmp217
	cmovne	%rcx, %rdx	# tmp217,, _113
.L114:
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movzbl	12(%rsp), %ecx	# %sfp, tmp283
	movq	%rdx, %r8	# _113, _65
	shrq	%cl, %r8	# tmp283, _65
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	cmpl	$1, %r8d	#, _65
	jne	.L140	#,
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movl	$8, %esi	#, bytes
	jmp	.L116	#
	.p2align 4,,10
	.p2align 3
.L99:
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movl	$-1, %eax	#, <retval>
.L94:
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	addq	$88, %rsp	#,
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx	#
	.cfi_def_cfa_offset 48
	popq	%rbp	#
	.cfi_def_cfa_offset 40
	popq	%r12	#
	.cfi_def_cfa_offset 32
	popq	%r13	#
	.cfi_def_cfa_offset 24
	popq	%r14	#
	.cfi_def_cfa_offset 16
	popq	%r15	#
	.cfi_def_cfa_offset 8
	ret	
	.p2align 4,,10
	.p2align 3
.L137:
	.cfi_restore_state
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	rolw	$8, %dx	#, _12
	movl	%r13d, %ecx	# _3, _3
	rolw	$8, %ax	#, _26
	rolw	$8, %cx	#, _3
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movzwl	%dx, %edx	# _12, design
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	rolw	$8, %bx	#, _24
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movzwl	%cx, %r13d	# _3, fmt
	jmp	.L98	#
	.p2align 4,,10
	.p2align 3
.L138:
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movq	(%rbx), %r14	# MEM <unsigned long> [(char * {ref-all})p_54], _140
	movq	8(%rbx), %rdi	# MEM <unsigned long> [(char * {ref-all})p_54 + 8B], _89
# loader.c:51:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap64(v);
	testl	%r15d, %r15d	# en
	movl	$8, %r9d	#, _136
	movq	%r14, %rax	# _140, tmp226
	bswap	%rax		# tmp226
	cmovne	%rax, %r14	# _140,, tmp226, _140
	movq	%rdi, %rax	# _89, tmp228
	bswap	%rax		# tmp228
	cmovne	%rax, %rdi	# _89,, tmp228, _89
	jmp	.L108	#
	.p2align 4,,10
	.p2align 3
.L110:
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movzwl	0(%r13), %edx	# MEM <unsigned short> [(char * {ref-all})p_53], _109
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	movl	%edx, %ecx	# _109, tmp213
	rolw	$8, %cx	#, tmp213
	testl	%r15d, %r15d	# en
	cmovne	%ecx, %edx	# tmp213,, _109
# bench.c:8: static uint64_t readw(const uint8_t *p,unsigned w,unsigned en){switch(w){case 2:return rd16(p,en);case 4:return rd32(p,en);default:return rd64(p,en);}}
	movzwl	%dx, %edx	# _109, _113
# bench.c:8: static uint64_t readw(const uint8_t *p,unsigned w,unsigned en){switch(w){case 2:return rd16(p,en);case 4:return rd32(p,en);default:return rd64(p,en);}}
	jmp	.L114	#
	.p2align 4,,10
	.p2align 3
.L111:
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movl	0(%r13), %ecx	# MEM <unsigned int> [(char * {ref-all})p_53], _114
# loader.c:47:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap32(v);
	testl	%r15d, %r15d	# en
	movl	%ecx, %edx	# _114, tmp215
	bswap	%edx		# tmp215
# bench.c:8: static uint64_t readw(const uint8_t *p,unsigned w,unsigned en){switch(w){case 2:return rd16(p,en);case 4:return rd32(p,en);default:return rd64(p,en);}}
	cmove	%ecx, %edx	# tmp215,, _114, _113
# bench.c:8: static uint64_t readw(const uint8_t *p,unsigned w,unsigned en){switch(w){case 2:return rd16(p,en);case 4:return rd32(p,en);default:return rd64(p,en);}}
	jmp	.L114	#
	.p2align 4,,10
	.p2align 3
.L101:
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movzwl	(%rbx), %edx	# MEM <unsigned short> [(char * {ref-all})p_54], _97
	movzwl	2(%rbx), %eax	# MEM <unsigned short> [(char * {ref-all})p_54 + 2B], _88
# bench.c:8: static uint64_t readw(const uint8_t *p,unsigned w,unsigned en){switch(w){case 2:return rd16(p,en);case 4:return rd32(p,en);default:return rd64(p,en);}}
	movzwl	%dx, %r14d	# _97, _140
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	testl	%r15d, %r15d	# en
	je	.L105	#,
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	rolw	$8, %dx	#, _154
	rolw	$8, %ax	#, _88
# bench.c:8: static uint64_t readw(const uint8_t *p,unsigned w,unsigned en){switch(w){case 2:return rd16(p,en);case 4:return rd32(p,en);default:return rd64(p,en);}}
	movzwl	%dx, %r14d	# _154, _140
.L105:
	movzwl	%ax, %edi	# _88, _89
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movl	$2, %r9d	#, _136
# bench.c:8: static uint64_t readw(const uint8_t *p,unsigned w,unsigned en){switch(w){case 2:return rd16(p,en);case 4:return rd32(p,en);default:return rd64(p,en);}}
	jmp	.L108	#
	.p2align 4,,10
	.p2align 3
.L139:
	movq	48(%rsp), %r8	# %sfp, len
	movq	64(%rsp), %rdx	# %sfp, p
	movq	%r13, %rbx	# p, p
	movq	(%rsp), %r12	# %sfp, target_size
	movq	56(%rsp), %r11	# %sfp, _49
	leaq	(%rdx,%r8), %rax	#, _55
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	subq	%r13, %rax	# p, _55
	movq	%rax, %r8	# _55, len
.L109:
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	addl	$1, 72(%rsp)	#, %sfp
	movl	72(%rsp), %eax	# %sfp, b
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	cmpl	%eax, 76(%rsp)	# b, %sfp
	jne	.L118	#,
.L119:
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	xorl	%eax, %eax	# <retval>
	jmp	.L94	#
.L121:
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movq	%rdx, %rbx	# p, p
	jmp	.L109	#
.L136:
	.cfi_def_cfa_offset 8
	.cfi_restore 3
	.cfi_restore 6
	.cfi_restore 12
	.cfi_restore 13
	.cfi_restore 14
	.cfi_restore 15
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movl	$-1, %eax	#, <retval>
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	ret	
	.cfi_endproc
.LFE68:
	.size	generic.constprop.0, .-generic.constprop.0
	.section	.rodata.str1.1
.LC3:
	.string	"monolithic"
.LC4:
	.string	"--L="
.LC5:
	.string	"--quiet-reloc"
	.section	.rodata.str1.8
	.align 8
.LC6:
	.string	"usage: %s [--L=monolithic|scattered] <file.ueec>\n"
	.section	.rodata.str1.1
.LC7:
	.string	"rb"
.LC8:
	.string	"fopen"
.LC9:
	.string	"read error\n"
.LC10:
	.string	"invalid magic\n"
.LC11:
	.string	"node: %d, load-mode: %s\n"
.LC12:
	.string	"no matching node\n"
	.section	.rodata.str1.8
	.align 8
.LC13:
	.string	"resident sections: %d, RELOC sections: %d\n"
	.section	.rodata.str1.1
.LC14:
	.string	"scattered"
.LC15:
	.string	"unknown --L mode: %s\n"
	.section	.rodata.str1.8
	.align 8
.LC16:
	.string	"invalid or unsupported relocation section %d\n"
	.section	.rodata.str1.1
.LC17:
	.string	"no CODE section found\n"
	.section	.text.unlikely,"ax",@progbits
.LCOLDB18:
	.text
.LHOTB18:
	.p2align 4
	.globl	loader_main
	.type	loader_main, @function
loader_main:
.LFB62:
	.cfi_startproc
	endbr64	
	pushq	%r15	#
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14	#
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13	#
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12	#
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp	#
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx	#
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$328, %rsp	#,
	.cfi_def_cfa_offset 384
# loader.c:123: int main(int argc, char *argv[]) {
	movq	%fs:40, %r13	# MEM[(<address-space-1> long unsigned int *)40B], argv
	movq	%r13, 312(%rsp)	# argv, D.5925
	movq	%rsi, %r13	# argv, argv
# loader.c:127:     for (int i = 1; i < argc; i++) {
	cmpl	$1, %edi	#, argc
	jle	.L142	#,
	leal	-2(%rdi), %eax	#, _581
# loader.c:130:         else path = argv[i];
	movq	%r13, (%rsp)	# argv, %sfp
# loader.c:126:     int trace_reloc = 1;
	movl	$1, %ebx	#, trace_reloc
# loader.c:124:     const char *path = NULL;
	xorl	%r15d, %r15d	# path
	leaq	16(%r13,%rax,8), %r14	#, _79
# loader.c:125:     const char *load_mode = "monolithic";
	leaq	.LC3(%rip), %rbp	#, load_mode
# loader.c:130:         else path = argv[i];
	addq	$8, %r13	#, ivtmp.267
	jmp	.L145	#
	.p2align 4,,10
	.p2align 3
.L276:
# loader.c:127:     for (int i = 1; i < argc; i++) {
	addq	$8, %r13	#, ivtmp.267
# loader.c:128:         if (!strncmp(argv[i], "--L=", 4)) load_mode = argv[i] + 4;
	leaq	4(%r12), %rbp	#, load_mode
# loader.c:127:     for (int i = 1; i < argc; i++) {
	cmpq	%r13, %r14	# ivtmp.267, _79
	je	.L275	#,
.L145:
# loader.c:128:         if (!strncmp(argv[i], "--L=", 4)) load_mode = argv[i] + 4;
	movq	0(%r13), %r12	# MEM[(char * *)_584], _4
	movl	$4, %edx	#,
	leaq	.LC4(%rip), %rsi	#,
	movq	%r12, %rdi	# _4,
	call	strncmp@PLT	#
# loader.c:128:         if (!strncmp(argv[i], "--L=", 4)) load_mode = argv[i] + 4;
	testl	%eax, %eax	# _5
	je	.L276	#,
# loader.c:129:         else if (!strcmp(argv[i], "--quiet-reloc")) trace_reloc = 0;
	leaq	.LC5(%rip), %rsi	#,
	movq	%r12, %rdi	# _4,
	call	strcmp@PLT	#
# loader.c:130:         else path = argv[i];
	testl	%eax, %eax	# _6
	movl	$0, %eax	#, tmp695
	cmovne	%r12, %r15	# path,, _4, path
	cmove	%eax, %ebx	# trace_reloc,, tmp695, trace_reloc
# loader.c:127:     for (int i = 1; i < argc; i++) {
	addq	$8, %r13	#, ivtmp.267
	cmpq	%r13, %r14	# ivtmp.267, _79
	jne	.L145	#,
.L275:
# loader.c:132:     if (!path) { fprintf(stderr, "usage: %s [--L=monolithic|scattered] <file.ueec>\n", argv[0]); return 1; }
	movq	(%rsp), %r13	# %sfp, argv
	testq	%r15, %r15	# path
	je	.L142	#,
# loader.c:134:     FILE *f = fopen(path, "rb");
	leaq	.LC7(%rip), %rsi	#,
	movq	%r15, %rdi	# path,
	call	fopen@PLT	#
	movq	%rax, %r13	#, tmp535
# loader.c:135:     if (!f) { perror("fopen"); return 1; }
	testq	%rax, %rax	# tmp535
	je	.L263	#,
# loader.c:136:     fseek(f, 0, SEEK_END);
	xorl	%esi, %esi	#
	movl	$2, %edx	#,
	movq	%rax, %rdi	# tmp535,
	call	fseek@PLT	#
# loader.c:137:     long fsize = ftell(f);
	movq	%r13, %rdi	# tmp535,
	call	ftell@PLT	#
# loader.c:138:     fseek(f, 0, SEEK_SET);
	xorl	%edx, %edx	#
	xorl	%esi, %esi	#
	movq	%r13, %rdi	# tmp535,
# loader.c:137:     long fsize = ftell(f);
	movq	%rax, %r14	#, fsize
# loader.c:138:     fseek(f, 0, SEEK_SET);
	call	fseek@PLT	#
# loader.c:139:     uint8_t *buf = malloc(fsize);
	movq	%r14, %rdi	# fsize,
	call	malloc@PLT	#
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:331:     return __fread_alias (__ptr, __size, __n, __stream);
	movq	%r13, %rcx	# tmp535,
	movq	%r14, %rdx	# fsize,
	movl	$1, %esi	#,
	movq	%rax, %rdi	# buf,
# loader.c:139:     uint8_t *buf = malloc(fsize);
	movq	%rax, %r12	#, buf
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:331:     return __fread_alias (__ptr, __size, __n, __stream);
	call	fread@PLT	#
# loader.c:140:     if (fread(buf, 1, fsize, f) != (size_t)fsize) { fprintf(stderr, "read error\n"); return 1; }
	cmpq	%rax, %r14	# _291, fsize
	je	.L149	#,
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:111:   return __fprintf_chk (__stream, __USE_FORTIFY_LEVEL - 1, __fmt,
	movq	stderr(%rip), %rcx	# stderr,
	movl	$11, %edx	#,
	movl	$1, %esi	#,
	leaq	.LC9(%rip), %rdi	#,
	call	fwrite@PLT	#
.L147:
# loader.c:274: }
	movq	312(%rsp), %rax	# D.5925, tmp557
	subq	%fs:40, %rax	# MEM[(<address-space-1> long unsigned int *)40B], tmp557
	jne	.L277	#,
	addq	$328, %rsp	#,
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movl	$1, %eax	#,
	popq	%rbx	#
	.cfi_def_cfa_offset 48
	popq	%rbp	#
	.cfi_def_cfa_offset 40
	popq	%r12	#
	.cfi_def_cfa_offset 32
	popq	%r13	#
	.cfi_def_cfa_offset 24
	popq	%r14	#
	.cfi_def_cfa_offset 16
	popq	%r15	#
	.cfi_def_cfa_offset 8
	ret	
	.p2align 4,,10
	.p2align 3
.L149:
	.cfi_restore_state
# loader.c:141:     fclose(f);
	movq	%r13, %rdi	# tmp535,
	call	fclose@PLT	#
# loader.c:144:     if (buf[0] != UEEC_MAGIC_0 || buf[1] != UEEC_MAGIC_1 || buf[2] != UEEC_MAGIC_2) {
	cmpb	$95, (%r12)	#, *buf_209
	jne	.L150	#,
# loader.c:144:     if (buf[0] != UEEC_MAGIC_0 || buf[1] != UEEC_MAGIC_1 || buf[2] != UEEC_MAGIC_2) {
	cmpb	$71, 1(%r12)	#, MEM[(uint8_t *)buf_209 + 1B]
	jne	.L150	#,
# loader.c:144:     if (buf[0] != UEEC_MAGIC_0 || buf[1] != UEEC_MAGIC_1 || buf[2] != UEEC_MAGIC_2) {
	cmpb	$77, 2(%r12)	#, MEM[(uint8_t *)buf_209 + 2B]
	jne	.L150	#,
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movzwl	4(%r12), %eax	# MEM <unsigned short> [(char * {ref-all})buf_209 + 4B], _58
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	movzbl	3(%r12), %r11d	# MEM[(uint8_t *)buf_209 + 3B], _16
	movl	%eax, %edx	# _58, tmp508
	rolw	$8, %dx	#, tmp508
	shrb	$7, %r11b	#, _16
	cmovne	%edx, %eax	# tmp508,, _58
	movb	%r11b, 8(%rsp)	# _16, %sfp
	movzwl	%ax, %ecx	# _58, nodes
# loader.c:154:     node_t *node = malloc(sizeof(node_t) * nodes);
	movzwl	%ax, %eax	# _58, _18
# loader.c:154:     node_t *node = malloc(sizeof(node_t) * nodes);
	leaq	(%rax,%rax,2), %rdi	#, _19
	movl	%ecx, (%rsp)	# nodes, %sfp
	salq	$2, %rdi	#, tmp367
# loader.c:154:     node_t *node = malloc(sizeof(node_t) * nodes);
	call	malloc@PLT	#
# loader.c:156:     for (unsigned i = 0; i < nodes; i++) {
	movl	(%rsp), %ecx	# %sfp, nodes
	movzbl	8(%rsp), %r11d	# %sfp, _16
# loader.c:154:     node_t *node = malloc(sizeof(node_t) * nodes);
	movq	%rax, %rdx	#, node
# loader.c:156:     for (unsigned i = 0; i < nodes; i++) {
	testl	%ecx, %ecx	# nodes
	je	.L153	#,
	leal	-1(%rcx), %eax	#, _594
# loader.c:155:     long total_info = 0;
	xorl	%r8d, %r8d	# total_info
# loader.c:151:     size_t off = 8;
	movl	$8, %esi	#, off
	leaq	(%rax,%rax,2), %rax	#, _588
	addq	%rax, %rax	# tmp374
	movq	%rax, 8(%rsp)	# tmp374, %sfp
	leaq	14(%rax), %r14	#, off
	.p2align 6
	.p2align 4
	.p2align 3
.L155:
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movl	(%r12,%rsi), %eax	# MEM <unsigned int> [(char * {ref-all})buf_209 + off_449 * 1], _442
# loader.c:47:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap32(v);
	testb	%r11b, %r11b	# _16
	movl	%eax, %edi	# _442, tmp510
	bswap	%edi		# tmp510
	cmovne	%edi, %eax	# tmp510,, _442
# loader.c:158:         node[i].machine_type = (v >> 7) & 0x7;
	movl	%eax, %edi	# _442, _441
	shrl	$7, %edi	#, _441
# loader.c:158:         node[i].machine_type = (v >> 7) & 0x7;
	andl	$7, %edi	#, tmp376
	movl	%edi, -16(%rdx,%rsi,2)	# tmp376, MEM[(int *)node_215 + -16B + off_449 * 2]
# loader.c:159:         node[i].machine = (v >> 10) & 0xFF;
	movl	%eax, %edi	# _442, _423
# loader.c:160:         node[i].section_count = ((v >> 27) & 0x1F) + 1;
	shrl	$27, %eax	#,
# loader.c:159:         node[i].machine = (v >> 10) & 0xFF;
	shrl	$10, %edi	#, _423
# loader.c:161:         total_info += node[i].section_count - 1; // HEADER ar iTvleba node_info-Si
	addq	%rax, %r8	# _383, total_info
# loader.c:159:         node[i].machine = (v >> 10) & 0xFF;
	andl	$255, %edi	#, tmp378
	movl	%edi, -12(%rdx,%rsi,2)	# tmp378, MEM[(int *)node_215 + -12B + off_449 * 2]
# loader.c:160:         node[i].section_count = ((v >> 27) & 0x1F) + 1;
	leal	1(%rax), %edi	#, tmp379
	movl	%edi, -8(%rdx,%rsi,2)	# tmp379, MEM[(int *)node_215 + -8B + off_449 * 2]
# loader.c:163:         off += 2; // format
	addq	$6, %rsi	#, off
# loader.c:156:     for (unsigned i = 0; i < nodes; i++) {
	cmpq	%r14, %rsi	# off, off
	jne	.L155	#,
# loader.c:167:     info_t *info = malloc(sizeof(info_t) * total_info);
	leaq	0(,%r8,8), %r13	#, _33
	movq	%rdx, 40(%rsp)	# node, %sfp
# loader.c:167:     info_t *info = malloc(sizeof(info_t) * total_info);
	movq	%r13, %rdi	# _33,
	movl	%ecx, 32(%rsp)	# nodes, %sfp
	movb	%r11b, 24(%rsp)	# _16, %sfp
# loader.c:167:     info_t *info = malloc(sizeof(info_t) * total_info);
	movq	%r8, (%rsp)	# total_info, %sfp
# loader.c:167:     info_t *info = malloc(sizeof(info_t) * total_info);
	call	malloc@PLT	#
# loader.c:169:     for (long i = 0; i < total_info; i++) {
	movq	(%rsp), %r8	# %sfp, total_info
	movzbl	24(%rsp), %r11d	# %sfp, _16
	movl	32(%rsp), %ecx	# %sfp, nodes
	movq	40(%rsp), %rdx	# %sfp, node
# loader.c:167:     info_t *info = malloc(sizeof(info_t) * total_info);
	movq	%rax, 16(%rsp)	# info, %sfp
# loader.c:169:     for (long i = 0; i < total_info; i++) {
	testq	%r8, %r8	# total_info
	jle	.L157	#,
	movq	8(%rsp), %rsi	# %sfp, tmp374
	leaq	4(%rax), %rdi	#, ivtmp.251
# loader.c:168:     long max_section = 0;
	movl	%ecx, %r15d	# nodes, nodes
	movq	%rdx, %r14	# node, node
	leaq	4(%rax,%r13), %r13	#, _31
	leaq	14(%r12,%rsi), %r9	#, ivtmp.247
	xorl	%esi, %esi	# max_section
	.p2align 6
	.p2align 4
	.p2align 3
.L159:
# loader.c:170:         info[i].n = rd16(buf + off, file_endian); off += 2;
	movzwl	(%r9), %edx	# MEM <unsigned short> [(char * {ref-all})_27], _459
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movl	2(%r9), %eax	# MEM <unsigned int> [(char * {ref-all})_27 + 2B], _460
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	testb	%r11b, %r11b	# _16
# loader.c:47:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap32(v);
	movl	%edx, %ecx	# _459, _463
	xchgb	%ch, %cl	# _463
	movzwl	%cx, %r10d	# _463, _463
	cmovne	%r10d, %edx	# _459,, _463, _459
	movl	%eax, %r10d	# _460, tmp519
	bswap	%r10d		# tmp519
	cmovne	%r10d, %eax	# _460,, tmp519, _460
# loader.c:170:         info[i].n = rd16(buf + off, file_endian); off += 2;
	movl	%edx, -4(%rdi)	# _459, MEM[(int *)_277 + -4B]
# loader.c:171:         info[i].s = rd32(buf + off, file_endian); off += 4;
	movl	%eax, (%rdi)	# _460, MEM[(int *)_277]
# loader.c:172:         if (info[i].s > max_section) max_section = info[i].s;
	cltq
# loader.c:172:         if (info[i].s > max_section) max_section = info[i].s;
	cmpq	%rax, %rsi	# _454, max_section
	cmovl	%rax, %rsi	# max_section,, _454, max_section
# loader.c:169:     for (long i = 0; i < total_info; i++) {
	addq	$8, %rdi	#, ivtmp.251
	addq	$6, %r9	#, ivtmp.247
	cmpq	%rdi, %r13	# ivtmp.251, _31
	jne	.L159	#,
# loader.c:174:     long total_sections = max_section + 1;
	leaq	1(%rsi), %rax	#, prephitmp_503
	movq	%r14, 32(%rsp)	# node, %sfp
# loader.c:176:     int *sec_type = malloc(sizeof(int) * total_sections);
	leaq	0(,%rax,4), %rdi	#, _548
# loader.c:177:     long *sec_size = malloc(sizeof(long) * total_sections);
	leaq	0(,%rax,8), %r14	#, _550
# loader.c:174:     long total_sections = max_section + 1;
	movb	%r11b, 56(%rsp)	# _16, %sfp
	movq	%r8, 40(%rsp)	# total_info, %sfp
	movq	%rsi, 64(%rsp)	# max_section, %sfp
	movl	%r15d, 48(%rsp)	# nodes, %sfp
# loader.c:176:     int *sec_type = malloc(sizeof(int) * total_sections);
	movq	%rax, (%rsp)	# prephitmp_503, %sfp
# loader.c:176:     int *sec_type = malloc(sizeof(int) * total_sections);
	call	malloc@PLT	#
# loader.c:177:     long *sec_size = malloc(sizeof(long) * total_sections);
	movq	%r14, %rdi	# _550,
# loader.c:176:     int *sec_type = malloc(sizeof(int) * total_sections);
	movq	%rax, 24(%rsp)	# sec_type, %sfp
# loader.c:177:     long *sec_size = malloc(sizeof(long) * total_sections);
	call	malloc@PLT	#
# loader.c:178:     long *sec_off = malloc(sizeof(long) * total_sections);
	movq	%r14, %rdi	# _550,
# loader.c:177:     long *sec_size = malloc(sizeof(long) * total_sections);
	movq	%rax, %r13	# sec_size, sec_size
# loader.c:178:     long *sec_off = malloc(sizeof(long) * total_sections);
	call	malloc@PLT	#
# loader.c:179:     for (long s = 0; s < total_sections; s++) {
	cmpq	$0, (%rsp)	#, %sfp
	movq	24(%rsp), %r9	# %sfp, sec_type
	movq	32(%rsp), %rdx	# %sfp, node
	movq	40(%rsp), %r8	# %sfp, total_info
# loader.c:178:     long *sec_off = malloc(sizeof(long) * total_sections);
	movq	%rax, %r15	# sec_off, sec_off
# loader.c:179:     for (long s = 0; s < total_sections; s++) {
	movl	48(%rsp), %ecx	# %sfp, nodes
	movzbl	56(%rsp), %r11d	# %sfp, _16
	jle	.L160	#,
	movq	8(%rsp), %rsi	# %sfp, tmp374
	leaq	-3(%r8,%r8,2), %rax	#, _518
	leaq	20(%rsi,%rax,2), %r14	#, off
	movq	64(%rsp), %rsi	# %sfp, max_section
.L203:
	movq	%r15, 8(%rsp)	# sec_off, %sfp
	leaq	(%r12,%r14), %rdi	#, ivtmp.237
# loader.c:179:     for (long s = 0; s < total_sections; s++) {
	xorl	%r10d, %r10d	# s
	movq	%rdx, %r15	# node, node
	movl	%ecx, 24(%rsp)	# nodes, %sfp
	jmp	.L162	#
	.p2align 6
	.p2align 4,,10
	.p2align 3
.L206:
# loader.c:179:     for (long s = 0; s < total_sections; s++) {
	addq	$1, %r10	#, s
.L162:
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	movzwl	(%rdi), %edx	# MEM <unsigned short> [(char * {ref-all})_147], _486
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movzwl	2(%rdi), %eax	# MEM <unsigned short> [(char * {ref-all})_147 + 2B], _487
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	testb	%r11b, %r11b	# _16
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	movl	%edx, %ecx	# _486, _491
	xchgb	%ch, %cl	# _491
	movzwl	%cx, %r14d	# _491, _491
	movl	%eax, %ecx	# _487, tmp527
	xchgb	%ch, %cl	# tmp527
	cmovne	%r14d, %edx	# _486,, _491, _486
	cmovne	%ecx, %eax	# _487,, tmp527, _487
# loader.c:179:     for (long s = 0; s < total_sections; s++) {
	addq	$6, %rdi	#, ivtmp.237
# loader.c:180:         sec_type[s] = rd16(buf + off, file_endian); off += 2;
	movl	%edx, (%r9,%r10,4)	# _486, MEM[(int *)sec_type_338 + _585 * 4]
# loader.c:181:         sec_size[s] = rd16(buf + off, file_endian); off += 2;
	movzwl	%ax, %eax	# _487, _487
	movq	%rax, 0(%r13,%r10,8)	# _487, MEM[(long int *)sec_size_540 + _585 * 8]
# loader.c:179:     for (long s = 0; s < total_sections; s++) {
	cmpq	%rsi, %r10	# max_section, s
	jl	.L206	#,
	movq	%r15, %rdx	# node, node
	movq	8(%rsp), %r15	# %sfp, sec_off
	movl	24(%rsp), %ecx	# %sfp, nodes
# loader.c:184:     sec_off[0] = 0;
	movq	$0, (%r15)	#, *sec_off_536
# loader.c:185:     for (long s = 1; s < total_sections; s++) sec_off[s] = sec_off[s-1] + sec_size[s-1];
	cmpq	$1, (%rsp)	#, %sfp
	je	.L165	#,
	xorl	%eax, %eax	# ivtmp.224
	xorl	%edi, %edi	# D__lsm0.169
	.p2align 5
	.p2align 4
	.p2align 3
.L166:
# loader.c:185:     for (long s = 1; s < total_sections; s++) sec_off[s] = sec_off[s-1] + sec_size[s-1];
	addq	0(%r13,%rax,8), %rdi	# MEM[(long int *)sec_size_540 + ivtmp.224_41 * 8], D__lsm0.169
# loader.c:185:     for (long s = 1; s < total_sections; s++) sec_off[s] = sec_off[s-1] + sec_size[s-1];
	movq	%rdi, 8(%r15,%rax,8)	# D__lsm0.169, MEM[(long int *)sec_off_536 + 8B + ivtmp.224_41 * 8]
# loader.c:185:     for (long s = 1; s < total_sections; s++) sec_off[s] = sec_off[s-1] + sec_size[s-1];
	addq	$1, %rax	#, ivtmp.224
	cmpq	%rsi, %rax	# max_section, ivtmp.224
	jl	.L166	#,
.L165:
# loader.c:189:     for (unsigned i = 0; i < nodes; i++) {
	testl	%ecx, %ecx	# nodes
	je	.L167	#,
.L164:
	movq	%rdx, %rax	# node, ivtmp.219
# loader.c:189:     for (unsigned i = 0; i < nodes; i++) {
	xorl	%edx, %edx	# i
	.p2align 4
	.p2align 3
.L171:
# loader.c:190:         if (node[i].machine_type == UEEC_MACHINE_TYPE_CPU && node[i].machine == HOST_MACHINE) {
	movl	(%rax), %r10d	# MEM[(int *)_40], i
# loader.c:190:         if (node[i].machine_type == UEEC_MACHINE_TYPE_CPU && node[i].machine == HOST_MACHINE) {
	testl	%r10d, %r10d	# i
	jne	.L168	#,
# loader.c:190:         if (node[i].machine_type == UEEC_MACHINE_TYPE_CPU && node[i].machine == HOST_MACHINE) {
	cmpl	$10, 4(%rax)	#, MEM[(int *)_40 + 4B]
	je	.L278	#,
.L168:
# loader.c:189:     for (unsigned i = 0; i < nodes; i++) {
	addl	$1, %edx	#, i
# loader.c:189:     for (unsigned i = 0; i < nodes; i++) {
	addq	$12, %rax	#, ivtmp.219
	cmpl	%edx, %ecx	# i, nodes
	jne	.L171	#,
.L167:
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:111:   return __fprintf_chk (__stream, __USE_FORTIFY_LEVEL - 1, __fmt,
	movq	stderr(%rip), %rcx	# stderr,
	movl	$17, %edx	#,
	movl	$1, %esi	#,
	leaq	.LC12(%rip), %rdi	#,
	call	fwrite@PLT	#
# loader.c:194:     if (chosen < 0) { fprintf(stderr, "no matching node\n"); return 1; }
	jmp	.L147	#
	.p2align 4,,10
	.p2align 3
.L150:
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:111:   return __fprintf_chk (__stream, __USE_FORTIFY_LEVEL - 1, __fmt,
	movq	stderr(%rip), %rcx	# stderr,
	movl	$14, %edx	#,
	movl	$1, %esi	#,
	leaq	.LC10(%rip), %rdi	#,
	call	fwrite@PLT	#
# loader.c:145:         fprintf(stderr, "invalid magic\n"); return 1;
	jmp	.L147	#
	.p2align 4,,10
	.p2align 3
.L142:
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:111:   return __fprintf_chk (__stream, __USE_FORTIFY_LEVEL - 1, __fmt,
	movq	0(%r13), %rcx	# *argv_283(D), *argv_283(D)
	movq	stderr(%rip), %rdi	# stderr,
	leaq	.LC6(%rip), %rdx	#,
	xorl	%eax, %eax	#
	movl	$2, %esi	#,
	call	__fprintf_chk@PLT	#
# loader.c:132:     if (!path) { fprintf(stderr, "usage: %s [--L=monolithic|scattered] <file.ueec>\n", argv[0]); return 1; }
	jmp	.L147	#
.L278:
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:118:   return __printf_chk (__USE_FORTIFY_LEVEL - 1, __fmt, __va_arg_pack ());
	xorl	%eax, %eax	#
	movq	%rbp, %rcx	# load_mode,
	leaq	.LC11(%rip), %rsi	#,
	movl	%edx, (%rsp)	# i, %sfp
	movl	$2, %edi	#,
	movb	%r11b, 40(%rsp)	# _16, %sfp
	movq	%r9, 32(%rsp)	# sec_type, %sfp
	movl	%r10d, 24(%rsp)	# i, %sfp
	movq	%r8, 8(%rsp)	# total_info, %sfp
	call	__printf_chk@PLT	#
# loader.c:200:     for (long e = 0; e < total_info; e++) {
	movq	8(%rsp), %r8	# %sfp, total_info
	movl	(%rsp), %edx	# %sfp, i
	movl	24(%rsp), %r10d	# %sfp, i
	movq	32(%rsp), %r9	# %sfp, sec_type
	testq	%r8, %r8	# total_info
	movzbl	40(%rsp), %r11d	# %sfp, _16
	jle	.L279	#,
	movq	16(%rsp), %rax	# %sfp, ivtmp.213
# loader.c:199:     int reloc_g[8], n_reloc = 0;
	movl	$0, 8(%rsp)	#, %sfp
# loader.c:198:     int resident_g[8], resident_type[8], n_resident = 0;
	xorl	%r14d, %r14d	# n_resident
	leaq	(%rax,%r8,8), %rdi	#, _520
	jmp	.L174	#
	.p2align 4,,10
	.p2align 3
.L173:
# loader.c:204:         else { resident_type[n_resident] = sec_type[s]; resident_g[n_resident] = s; n_resident++; }
	movslq	%r14d, %r8	# n_resident, n_resident
# loader.c:204:         else { resident_type[n_resident] = sec_type[s]; resident_g[n_resident] = s; n_resident++; }
	addl	$1, %r14d	#, n_resident
# loader.c:204:         else { resident_type[n_resident] = sec_type[s]; resident_g[n_resident] = s; n_resident++; }
	movl	%esi, 112(%rsp,%r8,4)	# _77, resident_type[n_resident_403]
# loader.c:204:         else { resident_type[n_resident] = sec_type[s]; resident_g[n_resident] = s; n_resident++; }
	movl	%ecx, 80(%rsp,%r8,4)	# s, resident_g[n_resident_403]
.L172:
# loader.c:200:     for (long e = 0; e < total_info; e++) {
	addq	$8, %rax	#, ivtmp.213
	cmpq	%rdi, %rax	# _520, ivtmp.213
	je	.L280	#,
.L174:
# loader.c:201:         if (info[e].n != chosen) continue;
	cmpl	%edx, (%rax)	# i, MEM[(int *)_504]
	jne	.L172	#,
# loader.c:202:         int s = info[e].s;
	movslq	4(%rax), %rsi	# MEM[(int *)_504 + 4B],
	movq	%rsi, %rcx	#,
# loader.c:203:         if (sec_type[s] == UEEC_SECTION_RELOCATION) reloc_g[n_reloc++] = s;
	movl	(%r9,%rsi,4), %esi	# *_76, _77
# loader.c:203:         if (sec_type[s] == UEEC_SECTION_RELOCATION) reloc_g[n_reloc++] = s;
	cmpl	$5, %esi	#, _77
	jne	.L173	#,
# loader.c:203:         if (sec_type[s] == UEEC_SECTION_RELOCATION) reloc_g[n_reloc++] = s;
	movslq	8(%rsp), %rsi	# %sfp,
	movl	%ecx, 144(%rsp,%rsi,4)	# s, reloc_g[n_reloc_405]
# loader.c:203:         if (sec_type[s] == UEEC_SECTION_RELOCATION) reloc_g[n_reloc++] = s;
	leal	1(%rsi), %ecx	#, n_reloc
	movl	%ecx, 8(%rsp)	# n_reloc, %sfp
	jmp	.L172	#
.L279:
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:118:   return __printf_chk (__USE_FORTIFY_LEVEL - 1, __fmt, __va_arg_pack ());
	xorl	%ecx, %ecx	#
	xorl	%edx, %edx	#
	leaq	.LC13(%rip), %rsi	#,
	movl	$2, %edi	#,
	xorl	%eax, %eax	#
	movb	%r11b, (%rsp)	# _16, %sfp
	call	__printf_chk@PLT	#
# loader.c:214:     if (!strcmp(load_mode, "monolithic")) {
	leaq	.LC3(%rip), %rsi	#,
	movq	%rbp, %rdi	# load_mode,
	call	strcmp@PLT	#
	movzbl	(%rsp), %r11d	# %sfp, _16
	movl	%eax, 8(%rsp)	# n_reloc, %sfp
# loader.c:214:     if (!strcmp(load_mode, "monolithic")) {
	testl	%eax, %eax	# n_reloc
	je	.L176	#,
# loader.c:227:     } else if (!strcmp(load_mode, "scattered")) {
	leaq	.LC14(%rip), %rsi	#,
	movq	%rbp, %rdi	# load_mode,
	call	strcmp@PLT	#
# loader.c:227:     } else if (!strcmp(load_mode, "scattered")) {
	testl	%eax, %eax	# n_reloc
	jne	.L181	#,
.L188:
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:111:   return __fprintf_chk (__stream, __USE_FORTIFY_LEVEL - 1, __fmt,
	movq	stderr(%rip), %rcx	# stderr,
	movl	$22, %edx	#,
	movl	$1, %esi	#,
	leaq	.LC17(%rip), %rdi	#,
	call	fwrite@PLT	#
# loader.c:260:     if (!entry) { fprintf(stderr, "no CODE section found\n"); return 1; }
	jmp	.L147	#
	.p2align 4,,10
	.p2align 3
.L280:
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:118:   return __printf_chk (__USE_FORTIFY_LEVEL - 1, __fmt, __va_arg_pack ());
	movl	8(%rsp), %ecx	# %sfp,
	movl	%r14d, %edx	# n_resident,
	leaq	.LC13(%rip), %rsi	#,
	xorl	%eax, %eax	#
	movl	$2, %edi	#,
	movb	%r11b, 24(%rsp)	# _16, %sfp
	movl	%r10d, (%rsp)	# i, %sfp
	call	__printf_chk@PLT	#
# loader.c:212:     long *local_off_in_mono = malloc(sizeof(long) * n_resident);
	movslq	%r14d, %rax	# n_resident, _577
# loader.c:212:     long *local_off_in_mono = malloc(sizeof(long) * n_resident);
	leaq	0(,%rax,8), %r8	#, _560
# loader.c:212:     long *local_off_in_mono = malloc(sizeof(long) * n_resident);
	movq	%rax, 16(%rsp)	# _577, %sfp
	movq	%r8, %rdi	# _560,
	movq	%r8, 40(%rsp)	# _560, %sfp
	call	malloc@PLT	#
# loader.c:214:     if (!strcmp(load_mode, "monolithic")) {
	leaq	.LC3(%rip), %rsi	#,
	movq	%rbp, %rdi	# load_mode,
# loader.c:212:     long *local_off_in_mono = malloc(sizeof(long) * n_resident);
	movq	%rax, 32(%rsp)	#, %sfp
# loader.c:214:     if (!strcmp(load_mode, "monolithic")) {
	call	strcmp@PLT	#
# loader.c:214:     if (!strcmp(load_mode, "monolithic")) {
	movl	(%rsp), %r10d	# %sfp, i
	movzbl	24(%rsp), %r11d	# %sfp, _16
	testl	%eax, %eax	# _80
	jne	.L175	#,
# loader.c:216:         for (int i = 0; i < n_resident; i++) {
	testl	%r14d, %r14d	# n_resident
	je	.L176	#,
	leaq	80(%rsp), %rcx	#, ivtmp.187
	movq	32(%rsp), %rax	# %sfp, local_off_in_mono
	movq	40(%rsp), %r8	# %sfp, _560
# loader.c:215:         long total = 0;
	xorl	%esi, %esi	# total
	movq	%rcx, 24(%rsp)	# ivtmp.187, %sfp
	movq	%rax, %rdx	# local_off_in_mono, ivtmp.201
	leaq	(%rax,%r8), %rdi	#, _341
	.p2align 6
	.p2align 4
	.p2align 3
.L177:
# loader.c:218:             long padded = ((sec_size[resident_g[i]] + 15) / 16) * 16; // 16-byte alignment
	movslq	(%rcx), %rax	# MEM[(int *)_160], _85
# loader.c:217:             local_off_in_mono[i] = total;
	movq	%rsi, (%rdx)	# total, MEM[(long int *)_367]
# loader.c:218:             long padded = ((sec_size[resident_g[i]] + 15) / 16) * 16; // 16-byte alignment
	movq	0(%r13,%rax,8), %r8	# *_87, *_87
# loader.c:218:             long padded = ((sec_size[resident_g[i]] + 15) / 16) * 16; // 16-byte alignment
	leaq	30(%r8), %rax	#, tmp425
	addq	$15, %r8	#, _89
	cmovns	%r8, %rax	# tmp425,, _89, _89
# loader.c:216:         for (int i = 0; i < n_resident; i++) {
	addq	$8, %rdx	#, ivtmp.201
	addq	$4, %rcx	#, ivtmp.202
# loader.c:218:             long padded = ((sec_size[resident_g[i]] + 15) / 16) * 16; // 16-byte alignment
	andq	$-16, %rax	#, padded_238
# loader.c:219:             total += padded;
	addq	%rax, %rsi	# padded_238, total
# loader.c:216:         for (int i = 0; i < n_resident; i++) {
	cmpq	%rdi, %rdx	# _341, ivtmp.201
	jne	.L177	#,
# loader.c:221:         mono_mem = mmap(NULL, total, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
	movl	$34, %ecx	#,
	xorl	%r9d, %r9d	#
	movl	$-1, %r8d	#,
	xorl	%edi, %edi	#
	movl	$3, %edx	#,
	movb	%r11b, 40(%rsp)	# _16, %sfp
	xorl	%ebp, %ebp	# ivtmp.191
	movl	%r10d, 76(%rsp)	# i, %sfp
	movq	%rsi, 56(%rsp)	# total, %sfp
	call	mmap@PLT	#
	movl	%r14d, 64(%rsp)	# n_resident, %sfp
	movq	%rbp, %r14	# ivtmp.191, ivtmp.191
	movq	32(%rsp), %rbp	# %sfp, local_off_in_mono
	movq	%rax, %rcx	# mono_mem, mono_mem
	leaq	176(%rsp), %rax	#, ivtmp.176
	movl	%ebx, 48(%rsp)	# trace_reloc, %sfp
	movq	%rax, (%rsp)	# ivtmp.176, %sfp
	movq	%rcx, %rbx	# mono_mem, mono_mem
	.p2align 4
	.p2align 3
.L178:
# loader.c:223:             local_base[i] = (uint8_t *)mono_mem + local_off_in_mono[i];
	movq	0(%rbp,%r14,8), %rdi	# MEM[(long int *)local_off_in_mono_229 + ivtmp.191_397 * 8], _97
# loader.c:223:             local_base[i] = (uint8_t *)mono_mem + local_off_in_mono[i];
	movq	(%rsp), %rax	# %sfp, ivtmp.176
# loader.c:223:             local_base[i] = (uint8_t *)mono_mem + local_off_in_mono[i];
	addq	%rbx, %rdi	# mono_mem, _97
# loader.c:223:             local_base[i] = (uint8_t *)mono_mem + local_off_in_mono[i];
	movq	%rdi, (%rax,%r14,8)	# _97, MEM[(void * *)&local_base + ivtmp.191_397 * 8]
# loader.c:224:             memcpy(local_base[i], buf + sec_off[resident_g[i]], sec_size[resident_g[i]]);
	movq	24(%rsp), %rax	# %sfp, ivtmp.187
	movslq	(%rax,%r14,4), %rax	# MEM[(int *)&resident_g + ivtmp.191_397 * 4], _99
# loader.c:222:         for (int i = 0; i < n_resident; i++) {
	addq	$1, %r14	#, ivtmp.191
# loader.c:224:             memcpy(local_base[i], buf + sec_off[resident_g[i]], sec_size[resident_g[i]]);
	movq	(%r15,%rax,8), %rsi	# *_104, _107
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movq	0(%r13,%rax,8), %rdx	# *_101, *_101
# loader.c:224:             memcpy(local_base[i], buf + sec_off[resident_g[i]], sec_size[resident_g[i]]);
	addq	%r12, %rsi	# buf, _107
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	call	memcpy@PLT	#
# loader.c:222:         for (int i = 0; i < n_resident; i++) {
	cmpq	%r14, 16(%rsp)	# ivtmp.191, %sfp
	jne	.L178	#,
	movq	%rbx, %rcx	# mono_mem, mono_mem
	movzbl	40(%rsp), %r11d	# %sfp, _16
	movq	56(%rsp), %rsi	# %sfp, total
	movl	48(%rsp), %ebx	# %sfp, trace_reloc
	movl	64(%rsp), %r14d	# %sfp, n_resident
	movl	76(%rsp), %r10d	# %sfp, i
.L179:
	leaq	240(%rsp), %rdx	#, tmp499
	movq	24(%rsp), %rax	# %sfp, ivtmp.187
	movq	%rdx, %rdi	# tmp499, ivtmp.188
	.p2align 5
	.p2align 4
	.p2align 3
.L185:
# loader.c:238:     for (int i = 0; i < n_resident; ++i) resident_sizes[i] = (size_t)sec_size[resident_g[i]];
	movslq	(%rax), %r8	# MEM[(int *)_162], _122
# loader.c:238:     for (int i = 0; i < n_resident; ++i) resident_sizes[i] = (size_t)sec_size[resident_g[i]];
	addl	$1, %r10d	#, i
# loader.c:238:     for (int i = 0; i < n_resident; ++i) resident_sizes[i] = (size_t)sec_size[resident_g[i]];
	addq	$4, %rax	#, ivtmp.187
	addq	$8, %rdi	#, ivtmp.188
# loader.c:238:     for (int i = 0; i < n_resident; ++i) resident_sizes[i] = (size_t)sec_size[resident_g[i]];
	movq	0(%r13,%r8,8), %r8	# *_124, *_124
	movq	%r8, -8(%rdi)	# *_124, MEM[(long unsigned int *)_391]
# loader.c:238:     for (int i = 0; i < n_resident; ++i) resident_sizes[i] = (size_t)sec_size[resident_g[i]];
	cmpl	%r10d, %r14d	# i, n_resident
	jg	.L185	#,
# loader.c:239:     for (int r = 0; r < n_reloc; ++r) {
	movl	8(%rsp), %edi	# %sfp,
	testl	%edi, %edi	#
	je	.L281	#,
.L183:
# loader.c:147:     unsigned file_endian = (buf[3] >> 7) & 1;
	movzbl	%r11b, %eax	# _16, _17
	xorl	%ebp, %ebp	# ivtmp.180
	movl	%r14d, 16(%rsp)	# n_resident, %sfp
	movl	%eax, 24(%rsp)	# _17, %sfp
	leaq	144(%rsp), %rax	#, tmp505
	movq	%rbp, %r14	# ivtmp.180, ivtmp.180
	movl	%ebx, %ebp	# trace_reloc, trace_reloc
	movq	%rax, 32(%rsp)	# tmp505, %sfp
	movq	%rsi, 48(%rsp)	# total, %sfp
	movq	%rcx, 56(%rsp)	# mono_mem, %sfp
	movq	%rdx, 40(%rsp)	# tmp499, %sfp
	jmp	.L191	#
	.p2align 4,,10
	.p2align 3
.L190:
# loader.c:239:     for (int r = 0; r < n_reloc; ++r) {
	addq	$1, %r14	#, ivtmp.180
	cmpl	%r14d, 8(%rsp)	# ivtmp.180, %sfp
	jle	.L282	#,
.L191:
# loader.c:240:         int g = reloc_g[r];
	movq	32(%rsp), %rax	# %sfp, tmp505
# loader.c:241:         if (process_reloc_section(buf + sec_off[g], (size_t)sec_size[g], file_endian,
	subq	$8, %rsp	#,
	.cfi_def_cfa_offset 392
# loader.c:240:         int g = reloc_g[r];
	movslq	(%rax,%r14,4), %rax	# MEM[(int *)&reloc_g + ivtmp.180_573 * 4],
# loader.c:241:         if (process_reloc_section(buf + sec_off[g], (size_t)sec_size[g], file_endian,
	movq	(%r15,%rax,8), %rdi	# *_132, _135
# loader.c:241:         if (process_reloc_section(buf + sec_off[g], (size_t)sec_size[g], file_endian,
	movq	0(%r13,%rax,8), %rsi	# *_129, *_129
	pushq	%rbp	# trace_reloc
	.cfi_def_cfa_offset 400
# loader.c:240:         int g = reloc_g[r];
	movq	%rax, %rbx	#,
# loader.c:241:         if (process_reloc_section(buf + sec_off[g], (size_t)sec_size[g], file_endian,
	movl	32(%rsp), %r9d	# %sfp,
	movq	56(%rsp), %r8	# %sfp,
	movq	16(%rsp), %rcx	# %sfp,
	movl	40(%rsp), %edx	# %sfp,
# loader.c:241:         if (process_reloc_section(buf + sec_off[g], (size_t)sec_size[g], file_endian,
	addq	%r12, %rdi	# buf, _135
# loader.c:241:         if (process_reloc_section(buf + sec_off[g], (size_t)sec_size[g], file_endian,
	call	process_reloc_section	#
# loader.c:241:         if (process_reloc_section(buf + sec_off[g], (size_t)sec_size[g], file_endian,
	popq	%rdx	#
	.cfi_def_cfa_offset 392
	popq	%rcx	#
	.cfi_def_cfa_offset 384
	testl	%eax, %eax	# _136
	je	.L190	#,
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:111:   return __fprintf_chk (__stream, __USE_FORTIFY_LEVEL - 1, __fmt,
	movq	stderr(%rip), %rdi	# stderr,
	movl	%ebx, %ecx	# g,
	movl	$2, %esi	#,
	xorl	%eax, %eax	#
	leaq	.LC16(%rip), %rdx	#,
	call	__fprintf_chk@PLT	#
# loader.c:244:             return 1;
	jmp	.L147	#
.L175:
# loader.c:227:     } else if (!strcmp(load_mode, "scattered")) {
	leaq	.LC14(%rip), %rsi	#,
	movq	%rbp, %rdi	# load_mode,
	movl	%r10d, 32(%rsp)	# i, %sfp
	movb	%r11b, (%rsp)	# _16, %sfp
	call	strcmp@PLT	#
# loader.c:227:     } else if (!strcmp(load_mode, "scattered")) {
	testl	%eax, %eax	# _108
	jne	.L181	#,
# loader.c:228:         for (int i = 0; i < n_resident; i++) {
	testl	%r14d, %r14d	# n_resident
	movzbl	(%rsp), %r11d	# %sfp, _16
	je	.L180	#,
	movq	16(%rsp), %rdx	# %sfp, _577
	leaq	80(%rsp), %rax	#, ivtmp.187
	movl	32(%rsp), %r10d	# %sfp, i
	leaq	176(%rsp), %rcx	#, ivtmp.176
	movq	%rax, %rbp	# ivtmp.187, ivtmp.207
	movq	%rax, 24(%rsp)	# ivtmp.187, %sfp
	leaq	(%rax,%rdx,4), %rax	#, _400
	movq	%rcx, (%rsp)	# ivtmp.176, %sfp
	movq	%rax, 40(%rsp)	# _400, %sfp
	movb	%r11b, 48(%rsp)	# _16, %sfp
	movl	%r10d, 76(%rsp)	# i, %sfp
	movq	%r12, 32(%rsp)	# buf, %sfp
	movl	%ebx, 56(%rsp)	# trace_reloc, %sfp
	movq	%rcx, %rbx	# ivtmp.208, ivtmp.208
	movl	%r14d, 64(%rsp)	# n_resident, %sfp
	movq	%rbp, %r14	# ivtmp.207, ivtmp.207
	.p2align 4
	.p2align 3
.L182:
# loader.c:229:             local_base[i] = mmap(NULL, sec_size[resident_g[i]], PROT_READ | PROT_WRITE,
	movslq	(%r14), %r12	# MEM[(int *)_566], _110
# loader.c:229:             local_base[i] = mmap(NULL, sec_size[resident_g[i]], PROT_READ | PROT_WRITE,
	xorl	%r9d, %r9d	#
	movl	$-1, %r8d	#,
	xorl	%edi, %edi	#
	movl	$34, %ecx	#,
	movl	$3, %edx	#,
# loader.c:228:         for (int i = 0; i < n_resident; i++) {
	addq	$4, %r14	#, ivtmp.207
	addq	$8, %rbx	#, ivtmp.208
# loader.c:229:             local_base[i] = mmap(NULL, sec_size[resident_g[i]], PROT_READ | PROT_WRITE,
	movq	0(%r13,%r12,8), %rbp	# *_112, _114
	movq	%rbp, %rsi	# _114,
	call	mmap@PLT	#
# loader.c:231:             memcpy(local_base[i], buf + sec_off[resident_g[i]], sec_size[resident_g[i]]);
	movq	32(%rsp), %rsi	# %sfp, _119
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movq	%rbp, %rdx	# _114,
# loader.c:231:             memcpy(local_base[i], buf + sec_off[resident_g[i]], sec_size[resident_g[i]]);
	addq	(%r15,%r12,8), %rsi	# *_116, _119
# loader.c:229:             local_base[i] = mmap(NULL, sec_size[resident_g[i]], PROT_READ | PROT_WRITE,
	movq	%rax, -8(%rbx)	# _115, MEM[(void * *)_565]
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movq	%rax, %rdi	# _115,
	call	memcpy@PLT	#
# loader.c:228:         for (int i = 0; i < n_resident; i++) {
	cmpq	%r14, 40(%rsp)	# ivtmp.207, %sfp
	jne	.L182	#,
# loader.c:211:     long total_mono_size = 0;
	movzbl	48(%rsp), %r11d	# %sfp, _16
	movl	56(%rsp), %ebx	# %sfp, trace_reloc
	xorl	%esi, %esi	# total
# loader.c:210:     void *mono_mem = NULL;
	xorl	%ecx, %ecx	# mono_mem
# loader.c:211:     long total_mono_size = 0;
	movl	64(%rsp), %r14d	# %sfp, n_resident
	movl	76(%rsp), %r10d	# %sfp, i
	movq	32(%rsp), %r12	# %sfp, buf
	jmp	.L179	#
.L282:
# loader.c:250:     if (mono_mem) {
	movq	56(%rsp), %rcx	# %sfp, mono_mem
	movq	48(%rsp), %rsi	# %sfp, total
	movl	16(%rsp), %r14d	# %sfp, n_resident
	testq	%rcx, %rcx	# mono_mem
	je	.L192	#,
# loader.c:252:         mprotect(mono_mem, total_mono_size, PROT_READ | PROT_EXEC | PROT_WRITE);
	movq	%rcx, %rdi	# mono_mem,
	movl	$7, %edx	#,
	movq	%rcx, 8(%rsp)	# mono_mem, %sfp
	call	mprotect@PLT	#
	movq	8(%rsp), %rcx	# %sfp, mono_mem
.L192:
# loader.c:255:     for (int i = 0; i < n_resident; i++) {
	testl	%r14d, %r14d	# n_resident
	je	.L188	#,
	movslq	%r14d, %rax	# n_resident, _577
	movq	%rax, 16(%rsp)	# _577, %sfp
.L200:
	movq	16(%rsp), %r15	# %sfp, _577
	movq	%r13, 8(%rsp)	# sec_size, %sfp
# loader.c:147:     unsigned file_endian = (buf[3] >> 7) & 1;
	xorl	%ebx, %ebx	# ivtmp.178
	movq	%rcx, %r13	# mono_mem, mono_mem
	movq	(%rsp), %rbp	# %sfp, ivtmp.176
	leaq	112(%rsp), %rcx	#, tmp502
	xorl	%r14d, %r14d	# entry
	salq	$2, %r15	#, _577
	jmp	.L196	#
	.p2align 4,,10
	.p2align 3
.L193:
# loader.c:258:         if (resident_type[i] == UEEC_SECTION_CODE && !entry) entry = local_base[i];
	cmpl	$1, %r12d	#, pretmp_564
	jne	.L195	#,
	testq	%r14, %r14	# entry
	je	.L283	#,
.L195:
# loader.c:255:     for (int i = 0; i < n_resident; i++) {
	addq	$4, %rbx	#, ivtmp.178
	addq	$8, %rbp	#, ivtmp.176
	cmpq	%rbx, %r15	# ivtmp.178, _576
	je	.L284	#,
.L196:
# loader.c:257:                                  resident_type[i] == UEEC_SECTION_CODE ? (PROT_READ | PROT_EXEC) : PROT_READ);
	movl	(%rcx,%rbx), %r12d	# MEM[(int *)&resident_type + ivtmp.178_310 * 1], pretmp_564
# loader.c:256:         if (!mono_mem) mprotect(local_base[i], sec_size[resident_g[i]],
	testq	%r13, %r13	# mono_mem
	jne	.L193	#,
# loader.c:256:         if (!mono_mem) mprotect(local_base[i], sec_size[resident_g[i]],
	movslq	80(%rsp,%rbx), %rax	# MEM[(int *)&resident_g + ivtmp.178_310 * 1], _141
# loader.c:256:         if (!mono_mem) mprotect(local_base[i], sec_size[resident_g[i]],
	xorl	%edx, %edx	# iftmp.27_184
	movq	%rcx, (%rsp)	# tmp502, %sfp
	cmpl	$1, %r12d	#, pretmp_564
# loader.c:256:         if (!mono_mem) mprotect(local_base[i], sec_size[resident_g[i]],
	movq	8(%rsp), %rcx	# %sfp, sec_size
# loader.c:256:         if (!mono_mem) mprotect(local_base[i], sec_size[resident_g[i]],
	sete	%dl	#, iftmp.27_184
# loader.c:256:         if (!mono_mem) mprotect(local_base[i], sec_size[resident_g[i]],
	movq	0(%rbp), %rdi	# MEM[(void * *)_574], MEM[(void * *)_574]
# loader.c:256:         if (!mono_mem) mprotect(local_base[i], sec_size[resident_g[i]],
	leal	1(,%rdx,4), %edx	#, iftmp.27_184
# loader.c:256:         if (!mono_mem) mprotect(local_base[i], sec_size[resident_g[i]],
	movq	(%rcx,%rax,8), %rsi	# *_143, *_143
	call	mprotect@PLT	#
	movq	(%rsp), %rcx	# %sfp, tmp502
	jmp	.L193	#
.L284:
# loader.c:260:     if (!entry) { fprintf(stderr, "no CODE section found\n"); return 1; }
	testq	%r14, %r14	# entry
	je	.L188	#,
# loader.c:262:     fflush(stdout);
	movq	stdout(%rip), %rdi	# stdout,
	movq	%r14, (%rsp)	# entry, %sfp
	call	fflush@PLT	#
# loader.c:271:     fn();
	movq	(%rsp), %r8	# %sfp, entry
	call	*%r8	# entry
# loader.c:273:     return 1;
	jmp	.L147	#
.L283:
# loader.c:258:         if (resident_type[i] == UEEC_SECTION_CODE && !entry) entry = local_base[i];
	movq	0(%rbp), %r14	# MEM[(void * *)_575], entry
	jmp	.L195	#
.L160:
# loader.c:184:     sec_off[0] = 0;
	movq	$0, (%rax)	#, *sec_off_224
	jmp	.L164	#
.L153:
# loader.c:167:     info_t *info = malloc(sizeof(info_t) * total_info);
	xorl	%edi, %edi	#
	movl	%ecx, 8(%rsp)	# nodes, %sfp
# loader.c:151:     size_t off = 8;
	movl	$8, %r14d	#, off
	movb	%r11b, (%rsp)	# _16, %sfp
	movq	%rax, 24(%rsp)	# node, %sfp
# loader.c:167:     info_t *info = malloc(sizeof(info_t) * total_info);
	call	malloc@PLT	#
	movzbl	(%rsp), %r11d	# %sfp, _16
	movl	8(%rsp), %ecx	# %sfp, nodes
# loader.c:155:     long total_info = 0;
	xorl	%r8d, %r8d	# total_info
# loader.c:167:     info_t *info = malloc(sizeof(info_t) * total_info);
	movq	%rax, 16(%rsp)	# info, %sfp
	movq	24(%rsp), %rdx	# %sfp, node
.L157:
# loader.c:176:     int *sec_type = malloc(sizeof(int) * total_sections);
	movl	$4, %edi	#,
	movq	%rdx, 48(%rsp)	# node, %sfp
	movq	%r8, 40(%rsp)	# total_info, %sfp
	movl	%ecx, 32(%rsp)	# nodes, %sfp
	movb	%r11b, 24(%rsp)	# _16, %sfp
	call	malloc@PLT	#
# loader.c:177:     long *sec_size = malloc(sizeof(long) * total_sections);
	movl	$8, %edi	#,
# loader.c:176:     int *sec_type = malloc(sizeof(int) * total_sections);
	movq	%rax, 8(%rsp)	# sec_type, %sfp
# loader.c:177:     long *sec_size = malloc(sizeof(long) * total_sections);
	call	malloc@PLT	#
# loader.c:178:     long *sec_off = malloc(sizeof(long) * total_sections);
	movl	$8, %edi	#,
# loader.c:177:     long *sec_size = malloc(sizeof(long) * total_sections);
	movq	%rax, %r13	# sec_size, sec_size
# loader.c:178:     long *sec_off = malloc(sizeof(long) * total_sections);
	call	malloc@PLT	#
	movq	8(%rsp), %r9	# %sfp, sec_type
	movl	32(%rsp), %ecx	# %sfp, nodes
	xorl	%esi, %esi	# max_section
	movq	$1, (%rsp)	#, %sfp
	movzbl	24(%rsp), %r11d	# %sfp, _16
	movq	%rax, %r15	# sec_off, sec_off
	movq	40(%rsp), %r8	# %sfp, total_info
	movq	48(%rsp), %rdx	# %sfp, node
	jmp	.L203	#
.L181:
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:111:   return __fprintf_chk (__stream, __USE_FORTIFY_LEVEL - 1, __fmt,
	movq	stderr(%rip), %rdi	# stderr,
	movq	%rbp, %rcx	# load_mode,
	movl	$2, %esi	#,
	xorl	%eax, %eax	#
	leaq	.LC15(%rip), %rdx	#,
	call	__fprintf_chk@PLT	#
# loader.c:234:         fprintf(stderr, "unknown --L mode: %s\n", load_mode); return 1;
	jmp	.L147	#
.L176:
# loader.c:221:         mono_mem = mmap(NULL, total, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
	xorl	%r9d, %r9d	#
	movl	$34, %ecx	#,
	xorl	%esi, %esi	#
	xorl	%edi, %edi	#
	movl	$-1, %r8d	#,
	movl	$3, %edx	#,
	movb	%r11b, (%rsp)	# _16, %sfp
	call	mmap@PLT	#
# loader.c:239:     for (int r = 0; r < n_reloc; ++r) {
	movzbl	(%rsp), %r11d	# %sfp, _16
# loader.c:221:         mono_mem = mmap(NULL, total, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
	movq	%rax, %rcx	# mono_mem, mono_mem
# loader.c:239:     for (int r = 0; r < n_reloc; ++r) {
	movl	8(%rsp), %eax	# %sfp,
	testl	%eax, %eax	#
	je	.L285	#,
	leaq	176(%rsp), %rax	#, ivtmp.176
	xorl	%r14d, %r14d	# n_resident
	xorl	%esi, %esi	# total
	movq	%rax, (%rsp)	# ivtmp.176, %sfp
	leaq	240(%rsp), %rdx	#, tmp499
	jmp	.L183	#
.L281:
# loader.c:250:     if (mono_mem) {
	testq	%rcx, %rcx	# mono_mem
	je	.L200	#,
# loader.c:252:         mprotect(mono_mem, total_mono_size, PROT_READ | PROT_EXEC | PROT_WRITE);
	movq	%rcx, %rdi	# mono_mem,
	movl	$7, %edx	#,
	movq	%rcx, 8(%rsp)	# mono_mem, %sfp
	call	mprotect@PLT	#
	movq	8(%rsp), %rcx	# %sfp, mono_mem
	jmp	.L200	#
.L180:
# loader.c:239:     for (int r = 0; r < n_reloc; ++r) {
	cmpl	$0, 8(%rsp)	#, %sfp
	je	.L188	#,
	leaq	176(%rsp), %rax	#, ivtmp.176
# loader.c:211:     long total_mono_size = 0;
	xorl	%esi, %esi	# total
# loader.c:210:     void *mono_mem = NULL;
	xorl	%ecx, %ecx	# mono_mem
	movq	%rax, (%rsp)	# ivtmp.176, %sfp
	leaq	240(%rsp), %rdx	#, tmp499
	jmp	.L183	#
.L277:
# loader.c:274: }
	call	__stack_chk_fail@PLT	#
.L285:
# loader.c:250:     if (mono_mem) {
	testq	%rcx, %rcx	# mono_mem
	je	.L188	#,
# loader.c:252:         mprotect(mono_mem, total_mono_size, PROT_READ | PROT_EXEC | PROT_WRITE);
	movl	$7, %edx	#,
	xorl	%esi, %esi	#
	movq	%rcx, %rdi	# mono_mem,
	call	mprotect@PLT	#
	jmp	.L188	#
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.type	loader_main.cold, @function
loader_main.cold:
.LFSB62:
.L263:
	.cfi_def_cfa_offset 384
	.cfi_offset 3, -56
	.cfi_offset 6, -48
	.cfi_offset 12, -40
	.cfi_offset 13, -32
	.cfi_offset 14, -24
	.cfi_offset 15, -16
# loader.c:135:     if (!f) { perror("fopen"); return 1; }
	leaq	.LC8(%rip), %rdi	#,
	call	perror@PLT	#
	jmp	.L147	#
	.cfi_endproc
.LFE62:
	.text
	.size	loader_main, .-loader_main
	.section	.text.unlikely
	.size	loader_main.cold, .-loader_main.cold
.LCOLDE18:
	.text
.LHOTE18:
	.section	.rodata.str1.8
	.align 8
.LC19:
	.string	"count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc"
	.section	.rodata.str1.1
.LC20:
	.string	"bench.c"
	.section	.rodata.str1.8
	.align 8
.LC21:
	.string	"rc==0&&!memcmp(m,expected,len)"
	.align 8
.LC22:
	.string	"%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n"
	.section	.text.unlikely
.LCOLDB23:
	.section	.text.startup,"ax",@progbits
.LHOTB23:
	.p2align 4
	.globl	main
	.type	main, @function
main:
.LFB67:
	.cfi_startproc
	endbr64	
	pushq	%r15	#
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14	#
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13	#
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12	#
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp	#
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	movl	$4, %ebp	#, ivtmp_340
	pushq	%rbx	#
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$328, %rsp	#,
	.cfi_def_cfa_offset 384
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%fs:40, %rdi	# MEM[(<address-space-1> long unsigned int *)40B],
	movq	%rdi, 312(%rsp)	#, D.6110
	leaq	.LC19(%rip), %rdi	#,
	call	puts@PLT	#
	leaq	256(%rsp), %rax	#, tmp464
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	$16, 36(%rsp)	#, %sfp
	movq	%rax, (%rsp)	# tmp464, %sfp
	leaq	288(%rsp), %rax	#, tmp467
	movq	%rax, 88(%rsp)	# tmp467, %sfp
	leaq	272(%rsp), %rax	#, tmp465
	movq	%rax, 80(%rsp)	# tmp465, %sfp
.L287:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movslq	36(%rsp), %r11	# %sfp,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	$8, 72(%rsp)	#, %sfp
	movl	$3, %r14d	#, ivtmp_342
	leal	-1(%r11), %ebx	#, _416
.L333:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movslq	72(%rsp), %rax	# %sfp,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	$512, 56(%rsp)	#, %sfp
	movl	%ebx, %r12d	# _416, _416
	movq	%r11, 176(%rsp)	# _415, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%rax, %rdi	#,
	movq	%rax, 184(%rsp)	# _2, %sfp
	imulq	%r11, %rax	# _415, _3
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	imull	%ebx, %edi	# _416, _5
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	leaq	8(%rax), %r15	#, len
	movq	%r15, %xmm2	# len, _255
	movq	%r15, %r13	# len, len
	movl	%edi, %ebx	# _5, _5
	punpcklqdq	%xmm2, %xmm2	# _255
	movaps	%xmm2, 192(%rsp)	# _255, %sfp
.L331:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	56(%rsp), %edi	# %sfp, page
	movl	%ebx, %eax	# _5, tmp449
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	$0, 172(%rsp)	#, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cltd
	movl	%r14d, 212(%rsp)	# ivtmp_342, %sfp
	idivl	%edi	# page
	movl	%ebx, %eax	# _5, _7
	subl	%edx, %eax	# tmp448, _7
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cltq
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cmpq	$65535, %rax	#, maxbase_97
	seta	211(%rsp)	#, %sfp
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	cmpl	$4096, %edi	#, page
	setne	%r9b	#, tmp454
	addl	$1, %r9d	#, tmp454
	movb	%r9b, 219(%rsp)	# tmp454, %sfp
.L329:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	$0, 60(%rsp)	#, %sfp
	movl	172(%rsp), %r15d	# %sfp, en
	movl	%ebx, 220(%rsp)	# _5, %sfp
	movl	%ebp, 224(%rsp)	# ivtmp_340, %sfp
	movl	%r12d, 228(%rsp)	# _416, %sfp
.L325:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	36(%rsp), %r9d	# %sfp, n
	testl	%r9d, %r9d	# n
	jle	.L288	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	72(%rsp), %r10d	# %sfp, stride
	movl	56(%rsp), %r8d	# %sfp, page
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	xorl	%ecx, %ecx	# ivtmp.357
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	xorl	%edi, %edi	# i
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	xorl	%esi, %esi	# maxdelta
	.p2align 5
	.p2align 4
	.p2align 3
.L289:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	%ecx, %eax	# ivtmp.357, tmp343
	cltd
	idivl	%r8d	# page
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cmpl	%edx, %esi	# _9, maxdelta
	cmovb	%edx, %esi	# maxdelta,, _9, maxdelta
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	addl	$1, %edi	#, i
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	addl	%r10d, %ecx	# stride, ivtmp.357
	cmpl	%r9d, %edi	# n, i
	jne	.L289	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cmpl	$4095, %esi	#, maxdelta
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	$2, %eax	#, tmp347
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	$24, %esi	#,
	movq	176(%rsp), %rdi	# %sfp,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	seta	%cl	#, _11
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	orb	211(%rsp), %cl	# %sfp, _12
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	$1, %ebx	#, blocks
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	sall	%cl, %eax	# _12, tmp347
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	%ecx, %ebp	# _12, _190
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	%eax, %r12d	# tmp347, w
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	call	calloc@PLT	#
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%r13, %rsi	# len,
	movl	$1, %edi	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%rax, 16(%rsp)	# table, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	call	calloc@PLT	#
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%r13, %rsi	# len,
	movl	$1, %edi	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%rax, 8(%rsp)	# m, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	call	calloc@PLT	#
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	$1, %edi	#,
	movq	%r13, %rsi	# len,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%rax, 40(%rsp)	# init, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	call	calloc@PLT	#
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	16(%rsp), %r8	# %sfp, table
	movl	36(%rsp), %r11d	# %sfp, n
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	$1, %edi	#, i
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%rax, 48(%rsp)	# expected, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	72(%rsp), %r14d	# %sfp, stride
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	xorl	%ecx, %ecx	# ivtmp.353
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	56(%rsp), %r9d	# %sfp, page
	.p2align 6
	.p2align 4
	.p2align 3
.L290:
	movl	%ecx, %esi	# ivtmp.353, ivtmp.353
	addl	%r14d, %ecx	# stride, ivtmp.353
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	%ecx, %eax	# ivtmp.353, _14
	cltd
	idivl	%r9d	# page
	movl	%eax, %r10d	# _14, _14
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	%esi, %eax	# ivtmp.353, ivtmp.353
	cltd
	idivl	%r9d	# page
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cmpl	%eax, %r10d	# _17, _14
	setne	%al	#, tmp469
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	addl	$1, %edi	#, i
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movzbl	%al, %eax	# tmp469, tmp469
	addl	%eax, %ebx	# tmp469, blocks
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cmpl	%r11d, %edi	# n, i
	jne	.L290	#,
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movl	%ebx, %esi	# blocks, _421
	movzbl	%bh, %ebx	# blocks, _423
.L334:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movdqa	192(%rsp), %xmm3	# %sfp, _255
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	8(%rsp), %rax	# %sfp, m
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movaps	%xmm3, 288(%rsp)	# _255, MEM <vector(2) long unsigned int> [(long unsigned int *)&sizes]
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%rax, 272(%rsp)	# m, base[0]
	movq	%rax, 280(%rsp)	# m, base[1]
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	testl	%r15d, %r15d	# en
	jne	.L294	#,
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movb	%bpl, (%r8)	# _190, *table_63
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	leaq	1(%r8), %rcx	#, _426
	movl	$1, %eax	#, prephitmp_425
	xorl	%edx, %edx	# iftmp.52_324
.L295:
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movzbl	219(%rsp), %edi	# %sfp, tmp454
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	36(%rsp), %ebp	# %sfp,
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movb	$0, (%rcx)	#, *prephitmp_427
	movb	%dil, 2(%r8,%rdx)	# tmp454, *_355
	movb	$0, 2(%r8,%rax)	#, *_367
	movb	$32, 4(%r8,%rdx)	#, *_331
	movb	$0, 4(%r8,%rax)	#, *_343
	movb	%sil, 6(%r8,%rdx)	# _421, *_101
	movb	%bl, 6(%r8,%rax)	# _423, *_319
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	leal	0(,%r12,8), %eax	#, _453
	movl	%eax, 76(%rsp)	# _453, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	testl	%ebp, %ebp	#
	jle	.L336	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	subl	$4, %eax	#, _35
	movl	%r15d, 24(%rsp)	# en, %sfp
	movl	72(%rsp), %r9d	# %sfp, stride
	leal	-1(%r12), %ebp	#, _86
	movl	%eax, 144(%rsp)	# _35, %sfp
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movslq	%r12d, %rax	# w, _428
	leaq	8(%r8), %rsi	#, p
	movq	%rax, 16(%rsp)	# _428, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movslq	56(%rsp), %rax	# %sfp, _429
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	$0, 148(%rsp)	#, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%rax, 160(%rsp)	# _429, %sfp
	movq	%r8, 232(%rsp)	# table, %sfp
	movq	%r13, 104(%rsp)	# len, %sfp
	movq	184(%rsp), %r13	# %sfp, _2
	.p2align 4
	.p2align 3
.L315:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	148(%rsp), %eax	# %sfp, i
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	56(%rsp), %r8d	# %sfp, page
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	36(%rsp), %ebx	# %sfp, n
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	leal	1(%rax), %r10d	#, j
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	imull	%r9d, %eax	# stride, _20
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cltd
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movslq	%eax, %r14	# _20,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	idivl	%r8d	# page
	movl	%r14d, %edi	# _20, _22
	subl	%edx, %edi	# tmp365, _22
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movslq	%edi, %rdi	# _22, idx
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cmpl	%ebx, %r10d	# n, j
	jge	.L337	#,
	movq	160(%rsp), %r11	# %sfp, _429
	leal	(%r14,%r9), %ecx	#, ivtmp.348
	jmp	.L298	#
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L299:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	addl	$1, %r10d	#, j
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	addl	%r9d, %ecx	# stride, ivtmp.348
	cmpl	%ebx, %r10d	# n, j
	je	.L356	#,
.L298:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	%ecx, %eax	# ivtmp.348, _24
	cltd
	idivl	%r8d	# page
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cltq
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	imulq	%r11, %rax	# _429, _27
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cmpq	%rdi, %rax	# idx, _27
	je	.L299	#,
.L356:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	%r10d, %r8d	# j, _431
	subl	148(%rsp), %r8d	# %sfp, _431
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movslq	%r8d, %r8	# _431, _434
.L297:
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movl	24(%rsp), %ebx	# %sfp,
	movq	%rdi, %rcx	# idx, _485
	xorl	%edx, %edx	# i
	xorl	%r11d, %r11d	# _482
	xorl	%eax, %eax	# i
	testl	%ebx, %ebx	#
	je	.L301	#,
.L302:
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movl	%ebp, %eax	# _86, _18
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	addl	$1, %edx	#, i
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	subl	%r11d, %eax	# _482, _18
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	cltq
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movb	%cl, (%rsi,%rax)	# _485, *_476
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	cmpl	%edx, %r12d	# i, w
	je	.L300	#,
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	leal	0(,%rdx,8), %ecx	#, _483
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movq	%rdi, %rax	# idx, _485
	movl	%edx, %r11d	# i, _482
	shrq	%cl, %rax	# _483, _485
	movq	%rax, %rcx	# _485, _485
	jmp	.L302	#
	.p2align 6
	.p2align 4,,10
	.p2align 3
.L301:
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movslq	%eax, %rdx	# i, iftmp.52_394
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movq	%rdi, %rbx	# idx, _180
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movb	%cl, (%rsi,%rdx)	# _363, *_392
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	leal	1(%rax), %ecx	#, i
	addl	$2, %eax	#, i_129
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movslq	%ecx, %rdx	# i, iftmp.52_347
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	sall	$3, %ecx	#, _61
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	shrq	%cl, %rbx	# _61, _180
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movb	%bl, (%rsi,%rdx)	# _180, *_175
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	cmpl	%eax, %r12d	# i_129, w
	je	.L300	#,
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movq	%rdi, %rcx	# idx, _363
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movl	$2, %eax	#, i
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	shrq	$16, %rcx	#, _363
	jmp	.L301	#
	.p2align 4,,10
	.p2align 3
.L300:
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movl	24(%rsp), %r11d	# %sfp,
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	addq	16(%rsp), %rsi	# %sfp, _252
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	testl	%r11d, %r11d	#
	jne	.L339	#,
	xorl	%eax, %eax	# i
	movq	%r8, %rcx	# _434, _494
.L306:
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movslq	%eax, %rdx	# i, iftmp.52_144
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movq	%r8, %rbx	# _434, _230
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movb	%cl, (%rsi,%rdx)	# _494, *_240
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	leal	1(%rax), %ecx	#, i
	addl	$2, %eax	#, i_464
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movslq	%ecx, %rdx	# i, iftmp.52_460
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	sall	$3, %ecx	#, _44
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	shrq	%cl, %rbx	# _44, _230
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movb	%bl, (%rsi,%rdx)	# _230, *_461
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	cmpl	%eax, %r12d	# i_464, w
	je	.L305	#,
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movq	%r8, %rcx	# _434, _494
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movl	$2, %eax	#, i
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	shrq	$16, %rcx	#, _494
	jmp	.L306	#
	.p2align 4,,10
	.p2align 3
.L339:
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movq	%r8, %rcx	# _434, _51
	xorl	%eax, %eax	# i
	xorl	%r11d, %r11d	# _200
	jmp	.L303	#
	.p2align 6
	.p2align 4,,10
	.p2align 3
.L357:
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	leal	0(,%rax,8), %ecx	#, _58
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movq	%r8, %rbx	# _434, _51
	movl	%eax, %r11d	# i, _200
	shrq	%cl, %rbx	# _58, _51
	movq	%rbx, %rcx	# _51, _51
.L303:
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movl	%ebp, %edx	# _86, _53
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	addl	$1, %eax	#, i
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	subl	%r11d, %edx	# _200, _53
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movslq	%edx, %rdx	# _53, iftmp.52_47
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movb	%cl, (%rsi,%rdx)	# _51, *_439
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	cmpl	%r12d, %eax	# w, i
	jne	.L357	#,
.L305:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	148(%rsp), %eax	# %sfp, i
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	addq	16(%rsp), %rsi	# %sfp, p
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cmpl	%eax, %r10d	# i, j
	jle	.L307	#,
	movq	40(%rsp), %rcx	# %sfp, init
	movslq	%eax, %rdx	# i, ivtmp.327
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	60(%rsp), %ebx	# %sfp, _436
	movl	%r10d, 32(%rsp)	# j, %sfp
	movq	8(%rsp), %rax	# %sfp, m
	movq	%rsi, 152(%rsp)	# p, %sfp
	xorl	$1, %ebx	#, _436
	movl	%r9d, 168(%rsp)	# stride, %sfp
	movq	%r13, %r9	# _2, _2
	leaq	(%rcx,%r14), %r13	#, ivtmp.323
	leaq	1(%rax,%rdx), %r8	#, ivtmp.328
	leaq	(%rcx,%rdi), %rax	#, _62
	movl	%ebx, 64(%rsp)	# _436, %sfp
	movq	48(%rsp), %rbx	# %sfp, expected
	movq	%rax, 96(%rsp)	# _62, %sfp
	leaq	(%rbx,%r14), %r15	#, ivtmp.324
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movq	%rsi, %rbx	# p, _266
	.p2align 4
	.p2align 3
.L314:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	%edx, %edi	# ivtmp.327, _125
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movzbl	144(%rsp), %ecx	# %sfp, tmp710
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movl	24(%rsp), %r10d	# %sfp,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%r13, %rsi	# ivtmp.323, _32
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	andl	$1, %edi	#, _125
	orl	64(%rsp), %edi	# %sfp, _307
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	subq	96(%rsp), %rsi	# %sfp, _32
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movslq	%edi, %rax	# _307, _33
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	salq	%cl, %rax	# tmp710, _36
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	orq	%rax, %rsi	# _36, _37
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	testl	%r10d, %r10d	#
	jne	.L340	#,
	xorl	%eax, %eax	# i
	movq	%rsi, %r10	# _37, _501
.L311:
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movslq	%eax, %rcx	# i, iftmp.52_1
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movq	%rsi, %r11	# _37, _227
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movb	%r10b, (%rbx,%rcx)	# _501, *_134
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	leal	1(%rax), %ecx	#, i
	addl	$2, %eax	#, i_292
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movslq	%ecx, %r10	# i, iftmp.52_320
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	sall	$3, %ecx	#, _388
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	shrq	%cl, %r11	# _388, _227
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movb	%r11b, (%rbx,%r10)	# _227, *_438
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	cmpl	%eax, %r12d	# i_292, w
	je	.L310	#,
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movq	%rsi, %r10	# _37, _501
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movl	$2, %eax	#, i
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	shrq	$16, %r10	#, _501
	jmp	.L311	#
	.p2align 4,,10
	.p2align 3
.L340:
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movq	%rsi, %r11	# _37, _192
	xorl	%eax, %eax	# i
	xorl	%r10d, %r10d	# _203
	jmp	.L308	#
	.p2align 6
	.p2align 4,,10
	.p2align 3
.L358:
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	leal	0(,%rax,8), %ecx	#, _243
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movq	%rsi, %r11	# _37, _192
	movl	%eax, %r10d	# i, _203
	shrq	%cl, %r11	# _243, _192
.L308:
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movl	%ebp, %ecx	# _86, _264
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	addl	$1, %eax	#, i
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	subl	%r10d, %ecx	# _203, _264
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movslq	%ecx, %rcx	# _264, iftmp.52_173
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movb	%r11b, (%rbx,%rcx)	# _192, *_174
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	cmpl	%eax, %r12d	# i, w
	jne	.L358	#,
.L310:
	leaq	1(%rdx), %r10	#, _248
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%r8, 256(%rsp)	# ivtmp.328, MEM[(long unsigned int *)_191]
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	addq	16(%rsp), %rbx	# %sfp, _266
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%r10, 248(%rsp)	# _248, a
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	testl	%edi, %edi	# _307
	je	.L312	#,
	movq	104(%rsp), %rax	# %sfp, len
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movl	$8, %edx	#,
	movq	%r13, %rdi	# ivtmp.323,
	movq	%r10, 120(%rsp)	# _248, %sfp
	leaq	248(%rsp), %rsi	#, tmp409
	movq	%r8, 136(%rsp)	# ivtmp.328, %sfp
	cmpq	%r14, %rax	# ivtmp.322, len
	movq	%rax, %rcx	# len, _223
	movq	%r9, 128(%rsp)	# _2, %sfp
	cmovb	%r14, %rcx	# _223,, ivtmp.322, _223
	subq	%r14, %rcx	# ivtmp.322, _302
	movq	%rcx, 112(%rsp)	# _302, %sfp
	call	__memcpy_chk@PLT	#
	movq	112(%rsp), %rcx	# %sfp, _302
	movq	(%rsp), %rsi	# %sfp,
	movq	%r15, %rdi	# ivtmp.324,
	movl	$8, %edx	#,
	call	__memcpy_chk@PLT	#
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movq	120(%rsp), %r10	# %sfp, _248
	movq	128(%rsp), %r9	# %sfp, _2
	movq	136(%rsp), %r8	# %sfp, ivtmp.328
.L313:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	addq	%r9, %r14	# _2, ivtmp.322
	addq	%r9, %r13	# _2, ivtmp.323
	addq	%r9, %r15	# _2, ivtmp.324
	addq	$1, %r8	#, ivtmp.328
	cmpl	%r10d, 32(%rsp)	# _248, %sfp
	jle	.L359	#,
	movq	%r10, %rdx	# _248, ivtmp.327
	jmp	.L314	#
	.p2align 4,,10
	.p2align 3
.L312:
	movq	104(%rsp), %rax	# %sfp, len
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	addl	$1, %edx	#, tmp411
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movq	%r13, %rdi	# ivtmp.323,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%r8, 120(%rsp)	# ivtmp.328, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	%edx, 240(%rsp)	# tmp411, aa
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	leaq	240(%rsp), %rsi	#, tmp413
	movl	$4, %edx	#,
	cmpq	%r14, %rax	# ivtmp.322, len
	movq	%rax, %rcx	# len, _451
	movq	%r9, 136(%rsp)	# _2, %sfp
	cmovb	%r14, %rcx	# _451,, ivtmp.322, _451
	movq	%r10, 128(%rsp)	# _248, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	%r8d, 244(%rsp)	# ivtmp.328, vv
	subq	%r14, %rcx	# ivtmp.322, _195
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movq	%rcx, 112(%rsp)	# _195, %sfp
	call	__memcpy_chk@PLT	#
	movq	112(%rsp), %rcx	# %sfp, _195
	movl	$4, %edx	#,
	movq	%r15, %rdi	# ivtmp.324,
	leaq	244(%rsp), %rsi	#, tmp414
	call	__memcpy_chk@PLT	#
	movq	136(%rsp), %r9	# %sfp, _2
	movq	120(%rsp), %r8	# %sfp, ivtmp.328
	movq	128(%rsp), %r10	# %sfp, _248
	jmp	.L313	#
	.p2align 4,,10
	.p2align 3
.L359:
	movl	32(%rsp), %r10d	# %sfp, j
	movq	16(%rsp), %rdi	# %sfp, _428
	movq	%r9, %r13	# _2, _2
	movq	152(%rsp), %rsi	# %sfp, p
	movl	168(%rsp), %r9d	# %sfp, stride
	movl	%r10d, %eax	# j, _459
	subl	148(%rsp), %eax	# %sfp, _459
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	%r10d, 148(%rsp)	# j, %sfp
	subl	$1, %eax	#, _368
	leaq	(%rsi,%rdi), %rdx	#, _380
	imulq	%rdi, %rax	# _428, _366
	leaq	(%rax,%rdx), %rsi	#, p
.L307:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	148(%rsp), %ebx	# %sfp, i
	cmpl	%ebx, 36(%rsp)	# i, %sfp
	jg	.L315	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	232(%rsp), %r8	# %sfp, table
	movq	%rsi, %r9	# p, p
	movq	104(%rsp), %r13	# %sfp, len
	movl	24(%rsp), %r15d	# %sfp, en
	subq	%r8, %r9	# table, p
	movq	%r9, 16(%rsp)	# p, %sfp
.L296:
	movq	%r8, 64(%rsp)	# table, %sfp
	xorl	%r14d, %r14d	# rep
	jmp	.L316	#
	.p2align 4,,10
	.p2align 3
.L360:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	subq	$8, %rsp	#,
	.cfi_def_cfa_offset 392
	movl	%r15d, %edx	# en,
	movl	$2, %r9d	#,
	pushq	$0	#
	.cfi_def_cfa_offset 400
	movq	96(%rsp), %rcx	# %sfp,
	movq	104(%rsp), %r8	# %sfp,
	movq	32(%rsp), %rsi	# %sfp,
	movq	80(%rsp), %rdi	# %sfp,
	call	process_reloc_section	#
	popq	%rdx	#
	.cfi_def_cfa_offset 392
	popq	%rsi	#
	.cfi_def_cfa_offset 384
	movl	%eax, %ecx	# rc, rc
.L318:
# bench.c:6: static uint64_t now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000+t.tv_nsec;}
	movq	(%rsp), %rsi	# %sfp,
	movl	$1, %edi	#,
	movl	%ecx, 32(%rsp)	# rc, %sfp
	call	clock_gettime@PLT	#
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	32(%rsp), %eax	# %sfp,
# bench.c:6: static uint64_t now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000+t.tv_nsec;}
	imulq	$1000000000, 256(%rsp), %rdx	#, MEM[(struct timespec *)_191].tv_sec, _275
	subq	%r12, %rdx	# _271, _376
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	addq	264(%rsp), %rdx	# MEM[(struct timespec *)_191].tv_nsec, _376
	movq	%rdx, %r12	# _376, _71
	subq	24(%rsp), %r12	# %sfp, elapsed
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	testl	%eax, %eax	#
	jne	.L319	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	48(%rsp), %rsi	# %sfp,
	movq	8(%rsp), %rdi	# %sfp,
	movq	%r13, %rdx	# len,
	call	memcmp@PLT	#
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	testl	%eax, %eax	# tmp493
	jne	.L319	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	testq	%r12, %r12	# elapsed
	js	.L321	#,
	pxor	%xmm0, %xmm0	# _55
	cvtsi2sdq	%r12, %xmm0	# elapsed, _55
.L322:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	36(%rsp), %edx	# %sfp, n
	pxor	%xmm1, %xmm1	# _56
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:118:   return __printf_chk (__USE_FORTIFY_LEVEL - 1, __fmt, __va_arg_pack ());
	subq	$8, %rsp	#,
	.cfi_def_cfa_offset 392
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	addl	$1, %ebx	#, ivtmp.300
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:118:   return __printf_chk (__USE_FORTIFY_LEVEL - 1, __fmt, __va_arg_pack ());
	pushq	24(%rsp)	# %sfp
	.cfi_def_cfa_offset 400
	leaq	.LC22(%rip), %rsi	#,
	movl	$2, %edi	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cvtsi2sdl	%edx, %xmm1	# n, _56
	divsd	%xmm1, %xmm0	# _56, _57
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:118:   return __printf_chk (__USE_FORTIFY_LEVEL - 1, __fmt, __va_arg_pack ());
	pushq	%rbp	# _458
	.cfi_def_cfa_offset 408
	pushq	%r14	# rep
	.cfi_def_cfa_offset 416
	movl	92(%rsp), %eax	# %sfp, mix
	pushq	%rax	# mix
	.cfi_def_cfa_offset 424
	movl	$1, %eax	#,
	pushq	%r15	# en
	.cfi_def_cfa_offset 432
	movl	124(%rsp), %r9d	# %sfp,
	movl	104(%rsp), %r8d	# %sfp,
	movl	120(%rsp), %ecx	# %sfp,
	call	__printf_chk@PLT	#
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	leal	2(%r14), %eax	#, _339
	addq	$48, %rsp	#,
	.cfi_def_cfa_offset 384
	cmpl	%ebx, %eax	# ivtmp.300, _339
	jne	.L323	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	addl	$1, %r14d	#, rep
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cmpl	$101, %r14d	#, rep
	je	.L324	#,
.L316:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	%r14d, %ebx	# rep, ivtmp.300
.L323:
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movq	40(%rsp), %rsi	# %sfp,
	movq	8(%rsp), %rdi	# %sfp,
	movq	%r13, %rcx	# len,
	movq	%r13, %rdx	# len,
	movl	%ebx, %ebp	# ivtmp.300, _458
	call	__memcpy_chk@PLT	#
# bench.c:6: static uint64_t now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000+t.tv_nsec;}
	movq	(%rsp), %rsi	# %sfp,
	movl	$1, %edi	#,
	andl	$1, %ebp	#, _458
	call	clock_gettime@PLT	#
# bench.c:6: static uint64_t now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000+t.tv_nsec;}
	movq	264(%rsp), %r12	# MEM[(struct timespec *)_191].tv_nsec, _271
# bench.c:6: static uint64_t now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000+t.tv_nsec;}
	imulq	$1000000000, 256(%rsp), %rax	#, MEM[(struct timespec *)_191].tv_sec, _269
	movq	%rax, 24(%rsp)	# _269, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	testl	%ebp, %ebp	# _458
	jne	.L360	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	80(%rsp), %rcx	# %sfp,
	movq	88(%rsp), %r8	# %sfp,
	movl	%r15d, %edx	# en,
	movq	16(%rsp), %rsi	# %sfp,
	movq	64(%rsp), %rdi	# %sfp,
	call	generic.constprop.0	#
	movl	%eax, %ecx	# rc, rc
	jmp	.L318	#
	.p2align 4,,10
	.p2align 3
.L321:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%r12, %rax	# elapsed, tmp437
	andl	$1, %r12d	#, tmp438
	pxor	%xmm0, %xmm0	# tmp436
	shrq	%rax	# tmp437
	orq	%r12, %rax	# tmp438, tmp437
	cvtsi2sdq	%rax, %xmm0	# tmp437, tmp436
	addsd	%xmm0, %xmm0	# tmp436, _55
	jmp	.L322	#
.L324:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	64(%rsp), %rdi	# %sfp,
	call	free@PLT	#
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	8(%rsp), %rdi	# %sfp,
	call	free@PLT	#
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	40(%rsp), %rdi	# %sfp,
	call	free@PLT	#
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	48(%rsp), %rdi	# %sfp,
	call	free@PLT	#
	movl	60(%rsp), %eax	# %sfp, mix
	movl	$1, 60(%rsp)	#, %sfp
	addl	$1, %eax	#, mix
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cmpl	$2, %eax	#, _456
	jne	.L325	#,
	movl	172(%rsp), %eax	# %sfp, en
	movl	220(%rsp), %ebx	# %sfp, _5
	movl	$1, 172(%rsp)	#, %sfp
	movl	224(%rsp), %ebp	# %sfp, ivtmp_340
	movl	228(%rsp), %r12d	# %sfp, _416
	addl	$1, %eax	#, en
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cmpl	$2, %eax	#, _310
	jne	.L329	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	56(%rsp), %eax	# %sfp, page
	movl	212(%rsp), %r14d	# %sfp, ivtmp_342
	cmpl	$512, %eax	#, page
	je	.L342	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	sall	$2, %eax	#, page
	movl	%eax, 56(%rsp)	# page, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cmpl	$16384, %eax	#, page
	jle	.L331	#,
	movq	176(%rsp), %r11	# %sfp, _415
	movl	%r12d, %ebx	# _416, _416
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	sall	$3, 72(%rsp)	#, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	subl	$1, %r14d	#, ivtmp_342
	jne	.L333	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	sall	$2, 36(%rsp)	#, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	subl	$1, %ebp	#, ivtmp_340
	jne	.L287	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	312(%rsp), %rax	# D.6110, tmp498
	subq	%fs:40, %rax	# MEM[(<address-space-1> long unsigned int *)40B], tmp498
	jne	.L361	#,
	addq	$328, %rsp	#,
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	xorl	%eax, %eax	#
	popq	%rbx	#
	.cfi_def_cfa_offset 48
	popq	%rbp	#
	.cfi_def_cfa_offset 40
	popq	%r12	#
	.cfi_def_cfa_offset 32
	popq	%r13	#
	.cfi_def_cfa_offset 24
	popq	%r14	#
	.cfi_def_cfa_offset 16
	popq	%r15	#
	.cfi_def_cfa_offset 8
	ret	
.L294:
	.cfi_restore_state
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movb	%bpl, 1(%r8)	# _190, MEM[(uint8_t *)table_63 + 1B]
	movq	%r8, %rcx	# table, _426
	xorl	%eax, %eax	# prephitmp_425
	movl	$1, %edx	#, iftmp.52_324
	jmp	.L295	#
.L337:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	$1, %r8d	#, _434
	jmp	.L297	#
.L336:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	$8, 16(%rsp)	#, %sfp
	jmp	.L296	#
.L288:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movzbl	211(%rsp), %ecx	# %sfp, _10
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	176(%rsp), %rdi	# %sfp,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	$2, %eax	#, tmp458
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	xorl	%ebx, %ebx	# _423
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	$24, %esi	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	sall	%cl, %eax	# _10, tmp458
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	%ecx, %ebp	# _10, _190
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	%eax, %r12d	# tmp458, w
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	call	calloc@PLT	#
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%r13, %rsi	# len,
	movl	$1, %edi	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%rax, 16(%rsp)	# table, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	call	calloc@PLT	#
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%r13, %rsi	# len,
	movl	$1, %edi	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%rax, 8(%rsp)	# m, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	call	calloc@PLT	#
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%r13, %rsi	# len,
	movl	$1, %edi	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%rax, 40(%rsp)	# init, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	call	calloc@PLT	#
	movq	16(%rsp), %r8	# %sfp, table
	xorl	%esi, %esi	# _421
	movq	%rax, 48(%rsp)	# expected, %sfp
	jmp	.L334	#
.L342:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	$4096, 56(%rsp)	#, %sfp
	jmp	.L331	#
.L361:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	call	__stack_chk_fail@PLT	#
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.type	main.cold, @function
main.cold:
.LFSB67:
.L319:
	.cfi_def_cfa_offset 384
	.cfi_offset 3, -56
	.cfi_offset 6, -48
	.cfi_offset 12, -40
	.cfi_offset 13, -32
	.cfi_offset 14, -24
	.cfi_offset 15, -16
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx	#,
	movl	$11, %edx	#,
	leaq	.LC20(%rip), %rsi	#,
	leaq	.LC21(%rip), %rdi	#,
	call	__assert_fail@PLT	#
	.cfi_endproc
.LFE67:
	.section	.text.startup
	.size	main, .-main
	.section	.text.unlikely
	.size	main.cold, .-main.cold
.LCOLDE23:
	.section	.text.startup
.LHOTE23:
	.section	.rodata
	.type	__PRETTY_FUNCTION__.0, @object
	.size	__PRETTY_FUNCTION__.0, 5
__PRETTY_FUNCTION__.0:
	.string	"main"
	.ident	"GCC: (Ubuntu 15.2.0-16ubuntu1) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
	.section	.note.gnu.property,"a"
	.align 8
	.long	1f - 0f
	.long	4f - 1f
	.long	5
0:
	.string	"GNU"
1:
	.align 8
	.long	0xc0000002
	.long	3f - 2f
2:
	.long	0x3
3:
	.align 8
4:
