	.file	"bench.c"
# GNU C23 (Ubuntu 15.2.0-16ubuntu1) version 15.2.0 (x86_64-linux-gnu)
#	compiled by GNU C version 15.2.0, GMP version 6.3.0, MPFR version 4.2.2, MPC version 1.3.1, isl version isl-0.27-GMP

# GGC heuristics: --param ggc-min-expand=100 --param ggc-min-heapsize=131072
# options passed: -D_FORTIFY_SOURCE=3 -mtune=generic -march=x86-64 -O3 -fasynchronous-unwind-tables -fstack-protector-strong -fstack-clash-protection -fcf-protection -fzero-init-padding-bits=all
	.text
	.p2align 4
	.type	generic.constprop.0, @function
generic.constprop.0:
.LFB68:
	.cfi_startproc
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	cmpq	$7, %rsi	#, len
	jbe	.L69	#,
	movl	%edx, %r11d	# en, en
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	pushq	%r15	#
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	movq	%rcx, %r9	# base, base
	pushq	%r14	#
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	movq	%rsi, %r14	# len, len
	pushq	%r13	#
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12	#
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp	#
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx	#
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movzwl	(%rdi), %ecx	# MEM <unsigned short> [(char * {ref-all})p_2(D)], _3
	movzwl	2(%rdi), %edx	# MEM <unsigned short> [(char * {ref-all})p_2(D) + 2B], pretmp_313
	movzwl	6(%rdi), %ebx	# MEM <unsigned short> [(char * {ref-all})p_2(D) + 6B], _24
	movzwl	4(%rdi), %eax	# MEM <unsigned short> [(char * {ref-all})p_2(D) + 4B], _26
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	testl	%r11d, %r11d	# en
	jne	.L4	#,
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movzwl	%cx, %r13d	# _3, fmt
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movzwl	%dx, %ecx	# pretmp_313, design
.L5:
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movl	%eax, %edx	# _26, _29
	movl	%eax, %esi	# _26, _27
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	andl	$31, %eax	#, target_28
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	shrl	$5, %edx	#, _29
	andl	$31, %esi	#, _27
	andl	$31, %edx	#,
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	cmpl	%edx, %eax	# _30, target_28
	cmovl	%edx, %eax	# target_28,, _30, _32
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	cmpl	$1, %eax	#, _32
	jg	.L6	#,
	cmpl	$2, %r13d	#, fmt
	ja	.L6	#,
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	subl	$1, %ecx	#, _35
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	cmpl	$1, %ecx	#, _35
	ja	.L6	#,
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movzwl	%bx, %eax	# _24, blocks
	movl	%eax, -32(%rsp)	# blocks, %sfp
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	testl	%eax, %eax	# blocks
	je	.L46	#,
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movzwl	%si, %eax	# _27, _41
# loader.c:56:     unsigned long source_base = (unsigned long)local_base[source];
	leaq	(%r9,%rdx,8), %r10	#, _125
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	leaq	8(%rdi), %rsi	#, p
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	subq	$8, %r14	#, len
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	leaq	0(,%rax,8), %r15	#, _42
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movq	(%r8,%rax,8), %rax	# *_44, target_size
	movq	%rax, -40(%rsp)	# target_size, %sfp
	testl	%r13d, %r13d	# fmt
	je	.L8	#,
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movl	%r13d, %ecx	# fmt, tmp355
	movl	$2, %eax	#, tmp236
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movq	$-1, %rdi	#, tmp240
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movl	$0, -28(%rsp)	#, %sfp
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	sall	%cl, %eax	# tmp355, w
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movl	%r11d, -44(%rsp)	# en, %sfp
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	leal	-4(,%rax,8), %ebx	#, shift
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movl	%ebx, %ecx	# shift, tmp306
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movl	%ebx, -48(%rsp)	# shift, %sfp
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	negl	%ecx	# tmp306
	shrq	%cl, %rdi	# tmp306, tmp240
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	leal	(%rax,%rax), %ecx	#, _49
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movq	%rdi, %r11	# mask, mask
.L31:
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	cmpq	%rcx, %r14	# _49, len
	jb	.L6	#,
# bench.c:8: static uint64_t readw(const uint8_t *p,unsigned w,unsigned en){switch(w){case 2:return rd16(p,en);case 4:return rd32(p,en);default:return rd64(p,en);}}
	cmpl	$1, %r13d	#, fmt
	je	.L10	#,
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movq	(%rsi), %rbx	# MEM <unsigned long> [(char * {ref-all})p_299], _270
# loader.c:51:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap64(v);
	movl	-44(%rsp), %eax	# %sfp,
# loader.c:51:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap64(v);
	movl	$8, %ebp	#, _271
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movq	8(%rsi), %r8	# MEM <unsigned long> [(char * {ref-all})p_299 + 8B], _272
# loader.c:51:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap64(v);
	testl	%eax, %eax	#
# loader.c:51:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap64(v);
	movq	%rbx, %rax	# _270, tmp282
	bswap	%rax		# tmp282
	cmovne	%rax, %rbx	# _270,, tmp282, _270
	movq	%r8, %rax	# _272, tmp284
	bswap	%rax		# tmp284
	cmovne	%rax, %r8	# _272,, tmp284, _272
.L11:
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	subq	%rcx, %r14	# _49, len
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	xorl	%edx, %edx	# tmp244
	movq	%r14, %rax	# len, _268
	divq	%rbp	# _271
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	cmpq	%r8, %rax	# _272, _268
	jb	.L6	#,
	movq	-40(%rsp), %rax	# %sfp, target_size
	cmpq	%rbx, %rax	# _270, target_size
	jb	.L6	#,
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	leaq	(%rsi,%rcx), %rdx	#, p
	movq	%rdx, %rsi	# p, p
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	testq	%r8, %r8	# _272
	je	.L16	#,
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	subq	%rbx, %rax	# _270, _254
	movq	%r14, -24(%rsp)	# len, %sfp
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	xorl	%edi, %edi	# e
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movq	%rcx, -16(%rsp)	# _49, %sfp
	movq	%rax, %r12	# _254, _254
	movq	%rdx, -8(%rsp)	# p, %sfp
	jmp	.L24	#
	.p2align 4,,10
	.p2align 3
.L19:
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	ja	.L6	#,
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	andq	%r11, %rax	# mask, delta
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movl	$4, %ecx	#, bytes
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	cmpq	%rax, %r12	# delta, _254
	jb	.L6	#,
.L73:
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movq	%r12, %r14	# _254, _253
	subq	%rax, %r14	# delta, _253
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	cmpq	%rcx, %r14	# bytes, _253
	jb	.L6	#,
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	addq	%rbx, %rax	# _270, _249
# loader.c:56:     unsigned long source_base = (unsigned long)local_base[source];
	movq	(%r10), %rcx	# *_125, source_base
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	addq	%rbp, %rsi	# _271, p
# loader.c:55:     void *target_addr = (uint8_t *)local_base[target] + patch_offset;
	addq	(%r9,%r15), %rax	# *_248, target_addr
# loader.c:57:     if (type == 1) { // ABS64
	cmpl	$1, %edx	#, _258
	je	.L70	#,
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	addq	$1, %rdi	#, e
# loader.c:63:         uint32_t patched = (uint32_t)(source_base + addend);
	addl	%ecx, (%rax)	# source_base, MEM <unsigned int> [(char * {ref-all})target_addr_246]
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	cmpq	%r8, %rdi	# _272, e
	je	.L71	#,
.L24:
# bench.c:8: static uint64_t readw(const uint8_t *p,unsigned w,unsigned en){switch(w){case 2:return rd16(p,en);case 4:return rd32(p,en);default:return rd64(p,en);}}
	cmpl	$1, %r13d	#, fmt
	je	.L72	#,
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movq	(%rsi), %rax	# MEM <unsigned long> [(char * {ref-all})p_263], _231
# loader.c:51:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap64(v);
	movl	-44(%rsp), %r14d	# %sfp,
	movq	%rax, %rdx	# _231, tmp269
	testl	%r14d, %r14d	#
	bswap	%rdx		# tmp269
	cmovne	%rdx, %rax	# tmp269,, _231
.L28:
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movzbl	-48(%rsp), %ecx	# %sfp, tmp367
	movq	%rax, %rdx	# _231, _258
	shrq	%cl, %rdx	# tmp367, _258
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	cmpl	$1, %edx	#, _258
	jne	.L19	#,
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	andq	%r11, %rax	# mask, delta
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movl	$8, %ecx	#, bytes
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	cmpq	%rax, %r12	# delta, _254
	jnb	.L73	#,
	.p2align 4
	.p2align 3
.L6:
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movl	$-1, %eax	#, <retval>
.L1:
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	popq	%rbx	#
	.cfi_remember_state
	.cfi_def_cfa_offset 48
	popq	%rbp	#
	.cfi_def_cfa_offset 40
	popq	%r12	#
	.cfi_def_cfa_offset 32
	popq	%r13	#
	.cfi_def_cfa_offset 24
	popq	%r14	#
	.cfi_def_cfa_offset 16
	popq	%r15	#
	.cfi_def_cfa_offset 8
	ret	
	.p2align 4,,10
	.p2align 3
.L4:
	.cfi_restore_state
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	rolw	$8, %cx	#, _8
	rolw	$8, %dx	#, _12
	rolw	$8, %ax	#, _26
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movzwl	%cx, %r13d	# _8, fmt
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	rolw	$8, %bx	#, _24
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movzwl	%dx, %ecx	# _12, design
	jmp	.L5	#
.L76:
	addq	%r8, %r14	# p, _177
	movl	-48(%rsp), %r13d	# %sfp, fmt
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	subq	%rsi, %r14	# p, len
.L38:
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	addl	$1, %r13d	#, fmt
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	cmpl	%r13d, -32(%rsp)	# fmt, %sfp
	je	.L46	#,
.L8:
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	cmpq	$3, %r14	#, len
	jbe	.L6	#,
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movzwl	(%rsi), %edx	# MEM <unsigned short> [(char * {ref-all})p_22], _52
	movzwl	2(%rsi), %eax	# MEM <unsigned short> [(char * {ref-all})p_22 + 2B], _68
# bench.c:8: static uint64_t readw(const uint8_t *p,unsigned w,unsigned en){switch(w){case 2:return rd16(p,en);case 4:return rd32(p,en);default:return rd64(p,en);}}
	movzwl	%dx, %r12d	# _52, _108
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	testl	%r11d, %r11d	# en
	jne	.L74	#,
.L35:
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	subq	$4, %r14	#, len
# bench.c:8: static uint64_t readw(const uint8_t *p,unsigned w,unsigned en){switch(w){case 2:return rd16(p,en);case 4:return rd32(p,en);default:return rd64(p,en);}}
	movzwl	%ax, %ebp	# _68, _69
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movq	%r14, %rax	# len, _78
	shrq	%rax	# _78
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	cmpq	%rbp, %rax	# _69, _78
	jb	.L6	#,
	movq	-40(%rsp), %rax	# %sfp, target_size
	cmpq	%r12, %rax	# _108, target_size
	jb	.L6	#,
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	leaq	4(%rsi), %r8	#, p
	movq	%r8, %rsi	# p, p
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	testq	%rbp, %rbp	# _69
	je	.L38	#,
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	subq	%r12, %rax	# _108, _100
	movl	%r13d, -48(%rsp)	# fmt, %sfp
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	xorl	%ecx, %ecx	# e
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movq	%rax, %rdi	# _100, _100
	jmp	.L45	#
	.p2align 4,,10
	.p2align 3
.L77:
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	ja	.L6	#,
	movl	$4, %ebx	#, bytes
.L40:
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	andl	$4095, %eax	#, delta
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	cmpq	%rax, %rdi	# delta, _100
	jb	.L6	#,
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movq	%rdi, %r13	# _100, _101
	subq	%rax, %r13	# delta, _101
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	cmpq	%rbx, %r13	# bytes, _101
	jb	.L6	#,
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	addq	%r12, %rax	# _108, _104
# loader.c:56:     unsigned long source_base = (unsigned long)local_base[source];
	movq	(%r10), %rbx	# *_125, source_base
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	addq	$2, %rsi	#, p
# loader.c:55:     void *target_addr = (uint8_t *)local_base[target] + patch_offset;
	addq	(%r9,%r15), %rax	# *_120, target_addr
# loader.c:57:     if (type == 1) { // ABS64
	cmpq	$1, %rdx	#, _98
	je	.L75	#,
# loader.c:63:         uint32_t patched = (uint32_t)(source_base + addend);
	addl	%ebx, (%rax)	# source_base, MEM <unsigned int> [(char * {ref-all})target_addr_122]
.L44:
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	addq	$1, %rcx	#, e
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	cmpq	%rcx, %rbp	# e, _69
	je	.L76	#,
.L45:
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movzwl	(%rsi), %eax	# MEM <unsigned short> [(char * {ref-all})p_112], _82
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	movl	%eax, %edx	# _82, tmp273
	rolw	$8, %dx	#, tmp273
	testl	%r11d, %r11d	# en
	cmovne	%edx, %eax	# tmp273,, _82
# bench.c:8: static uint64_t readw(const uint8_t *p,unsigned w,unsigned en){switch(w){case 2:return rd16(p,en);case 4:return rd32(p,en);default:return rd64(p,en);}}
	movzwl	%ax, %edx	# _82, _86
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	shrq	$12, %rdx	#, _98
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	cmpq	$1, %rdx	#, _98
	jne	.L77	#,
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movl	$8, %ebx	#, bytes
	jmp	.L40	#
	.p2align 4,,10
	.p2align 3
.L72:
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movl	(%rsi), %edx	# MEM <unsigned int> [(char * {ref-all})p_263], _228
# loader.c:47:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap32(v);
	movl	-44(%rsp), %ecx	# %sfp,
	movl	%edx, %eax	# _228, tmp271
	testl	%ecx, %ecx	#
	bswap	%eax		# tmp271
# bench.c:8: static uint64_t readw(const uint8_t *p,unsigned w,unsigned en){switch(w){case 2:return rd16(p,en);case 4:return rd32(p,en);default:return rd64(p,en);}}
	cmove	%edx, %eax	# tmp271,, _228, _231
	jmp	.L28	#
	.p2align 4,,10
	.p2align 3
.L70:
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	addq	$1, %rdi	#, e
# loader.c:59:         uint64_t patched = source_base + addend;
	addq	%rcx, (%rax)	# source_base, MEM <unsigned long> [(char * {ref-all})target_addr_246]
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	cmpq	%r8, %rdi	# _272, e
	jne	.L24	#,
.L71:
	movq	-24(%rsp), %r14	# %sfp, len
	movq	-8(%rsp), %rdx	# %sfp, p
	movq	-16(%rsp), %rcx	# %sfp, _49
	leaq	(%rdx,%r14), %rax	#, _164
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	subq	%rsi, %rax	# p, _164
	movq	%rax, %r14	# _164, len
.L16:
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	addl	$1, -28(%rsp)	#, %sfp
	movl	-28(%rsp), %eax	# %sfp, b
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	cmpl	%eax, -32(%rsp)	# b, %sfp
	jne	.L31	#,
.L46:
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	xorl	%eax, %eax	# <retval>
	jmp	.L1	#
	.p2align 4,,10
	.p2align 3
.L75:
# loader.c:59:         uint64_t patched = source_base + addend;
	addq	%rbx, (%rax)	# source_base, MEM <unsigned long> [(char * {ref-all})target_addr_122]
	jmp	.L44	#
	.p2align 4,,10
	.p2align 3
.L10:
# loader.c:47:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap32(v);
	movl	-44(%rsp), %eax	# %sfp,
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movl	(%rsi), %ebx	# MEM <unsigned int> [(char * {ref-all})p_299],
	movl	4(%rsi), %r8d	# MEM <unsigned int> [(char * {ref-all})p_299 + 4B], _285
# loader.c:47:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap32(v);
	testl	%eax, %eax	#
	je	.L14	#,
# loader.c:47:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap32(v);
	bswap	%ebx		# _287
# bench.c:8: static uint64_t readw(const uint8_t *p,unsigned w,unsigned en){switch(w){case 2:return rd16(p,en);case 4:return rd32(p,en);default:return rd64(p,en);}}
	movl	%ebx, %ebx	# _287, _270
# loader.c:47:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap32(v);
	bswap	%r8d		# _285
.L14:
# bench.c:8: static uint64_t readw(const uint8_t *p,unsigned w,unsigned en){switch(w){case 2:return rd16(p,en);case 4:return rd32(p,en);default:return rd64(p,en);}}
	movl	%r8d, %r8d	# _285, _272
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movl	$4, %ebp	#, _271
	jmp	.L11	#
.L74:
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	rolw	$8, %dx	#, _169
	rolw	$8, %ax	#, _68
# bench.c:8: static uint64_t readw(const uint8_t *p,unsigned w,unsigned en){switch(w){case 2:return rd16(p,en);case 4:return rd32(p,en);default:return rd64(p,en);}}
	movzwl	%dx, %r12d	# _169, _108
	jmp	.L35	#
.L69:
	.cfi_def_cfa_offset 8
	.cfi_restore 3
	.cfi_restore 6
	.cfi_restore 12
	.cfi_restore 13
	.cfi_restore 14
	.cfi_restore 15
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	movl	$-1, %eax	#, <retval>
# bench.c:10: __attribute__((noinline)) static int generic(const uint8_t *p,size_t len,unsigned en,void **base,const size_t *sizes,int n,int trace){if(len<8)return -1;unsigned fmt=rd16(p,en),design=rd16(p+2,en),couple=rd16(p+4,en),blocks=rd16(p+6,en);int target=couple&31,source=(couple>>5)&31;if(target>=n||source>=n||fmt>2||(design!=1&&design!=2))return -1;unsigned w=2u<<fmt,shift=8*w-4;uint64_t mask=UINT64_MAX>>(64-shift);size_t target_size=sizes[target];p+=8;len-=8;for(unsigned b=0;b<blocks;b++){if(len<2*w)return -1;uint64_t index=readw(p,w,en),count=readw(p+w,w,en);p+=2*w;len-=2*w;if(count>len/w||index>target_size)return -1;for(uint64_t e=0;e<count;e++){uint64_t v=readw(p,w,en);p+=w;len-=w;uint64_t delta=v&mask;unsigned type=v>>shift;size_t bytes=type==1?8:4;if(type>1||delta>target_size-index||bytes>target_size-index-delta)return -1;apply_reloc(base,target,source,index+delta,type,trace);}}return 0;}
	ret	
	.cfi_endproc
.LFE68:
	.size	generic.constprop.0, .-generic.constprop.0
	.section	.rodata.str1.1,"aMS",@progbits,1
.LC0:
	.string	"ABS32"
.LC1:
	.string	"ABS64"
	.section	.rodata.str1.8,"aMS",@progbits,1
	.align 8
.LC2:
	.string	"  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n"
	.text
	.p2align 4
	.type	process_blocks16, @function
process_blocks16:
.LFB58:
	.cfi_startproc
	pushq	%r15	#
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14	#
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13	#
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12	#
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp	#
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx	#
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$56, %rsp	#,
	.cfi_def_cfa_offset 112
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	movq	120(%rsp), %r12	# target_size, target_size
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	testl	%ecx, %ecx	# blocks
	je	.L111	#,
# loader.c:55:     void *target_addr = (uint8_t *)local_base[target] + patch_offset;
	movslq	%r9d, %rax	# target, _54
	movl	%ecx, 20(%rsp)	# blocks, %sfp
	leaq	(%r8,%rax,8), %r15	#, _56
# loader.c:56:     unsigned long source_base = (unsigned long)local_base[source];
	movslq	112(%rsp), %rax	# source, _59
	leaq	(%r8,%rax,8), %r14	#, _61
	testl	%edx, %edx	# endian
	jne	.L112	#,
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:118:   return __printf_chk (__USE_FORTIFY_LEVEL - 1, __fmt, __va_arg_pack ());
	movl	%r9d, 16(%rsp)	# target, %sfp
	movq	%r14, %r11	# _61, _61
	movq	%r12, %r14	# target_size, target_size
.L96:
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	cmpq	$3, %rsi	#, len
	jbe	.L101	#,
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	leaq	-4(%rsi), %rax	#, len
	movzwl	2(%rdi), %r12d	# MEM <unsigned short> [(char * {ref-all})p_123 + 2B], count
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	movzwl	(%rdi), %r13d	# MEM <unsigned short> [(char * {ref-all})p_123], index
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	movq	%rax, %rcx	# len, _107
	shrq	%rcx	# _107
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	cmpq	%r12, %rcx	# count, _107
	jb	.L101	#,
	cmpq	%r13, %r14	# index, target_size
	jb	.L101	#,
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	leaq	4(%rdi), %rbx	#, p
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	testq	%r12, %r12	# count
	je	.L113	#,
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	movq	%r12, %r10	# count, count
	movq	%rdi, 24(%rsp)	# p, %sfp
	xorl	%ebp, %ebp	# e
	movq	%r11, %r12	# _61, _61
	movq	%rsi, 32(%rsp)	# len, %sfp
	movl	%edx, 40(%rsp)	# endian, %sfp
	jmp	.L90	#
	.p2align 4,,10
	.p2align 3
.L85:
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	ja	.L101	#,
	movl	$4, %esi	#, bytes
.L95:
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	movq	%r14, %rax	# target_size, _77
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	andl	$4095, %ecx	#, delta
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	subq	%r13, %rax	# index, _77
	cmpq	%rcx, %rax	# delta, _77
	jb	.L101	#,
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	subq	%rcx, %rax	# delta, _76
	cmpq	%rsi, %rax	# bytes, _76
	jb	.L101	#,
# loader.c:55:     void *target_addr = (uint8_t *)local_base[target] + patch_offset;
	movq	(%r15), %rax	# *_56, target_addr
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	addq	%r13, %rcx	# index, _70
# loader.c:56:     unsigned long source_base = (unsigned long)local_base[source];
	movq	(%r12), %rsi	# *_61, source_base
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	addq	$2, %rbx	#, p
# loader.c:55:     void *target_addr = (uint8_t *)local_base[target] + patch_offset;
	addq	%rcx, %rax	# _70, target_addr
# loader.c:57:     if (type == 1) { // ABS64
	cmpw	$1, %dx	#, _96
	je	.L129	#,
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	movl	128(%rsp), %edi	# trace,
# loader.c:63:         uint32_t patched = (uint32_t)(source_base + addend);
	addl	%esi, (%rax)	# source_base, MEM <unsigned int> [(char * {ref-all})target_addr_16]
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	testl	%edi, %edi	#
	je	.L91	#,
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	leaq	.LC0(%rip), %r9	#, iftmp.36_6
.L92:
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:118:   return __printf_chk (__USE_FORTIFY_LEVEL - 1, __fmt, __va_arg_pack ());
	movl	112(%rsp), %r8d	# source,
	movl	16(%rsp), %edx	# %sfp,
	movl	$2, %edi	#,
	xorl	%eax, %eax	#
	leaq	.LC2(%rip), %rsi	#,
	movq	%r10, 8(%rsp)	# count, %sfp
	call	__printf_chk@PLT	#
	movq	8(%rsp), %r10	# %sfp, count
.L91:
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	addq	$1, %rbp	#, e
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	cmpq	%r10, %rbp	# count, e
	je	.L130	#,
.L90:
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movzwl	(%rbx), %ecx	# MEM <unsigned short> [(char * {ref-all})p_102], _98
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	movl	%ecx, %edx	# _98, _96
	shrw	$12, %dx	#, _96
	cmpw	$1, %dx	#, _96
	jne	.L85	#,
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	movl	$8, %esi	#, bytes
	jmp	.L95	#
	.p2align 4,,10
	.p2align 3
.L112:
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:118:   return __printf_chk (__USE_FORTIFY_LEVEL - 1, __fmt, __va_arg_pack ());
	movl	%r9d, 16(%rsp)	# target, %sfp
	xorl	%ecx, %ecx	# b
	movq	%rsi, %r8	# len, len
.L81:
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	cmpq	$3, %r8	#, len
	jbe	.L101	#,
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	movzwl	(%rdi), %eax	# MEM <unsigned short> [(char * {ref-all})p_85], _46
	rolw	$8, %ax	#, _47
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	movzwl	%ax, %r13d	# _47, index
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	movzwl	2(%rdi), %eax	# MEM <unsigned short> [(char * {ref-all})p_85 + 2B], _25
	rolw	$8, %ax	#, _23
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	movzwl	%ax, %esi	# _23, count
	leaq	-4(%r8), %rax	#, len
	movq	%rax, %rdx	# len, _2
	shrq	%rdx	# _2
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	cmpq	%rsi, %rdx	# count, _2
	jb	.L101	#,
	cmpq	%r13, %r12	# index, target_size
	jb	.L101	#,
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	leaq	4(%rdi), %rbx	#, p
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	testq	%rsi, %rsi	# count
	je	.L116	#,
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	movq	%rsi, 8(%rsp)	# count, %sfp
	xorl	%ebp, %ebp	# e
	movl	%ecx, 24(%rsp)	# b, %sfp
	movq	%rdi, 32(%rsp)	# p, %sfp
	movq	%r8, 40(%rsp)	# len, %sfp
	jmp	.L110	#
	.p2align 4,,10
	.p2align 3
.L133:
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	ja	.L101	#,
	movl	$4, %esi	#, bytes
.L103:
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	rolw	$8, %cx	#, _50
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	movq	%r12, %rdx	# target_size, _4
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	andl	$4095, %ecx	#, delta
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	subq	%r13, %rdx	# index, _4
	cmpq	%rcx, %rdx	# delta, _4
	jb	.L101	#,
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	subq	%rcx, %rdx	# delta, _5
	cmpq	%rsi, %rdx	# bytes, _5
	jb	.L101	#,
# loader.c:55:     void *target_addr = (uint8_t *)local_base[target] + patch_offset;
	movq	(%r15), %rdx	# *_56, target_addr
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	addq	%r13, %rcx	# index, _7
# loader.c:56:     unsigned long source_base = (unsigned long)local_base[source];
	movq	(%r14), %rsi	# *_61, source_base
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	addq	$2, %rbx	#, p
# loader.c:55:     void *target_addr = (uint8_t *)local_base[target] + patch_offset;
	addq	%rcx, %rdx	# _7, target_addr
# loader.c:57:     if (type == 1) { // ABS64
	cmpw	$1, %ax	#, _3
	je	.L131	#,
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	movl	128(%rsp), %eax	# trace,
# loader.c:63:         uint32_t patched = (uint32_t)(source_base + addend);
	addl	%esi, (%rdx)	# source_base, MEM <unsigned int> [(char * {ref-all})target_addr_58]
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	leaq	.LC0(%rip), %r9	#, iftmp.36_71
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	testl	%eax, %eax	#
	je	.L108	#,
.L107:
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:118:   return __printf_chk (__USE_FORTIFY_LEVEL - 1, __fmt, __va_arg_pack ());
	movl	112(%rsp), %r8d	# source,
	movl	16(%rsp), %edx	# %sfp,
	movl	$2, %edi	#,
	xorl	%eax, %eax	#
	leaq	.LC2(%rip), %rsi	#,
	call	__printf_chk@PLT	#
.L108:
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	addq	$1, %rbp	#, e
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	cmpq	%rbp, 8(%rsp)	# e, %sfp
	je	.L132	#,
.L110:
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movzwl	(%rbx), %ecx	# MEM <unsigned short> [(char * {ref-all})p_83], _48
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	movl	%ecx, %eax	# _48, _172
	shrb	$4, %al	#, _172
	movzbl	%al, %eax	# _172, _3
	cmpw	$1, %ax	#, _3
	jne	.L133	#,
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	movl	$8, %esi	#, bytes
	jmp	.L103	#
	.p2align 4,,10
	.p2align 3
.L129:
# loader.c:59:         uint64_t patched = source_base + addend;
	addq	%rsi, (%rax)	# source_base, MEM <unsigned long> [(char * {ref-all})target_addr_16]
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	movl	128(%rsp), %esi	# trace,
	testl	%esi, %esi	#
	je	.L91	#,
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	leaq	.LC1(%rip), %r9	#, iftmp.36_6
	jmp	.L92	#
	.p2align 4,,10
	.p2align 3
.L131:
# loader.c:59:         uint64_t patched = source_base + addend;
	addq	%rsi, (%rdx)	# source_base, MEM <unsigned long> [(char * {ref-all})target_addr_58]
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	movl	128(%rsp), %edx	# trace,
	testl	%edx, %edx	#
	je	.L108	#,
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	leaq	.LC1(%rip), %r9	#, iftmp.36_71
	jmp	.L107	#
	.p2align 4,,10
	.p2align 3
.L101:
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	movl	$-1, %eax	#, <retval>
.L78:
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	addq	$56, %rsp	#,
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx	#
	.cfi_def_cfa_offset 48
	popq	%rbp	#
	.cfi_def_cfa_offset 40
	popq	%r12	#
	.cfi_def_cfa_offset 32
	popq	%r13	#
	.cfi_def_cfa_offset 24
	popq	%r14	#
	.cfi_def_cfa_offset 16
	popq	%r15	#
	.cfi_def_cfa_offset 8
	ret	
	.p2align 4,,10
	.p2align 3
.L132:
	.cfi_restore_state
	movq	32(%rsp), %rdi	# %sfp, p
	addq	40(%rsp), %rdi	# %sfp, _169
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	subq	%rbx, %rdi	# p, _169
	movl	24(%rsp), %ecx	# %sfp, b
	movq	%rdi, %r8	# _169, len
	movq	%rbx, %rdi	# p, p
.L102:
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	addl	$1, %ecx	#, b
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	cmpl	%ecx, 20(%rsp)	# b, %sfp
	jne	.L81	#,
.L111:
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	xorl	%eax, %eax	# <retval>
	jmp	.L78	#
	.p2align 4,,10
	.p2align 3
.L130:
	movq	24(%rsp), %rdi	# %sfp, p
	addq	32(%rsp), %rdi	# %sfp, _174
	movq	%r12, %r11	# _61, _61
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	subq	%rbx, %rdi	# p, _174
	movl	40(%rsp), %edx	# %sfp, endian
	movq	%rdi, %rsi	# _174, len
	movq	%rbx, %rdi	# p, p
.L84:
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	addl	$1, %edx	#, endian
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	cmpl	%edx, 20(%rsp)	# endian, %sfp
	jne	.L96	#,
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	xorl	%eax, %eax	# <retval>
	jmp	.L78	#
.L113:
# loader.c:90: BLOCK_PROCESS(16, uint16_t, 12, UINT16_C(0xFFF))
	movq	%rax, %rsi	# len, len
	movq	%rbx, %rdi	# p, p
	jmp	.L84	#
.L116:
	movq	%rax, %r8	# len, len
	movq	%rbx, %rdi	# p, p
	jmp	.L102	#
	.cfi_endproc
.LFE58:
	.size	process_blocks16, .-process_blocks16
	.p2align 4
	.type	process_blocks32, @function
process_blocks32:
.LFB59:
	.cfi_startproc
	pushq	%r15	#
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14	#
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13	#
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12	#
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp	#
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx	#
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$56, %rsp	#,
	.cfi_def_cfa_offset 112
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	movq	120(%rsp), %r12	# target_size, target_size
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	testl	%ecx, %ecx	# blocks
	je	.L167	#,
# loader.c:55:     void *target_addr = (uint8_t *)local_base[target] + patch_offset;
	movslq	%r9d, %rax	# target, _51
	movl	%ecx, 20(%rsp)	# blocks, %sfp
	leaq	(%r8,%rax,8), %r15	#, _53
# loader.c:56:     unsigned long source_base = (unsigned long)local_base[source];
	movslq	112(%rsp), %rax	# source, _56
	leaq	(%r8,%rax,8), %r14	#, _58
	testl	%edx, %edx	# endian
	jne	.L168	#,
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:118:   return __printf_chk (__USE_FORTIFY_LEVEL - 1, __fmt, __va_arg_pack ());
	movl	%r9d, 16(%rsp)	# target, %sfp
	movq	%r14, %r11	# _58, _58
	movq	%r12, %r14	# target_size, target_size
.L152:
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	cmpq	$7, %rsi	#, len
	jbe	.L157	#,
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	leaq	-8(%rsi), %rax	#, len
	movl	4(%rdi), %r12d	# MEM <unsigned int> [(char * {ref-all})p_115 + 4B], count
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	movl	(%rdi), %r13d	# MEM <unsigned int> [(char * {ref-all})p_115], index
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	movq	%rax, %rcx	# len, _101
	shrq	$2, %rcx	#, _101
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	cmpq	%r12, %rcx	# count, _101
	jb	.L157	#,
	cmpq	%r13, %r14	# index, target_size
	jb	.L157	#,
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	leaq	8(%rdi), %rbx	#, p
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	testq	%r12, %r12	# count
	je	.L169	#,
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	movq	%r12, %r10	# count, count
	movq	%rdi, 24(%rsp)	# p, %sfp
	xorl	%ebp, %ebp	# e
	movq	%r11, %r12	# _58, _58
	movq	%rsi, 32(%rsp)	# len, %sfp
	movl	%edx, 40(%rsp)	# endian, %sfp
	jmp	.L146	#
	.p2align 4,,10
	.p2align 3
.L141:
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	ja	.L157	#,
	movl	$4, %esi	#, bytes
.L151:
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	movq	%r14, %rax	# target_size, _69
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	andl	$268435455, %ecx	#, delta
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	subq	%r13, %rax	# index, _69
	cmpq	%rcx, %rax	# delta, _69
	jb	.L157	#,
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	subq	%rcx, %rax	# delta, _67
	cmpq	%rsi, %rax	# bytes, _67
	jb	.L157	#,
# loader.c:55:     void *target_addr = (uint8_t *)local_base[target] + patch_offset;
	movq	(%r15), %rax	# *_53, target_addr
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	addq	%r13, %rcx	# index, _14
# loader.c:56:     unsigned long source_base = (unsigned long)local_base[source];
	movq	(%r12), %rsi	# *_58, source_base
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	addq	$4, %rbx	#, p
# loader.c:55:     void *target_addr = (uint8_t *)local_base[target] + patch_offset;
	addq	%rcx, %rax	# _14, target_addr
# loader.c:57:     if (type == 1) { // ABS64
	cmpl	$1, %edx	#, type
	je	.L185	#,
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	movl	128(%rsp), %edi	# trace,
# loader.c:63:         uint32_t patched = (uint32_t)(source_base + addend);
	addl	%esi, (%rax)	# source_base, MEM <unsigned int> [(char * {ref-all})target_addr_11]
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	testl	%edi, %edi	#
	je	.L147	#,
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	leaq	.LC0(%rip), %r9	#, iftmp.36_129
.L148:
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:118:   return __printf_chk (__USE_FORTIFY_LEVEL - 1, __fmt, __va_arg_pack ());
	movl	112(%rsp), %r8d	# source,
	movl	16(%rsp), %edx	# %sfp,
	movl	$2, %edi	#,
	xorl	%eax, %eax	#
	leaq	.LC2(%rip), %rsi	#,
	movq	%r10, 8(%rsp)	# count, %sfp
	call	__printf_chk@PLT	#
	movq	8(%rsp), %r10	# %sfp, count
.L147:
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	addq	$1, %rbp	#, e
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	cmpq	%r10, %rbp	# count, e
	je	.L186	#,
.L146:
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movl	(%rbx), %ecx	# MEM <unsigned int> [(char * {ref-all})p_96], _92
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	movl	%ecx, %edx	# _92, type
	shrl	$28, %edx	#, type
	cmpl	$1, %edx	#, type
	jne	.L141	#,
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	movl	$8, %esi	#, bytes
	jmp	.L151	#
	.p2align 4,,10
	.p2align 3
.L168:
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:118:   return __printf_chk (__USE_FORTIFY_LEVEL - 1, __fmt, __va_arg_pack ());
	movl	%r9d, 16(%rsp)	# target, %sfp
	xorl	%ecx, %ecx	# b
	movq	%rsi, %r8	# len, len
.L137:
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	cmpq	$7, %r8	#, len
	jbe	.L157	#,
# loader.c:47:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap32(v);
	movl	4(%rdi), %esi	# MEM <unsigned int> [(char * {ref-all})p_82 + 4B], MEM <unsigned int> [(char * {ref-all})p_82 + 4B]
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	leaq	-8(%r8), %rax	#, len
# loader.c:47:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap32(v);
	movl	(%rdi), %r13d	# MEM <unsigned int> [(char * {ref-all})p_82], MEM <unsigned int> [(char * {ref-all})p_82]
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	movq	%rax, %rdx	# len, _2
# loader.c:47:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap32(v);
	bswap	%esi		# _24
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	shrq	$2, %rdx	#, _2
	movl	%esi, %esi	# _24, count
# loader.c:47:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap32(v);
	bswap	%r13d		# _45
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	movl	%r13d, %r13d	# _45, index
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	cmpq	%rsi, %rdx	# count, _2
	jb	.L157	#,
	cmpq	%r13, %r12	# index, target_size
	jb	.L157	#,
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	leaq	8(%rdi), %rbx	#, p
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	testq	%rsi, %rsi	# count
	je	.L172	#,
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	movq	%rsi, 8(%rsp)	# count, %sfp
	xorl	%ebp, %ebp	# e
	movl	%ecx, 24(%rsp)	# b, %sfp
	movq	%rdi, 32(%rsp)	# p, %sfp
	movq	%r8, 40(%rsp)	# len, %sfp
	jmp	.L166	#
	.p2align 4,,10
	.p2align 3
.L189:
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	ja	.L157	#,
	movl	$4, %esi	#, bytes
.L159:
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	movq	%r12, %rdx	# target_size, _3
# loader.c:47:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap32(v);
	bswap	%ecx		# _47
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	andl	$268435455, %ecx	#, delta
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	subq	%r13, %rdx	# index, _3
	cmpq	%rcx, %rdx	# delta, _3
	jb	.L157	#,
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	subq	%rcx, %rdx	# delta, _4
	cmpq	%rsi, %rdx	# bytes, _4
	jb	.L157	#,
# loader.c:55:     void *target_addr = (uint8_t *)local_base[target] + patch_offset;
	movq	(%r15), %rdx	# *_53, target_addr
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	addq	%r13, %rcx	# index, _6
# loader.c:56:     unsigned long source_base = (unsigned long)local_base[source];
	movq	(%r14), %rsi	# *_58, source_base
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	addq	$4, %rbx	#, p
# loader.c:55:     void *target_addr = (uint8_t *)local_base[target] + patch_offset;
	addq	%rcx, %rdx	# _6, target_addr
# loader.c:57:     if (type == 1) { // ABS64
	cmpl	$1, %eax	#, type
	je	.L187	#,
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	movl	128(%rsp), %eax	# trace,
# loader.c:63:         uint32_t patched = (uint32_t)(source_base + addend);
	addl	%esi, (%rdx)	# source_base, MEM <unsigned int> [(char * {ref-all})target_addr_55]
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	leaq	.LC0(%rip), %r9	#, iftmp.36_68
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	testl	%eax, %eax	#
	je	.L164	#,
.L163:
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:118:   return __printf_chk (__USE_FORTIFY_LEVEL - 1, __fmt, __va_arg_pack ());
	movl	112(%rsp), %r8d	# source,
	movl	16(%rsp), %edx	# %sfp,
	movl	$2, %edi	#,
	xorl	%eax, %eax	#
	leaq	.LC2(%rip), %rsi	#,
	call	__printf_chk@PLT	#
.L164:
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	addq	$1, %rbp	#, e
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	cmpq	%rbp, 8(%rsp)	# e, %sfp
	je	.L188	#,
.L166:
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movl	(%rbx), %ecx	# MEM <unsigned int> [(char * {ref-all})p_80], _46
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	movl	%ecx, %eax	# _46, _91
	shrb	$4, %al	#, _91
	movzbl	%al, %eax	# _91, type
	cmpl	$1, %eax	#, type
	jne	.L189	#,
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	movl	$8, %esi	#, bytes
	jmp	.L159	#
	.p2align 4,,10
	.p2align 3
.L185:
# loader.c:59:         uint64_t patched = source_base + addend;
	addq	%rsi, (%rax)	# source_base, MEM <unsigned long> [(char * {ref-all})target_addr_11]
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	movl	128(%rsp), %esi	# trace,
	testl	%esi, %esi	#
	je	.L147	#,
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	leaq	.LC1(%rip), %r9	#, iftmp.36_129
	jmp	.L148	#
	.p2align 4,,10
	.p2align 3
.L187:
# loader.c:59:         uint64_t patched = source_base + addend;
	addq	%rsi, (%rdx)	# source_base, MEM <unsigned long> [(char * {ref-all})target_addr_55]
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	movl	128(%rsp), %edx	# trace,
	testl	%edx, %edx	#
	je	.L164	#,
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	leaq	.LC1(%rip), %r9	#, iftmp.36_68
	jmp	.L163	#
	.p2align 4,,10
	.p2align 3
.L157:
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	movl	$-1, %eax	#, <retval>
.L134:
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	addq	$56, %rsp	#,
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx	#
	.cfi_def_cfa_offset 48
	popq	%rbp	#
	.cfi_def_cfa_offset 40
	popq	%r12	#
	.cfi_def_cfa_offset 32
	popq	%r13	#
	.cfi_def_cfa_offset 24
	popq	%r14	#
	.cfi_def_cfa_offset 16
	popq	%r15	#
	.cfi_def_cfa_offset 8
	ret	
	.p2align 4,,10
	.p2align 3
.L188:
	.cfi_restore_state
	movq	32(%rsp), %rdi	# %sfp, p
	addq	40(%rsp), %rdi	# %sfp, _148
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	subq	%rbx, %rdi	# p, _148
	movl	24(%rsp), %ecx	# %sfp, b
	movq	%rdi, %r8	# _148, len
	movq	%rbx, %rdi	# p, p
.L158:
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	addl	$1, %ecx	#, b
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	cmpl	%ecx, 20(%rsp)	# b, %sfp
	jne	.L137	#,
.L167:
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	xorl	%eax, %eax	# <retval>
	jmp	.L134	#
	.p2align 4,,10
	.p2align 3
.L186:
	movq	24(%rsp), %rdi	# %sfp, p
	addq	32(%rsp), %rdi	# %sfp, _140
	movq	%r12, %r11	# _58, _58
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	subq	%rbx, %rdi	# p, _140
	movl	40(%rsp), %edx	# %sfp, endian
	movq	%rdi, %rsi	# _140, len
	movq	%rbx, %rdi	# p, p
.L140:
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	addl	$1, %edx	#, endian
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	cmpl	%edx, 20(%rsp)	# endian, %sfp
	jne	.L152	#,
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	xorl	%eax, %eax	# <retval>
	jmp	.L134	#
.L169:
# loader.c:91: BLOCK_PROCESS(32, uint32_t, 28, UINT32_C(0xFFFFFFF))
	movq	%rax, %rsi	# len, len
	movq	%rbx, %rdi	# p, p
	jmp	.L140	#
.L172:
	movq	%rax, %r8	# len, len
	movq	%rbx, %rdi	# p, p
	jmp	.L158	#
	.cfi_endproc
.LFE59:
	.size	process_blocks32, .-process_blocks32
	.p2align 4
	.type	process_blocks64, @function
process_blocks64:
.LFB60:
	.cfi_startproc
	pushq	%r15	#
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14	#
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13	#
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12	#
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp	#
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx	#
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$56, %rsp	#,
	.cfi_def_cfa_offset 112
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	movq	120(%rsp), %r12	# target_size, target_size
	movl	128(%rsp), %r13d	# trace, trace
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	testl	%ecx, %ecx	# blocks
	je	.L223	#,
# loader.c:55:     void *target_addr = (uint8_t *)local_base[target] + patch_offset;
	movslq	%r9d, %rax	# target, _47
	movl	%r9d, 16(%rsp)	# target, %sfp
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	movabsq	$1152921504606846975, %r11	#, tmp207
# loader.c:55:     void *target_addr = (uint8_t *)local_base[target] + patch_offset;
	leaq	(%r8,%rax,8), %r14	#, _49
# loader.c:56:     unsigned long source_base = (unsigned long)local_base[source];
	movslq	112(%rsp), %rax	# source, _52
	movl	%ecx, 20(%rsp)	# blocks, %sfp
	leaq	(%r8,%rax,8), %r15	#, _54
	testl	%edx, %edx	# endian
	jne	.L224	#,
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	movl	%r13d, %r10d	# trace, trace
	movq	%rsi, %r8	# len, len
	movq	%r12, %r13	# target_size, target_size
.L208:
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	cmpq	$15, %r8	#, len
	jbe	.L213	#,
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	leaq	-16(%r8), %rax	#, len
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movq	8(%rdi), %rsi	# MEM <unsigned long> [(char * {ref-all})p_95 + 8B], pretmp_90
	movq	(%rdi), %r12	# MEM <unsigned long> [(char * {ref-all})p_95], _91
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	movq	%rax, %rcx	# len, _69
	shrq	$3, %rcx	#, _69
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	cmpq	%rsi, %rcx	# pretmp_90, _69
	jb	.L213	#,
	cmpq	%r12, %r13	# _91, target_size
	jb	.L213	#,
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	leaq	16(%rdi), %rbx	#, p
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	testq	%rsi, %rsi	# pretmp_90
	je	.L225	#,
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:118:   return __printf_chk (__USE_FORTIFY_LEVEL - 1, __fmt, __va_arg_pack ());
	movq	%rsi, 8(%rsp)	# pretmp_90, %sfp
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	xorl	%ebp, %ebp	# e
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:118:   return __printf_chk (__USE_FORTIFY_LEVEL - 1, __fmt, __va_arg_pack ());
	movq	%rdi, 24(%rsp)	# p, %sfp
	movq	%r8, 32(%rsp)	# len, %sfp
	movl	%edx, 40(%rsp)	# endian, %sfp
	jmp	.L202	#
	.p2align 4,,10
	.p2align 3
.L197:
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	ja	.L213	#,
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	movq	%r13, %rax	# target_size, _46
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	andq	%r11, %rcx	# tmp207, delta
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	movl	$4, %esi	#, bytes
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	subq	%r12, %rax	# _91, _46
	cmpq	%rcx, %rax	# delta, _46
	jb	.L213	#,
.L243:
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	subq	%rcx, %rax	# delta, _28
	cmpq	%rsi, %rax	# bytes, _28
	jb	.L213	#,
# loader.c:55:     void *target_addr = (uint8_t *)local_base[target] + patch_offset;
	movq	(%r14), %rax	# *_49, target_addr
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	addq	%r12, %rcx	# _91, _111
# loader.c:56:     unsigned long source_base = (unsigned long)local_base[source];
	movq	(%r15), %rsi	# *_54, source_base
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	addq	$8, %rbx	#, p
# loader.c:55:     void *target_addr = (uint8_t *)local_base[target] + patch_offset;
	addq	%rcx, %rax	# _111, target_addr
# loader.c:57:     if (type == 1) { // ABS64
	cmpq	$1, %rdx	#, _8
	je	.L241	#,
# loader.c:63:         uint32_t patched = (uint32_t)(source_base + addend);
	addl	%esi, (%rax)	# source_base, MEM <unsigned int> [(char * {ref-all})target_addr_113]
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	testl	%r10d, %r10d	# trace
	je	.L203	#,
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	leaq	.LC0(%rip), %r9	#, iftmp.36_121
.L204:
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:118:   return __printf_chk (__USE_FORTIFY_LEVEL - 1, __fmt, __va_arg_pack ());
	movl	112(%rsp), %r8d	# source,
	movl	16(%rsp), %edx	# %sfp,
	movl	$2, %edi	#,
	xorl	%eax, %eax	#
	leaq	.LC2(%rip), %rsi	#,
	movl	%r10d, 128(%rsp)	# trace, trace
	call	__printf_chk@PLT	#
	movl	128(%rsp), %r10d	# trace, trace
	movabsq	$1152921504606846975, %r11	#, tmp207
.L203:
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	addq	$1, %rbp	#, e
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	cmpq	%rbp, 8(%rsp)	# e, %sfp
	je	.L242	#,
.L202:
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movq	(%rbx), %rcx	# MEM <unsigned long> [(char * {ref-all})p_15], _10
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	movq	%rcx, %rdx	# _10, _8
	shrq	$60, %rdx	#, _8
	cmpq	$1, %rdx	#, _8
	jne	.L197	#,
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	movq	%r13, %rax	# target_size, _46
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	andq	%r11, %rcx	# tmp207, delta
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	movl	$8, %esi	#, bytes
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	subq	%r12, %rax	# _91, _46
	cmpq	%rcx, %rax	# delta, _46
	jnb	.L243	#,
	.p2align 4
	.p2align 3
.L213:
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	movl	$-1, %eax	#, <retval>
.L190:
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	addq	$56, %rsp	#,
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx	#
	.cfi_def_cfa_offset 48
	popq	%rbp	#
	.cfi_def_cfa_offset 40
	popq	%r12	#
	.cfi_def_cfa_offset 32
	popq	%r13	#
	.cfi_def_cfa_offset 24
	popq	%r14	#
	.cfi_def_cfa_offset 16
	popq	%r15	#
	.cfi_def_cfa_offset 8
	ret	
	.p2align 4,,10
	.p2align 3
.L224:
	.cfi_restore_state
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:118:   return __printf_chk (__USE_FORTIFY_LEVEL - 1, __fmt, __va_arg_pack ());
	movl	%r13d, %r10d	# trace, trace
	xorl	%ecx, %ecx	# b
	movq	%rsi, %r8	# len, len
	movq	%r12, %r13	# target_size, target_size
.L193:
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	cmpq	$15, %r8	#, len
	jbe	.L213	#,
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movq	8(%rdi), %rax	# MEM <unsigned long> [(char * {ref-all})p_78 + 8B], pretmp_105
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	leaq	-16(%r8), %rdx	#, len
# loader.c:51:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap64(v);
	movq	(%rdi), %r12	# MEM <unsigned long> [(char * {ref-all})p_78], MEM <unsigned long> [(char * {ref-all})p_78]
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	movq	%rdx, %r9	# len, _1
# loader.c:51:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap64(v);
	movq	%rax, %rsi	# pretmp_105, _23
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	shrq	$3, %r9	#, _1
# loader.c:51:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap64(v);
	bswap	%r12		# _41
	bswap	%rsi		# _23
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	cmpq	%rsi, %r9	# _23, _1
	jb	.L213	#,
	cmpq	%r12, %r13	# _41, target_size
	jb	.L213	#,
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	leaq	16(%rdi), %rbx	#, p
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	testq	%rax, %rax	# pretmp_105
	je	.L228	#,
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	movq	%rsi, 8(%rsp)	# _23, %sfp
	xorl	%ebp, %ebp	# e
	movl	%ecx, 24(%rsp)	# b, %sfp
	movq	%rdi, 32(%rsp)	# p, %sfp
	movq	%r8, 40(%rsp)	# len, %sfp
	jmp	.L222	#
	.p2align 4,,10
	.p2align 3
.L246:
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	ja	.L213	#,
	movl	$4, %esi	#, bytes
.L215:
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	movq	%r13, %rdx	# target_size, _3
# loader.c:51:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap64(v);
	bswap	%rcx		# _43
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	andq	%r11, %rcx	# tmp215, delta
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	subq	%r12, %rdx	# _41, _3
	cmpq	%rcx, %rdx	# delta, _3
	jb	.L213	#,
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	subq	%rcx, %rdx	# delta, _4
	cmpq	%rsi, %rdx	# bytes, _4
	jb	.L213	#,
# loader.c:55:     void *target_addr = (uint8_t *)local_base[target] + patch_offset;
	movq	(%r14), %rdx	# *_49, target_addr
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	addq	%r12, %rcx	# _41, _6
# loader.c:56:     unsigned long source_base = (unsigned long)local_base[source];
	movq	(%r15), %rsi	# *_54, source_base
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	addq	$8, %rbx	#, p
# loader.c:55:     void *target_addr = (uint8_t *)local_base[target] + patch_offset;
	addq	%rcx, %rdx	# _6, target_addr
# loader.c:57:     if (type == 1) { // ABS64
	cmpq	$1, %rax	#, _2
	je	.L244	#,
# loader.c:63:         uint32_t patched = (uint32_t)(source_base + addend);
	addl	%esi, (%rdx)	# source_base, MEM <unsigned int> [(char * {ref-all})target_addr_51]
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	leaq	.LC0(%rip), %r9	#, iftmp.36_64
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	testl	%r10d, %r10d	# trace
	je	.L220	#,
.L219:
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:118:   return __printf_chk (__USE_FORTIFY_LEVEL - 1, __fmt, __va_arg_pack ());
	movl	112(%rsp), %r8d	# source,
	movl	16(%rsp), %edx	# %sfp,
	movl	$2, %edi	#,
	xorl	%eax, %eax	#
	leaq	.LC2(%rip), %rsi	#,
	movl	%r10d, 128(%rsp)	# trace, trace
	call	__printf_chk@PLT	#
	movl	128(%rsp), %r10d	# trace, trace
	movabsq	$1152921504606846975, %r11	#, tmp215
.L220:
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	addq	$1, %rbp	#, e
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	cmpq	%rbp, 8(%rsp)	# e, %sfp
	je	.L245	#,
.L222:
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movq	(%rbx), %rcx	# MEM <unsigned long> [(char * {ref-all})p_76], _42
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	movl	%ecx, %eax	# _42, _9
	shrb	$4, %al	#, _9
	movzbl	%al, %eax	# _9, _2
	cmpq	$1, %rax	#, _2
	jne	.L246	#,
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	movl	$8, %esi	#, bytes
	jmp	.L215	#
	.p2align 4,,10
	.p2align 3
.L241:
# loader.c:59:         uint64_t patched = source_base + addend;
	addq	%rsi, (%rax)	# source_base, MEM <unsigned long> [(char * {ref-all})target_addr_113]
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	testl	%r10d, %r10d	# trace
	je	.L203	#,
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	leaq	.LC1(%rip), %r9	#, iftmp.36_121
	jmp	.L204	#
	.p2align 4,,10
	.p2align 3
.L244:
# loader.c:59:         uint64_t patched = source_base + addend;
	addq	%rsi, (%rdx)	# source_base, MEM <unsigned long> [(char * {ref-all})target_addr_51]
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	testl	%r10d, %r10d	# trace
	je	.L220	#,
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	leaq	.LC1(%rip), %r9	#, iftmp.36_64
	jmp	.L219	#
	.p2align 4,,10
	.p2align 3
.L245:
	movq	32(%rsp), %rdi	# %sfp, p
	addq	40(%rsp), %rdi	# %sfp, _139
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	subq	%rbx, %rdi	# p, _139
	movl	24(%rsp), %ecx	# %sfp, b
	movq	%rdi, %r8	# _139, len
	movq	%rbx, %rdi	# p, p
.L214:
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	addl	$1, %ecx	#, b
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	cmpl	%ecx, 20(%rsp)	# b, %sfp
	jne	.L193	#,
.L223:
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	xorl	%eax, %eax	# <retval>
	jmp	.L190	#
	.p2align 4,,10
	.p2align 3
.L242:
	movq	24(%rsp), %rdi	# %sfp, p
	addq	32(%rsp), %rdi	# %sfp, _132
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	subq	%rbx, %rdi	# p, _132
	movl	40(%rsp), %edx	# %sfp, endian
	movq	%rdi, %r8	# _132, len
	movq	%rbx, %rdi	# p, p
.L196:
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	addl	$1, %edx	#, endian
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	cmpl	%edx, 20(%rsp)	# endian, %sfp
	jne	.L208	#,
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	xorl	%eax, %eax	# <retval>
	jmp	.L190	#
.L225:
# loader.c:92: BLOCK_PROCESS(64, uint64_t, 60, UINT64_C(0xFFFFFFFFFFFFFFF))
	movq	%rax, %r8	# len, len
	movq	%rbx, %rdi	# p, p
	jmp	.L196	#
.L228:
	movq	%rdx, %r8	# len, len
	movq	%rbx, %rdi	# p, p
	jmp	.L214	#
	.cfi_endproc
.LFE60:
	.size	process_blocks64, .-process_blocks64
	.section	.rodata.str1.1
.LC3:
	.string	"monolithic"
.LC4:
	.string	"--L="
.LC5:
	.string	"--quiet-reloc"
	.section	.rodata.str1.8
	.align 8
.LC6:
	.string	"usage: %s [--L=monolithic|scattered] <file.ueec>\n"
	.section	.rodata.str1.1
.LC7:
	.string	"rb"
.LC8:
	.string	"fopen"
.LC9:
	.string	"read error\n"
.LC10:
	.string	"invalid magic\n"
.LC11:
	.string	"node: %d, load-mode: %s\n"
.LC12:
	.string	"no matching node\n"
	.section	.rodata.str1.8
	.align 8
.LC13:
	.string	"resident sections: %d, RELOC sections: %d\n"
	.section	.rodata.str1.1
.LC14:
	.string	"scattered"
.LC15:
	.string	"unknown --L mode: %s\n"
	.section	.rodata.str1.8
	.align 8
.LC16:
	.string	"invalid or unsupported relocation section %d\n"
	.section	.rodata.str1.1
.LC17:
	.string	"no CODE section found\n"
	.section	.text.unlikely,"ax",@progbits
.LCOLDB18:
	.text
.LHOTB18:
	.p2align 4
	.globl	loader_main
	.type	loader_main, @function
loader_main:
.LFB62:
	.cfi_startproc
	endbr64	
	pushq	%r15	#
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14	#
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13	#
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12	#
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp	#
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx	#
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$344, %rsp	#,
	.cfi_def_cfa_offset 400
# loader.c:123: int main(int argc, char *argv[]) {
	movq	%fs:40, %r13	# MEM[(<address-space-1> long unsigned int *)40B], argv
	movq	%r13, 328(%rsp)	# argv, D.6101
	movq	%rsi, %r13	# argv, argv
# loader.c:127:     for (int i = 1; i < argc; i++) {
	cmpl	$1, %edi	#, argc
	jle	.L248	#,
	leal	-2(%rdi), %eax	#, _973
# loader.c:130:         else path = argv[i];
	movq	%r13, (%rsp)	# argv, %sfp
# loader.c:126:     int trace_reloc = 1;
	movl	$1, %ebx	#, trace_reloc
# loader.c:124:     const char *path = NULL;
	xorl	%r15d, %r15d	# path
	leaq	16(%r13,%rax,8), %r14	#, _977
# loader.c:125:     const char *load_mode = "monolithic";
	leaq	.LC3(%rip), %rbp	#, load_mode
# loader.c:130:         else path = argv[i];
	addq	$8, %r13	#, ivtmp.350
	jmp	.L251	#
	.p2align 4,,10
	.p2align 3
.L531:
# loader.c:127:     for (int i = 1; i < argc; i++) {
	addq	$8, %r13	#, ivtmp.350
# loader.c:128:         if (!strncmp(argv[i], "--L=", 4)) load_mode = argv[i] + 4;
	leaq	4(%r12), %rbp	#, load_mode
# loader.c:127:     for (int i = 1; i < argc; i++) {
	cmpq	%r14, %r13	# _977, ivtmp.350
	je	.L530	#,
.L251:
# loader.c:128:         if (!strncmp(argv[i], "--L=", 4)) load_mode = argv[i] + 4;
	movq	0(%r13), %r12	# MEM[(char * *)_970], _4
	movl	$4, %edx	#,
	leaq	.LC4(%rip), %rsi	#,
	movq	%r12, %rdi	# _4,
	call	strncmp@PLT	#
# loader.c:128:         if (!strncmp(argv[i], "--L=", 4)) load_mode = argv[i] + 4;
	testl	%eax, %eax	# _5
	je	.L531	#,
# loader.c:129:         else if (!strcmp(argv[i], "--quiet-reloc")) trace_reloc = 0;
	leaq	.LC5(%rip), %rsi	#,
	movq	%r12, %rdi	# _4,
	call	strcmp@PLT	#
# loader.c:130:         else path = argv[i];
	testl	%eax, %eax	# _6
	movl	$0, %eax	#, tmp1300
	cmovne	%r12, %r15	# path,, _4, path
	cmove	%eax, %ebx	# trace_reloc,, tmp1300, trace_reloc
# loader.c:127:     for (int i = 1; i < argc; i++) {
	addq	$8, %r13	#, ivtmp.350
	cmpq	%r14, %r13	# _977, ivtmp.350
	jne	.L251	#,
.L530:
# loader.c:132:     if (!path) { fprintf(stderr, "usage: %s [--L=monolithic|scattered] <file.ueec>\n", argv[0]); return 1; }
	movq	(%rsp), %r13	# %sfp, argv
	testq	%r15, %r15	# path
	je	.L248	#,
# loader.c:134:     FILE *f = fopen(path, "rb");
	leaq	.LC7(%rip), %rsi	#,
	movq	%r15, %rdi	# path,
	call	fopen@PLT	#
	movq	%rax, %r13	#, tmp1104
# loader.c:135:     if (!f) { perror("fopen"); return 1; }
	testq	%rax, %rax	# tmp1104
	je	.L517	#,
# loader.c:136:     fseek(f, 0, SEEK_END);
	xorl	%esi, %esi	#
	movl	$2, %edx	#,
	movq	%rax, %rdi	# tmp1104,
	call	fseek@PLT	#
# loader.c:137:     long fsize = ftell(f);
	movq	%r13, %rdi	# tmp1104,
	call	ftell@PLT	#
# loader.c:138:     fseek(f, 0, SEEK_SET);
	xorl	%edx, %edx	#
	xorl	%esi, %esi	#
	movq	%r13, %rdi	# tmp1104,
# loader.c:137:     long fsize = ftell(f);
	movq	%rax, %r14	#, fsize
# loader.c:138:     fseek(f, 0, SEEK_SET);
	call	fseek@PLT	#
# loader.c:139:     uint8_t *buf = malloc(fsize);
	movq	%r14, %rdi	# fsize,
	call	malloc@PLT	#
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:331:     return __fread_alias (__ptr, __size, __n, __stream);
	movq	%r13, %rcx	# tmp1104,
	movq	%r14, %rdx	# fsize,
	movl	$1, %esi	#,
	movq	%rax, %rdi	# buf,
# loader.c:139:     uint8_t *buf = malloc(fsize);
	movq	%rax, %r12	#, buf
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:331:     return __fread_alias (__ptr, __size, __n, __stream);
	call	fread@PLT	#
# loader.c:140:     if (fread(buf, 1, fsize, f) != (size_t)fsize) { fprintf(stderr, "read error\n"); return 1; }
	cmpq	%rax, %r14	# _291, fsize
	je	.L255	#,
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:111:   return __fprintf_chk (__stream, __USE_FORTIFY_LEVEL - 1, __fmt,
	movq	stderr(%rip), %rcx	# stderr,
	movl	$11, %edx	#,
	movl	$1, %esi	#,
	leaq	.LC9(%rip), %rdi	#,
	call	fwrite@PLT	#
.L253:
# loader.c:274: }
	movq	328(%rsp), %rax	# D.6101, tmp1133
	subq	%fs:40, %rax	# MEM[(<address-space-1> long unsigned int *)40B], tmp1133
	jne	.L532	#,
	addq	$344, %rsp	#,
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movl	$1, %eax	#,
	popq	%rbx	#
	.cfi_def_cfa_offset 48
	popq	%rbp	#
	.cfi_def_cfa_offset 40
	popq	%r12	#
	.cfi_def_cfa_offset 32
	popq	%r13	#
	.cfi_def_cfa_offset 24
	popq	%r14	#
	.cfi_def_cfa_offset 16
	popq	%r15	#
	.cfi_def_cfa_offset 8
	ret	
	.p2align 4,,10
	.p2align 3
.L255:
	.cfi_restore_state
# loader.c:141:     fclose(f);
	movq	%r13, %rdi	# tmp1104,
	call	fclose@PLT	#
# loader.c:144:     if (buf[0] != UEEC_MAGIC_0 || buf[1] != UEEC_MAGIC_1 || buf[2] != UEEC_MAGIC_2) {
	cmpb	$95, (%r12)	#, *buf_209
	jne	.L256	#,
# loader.c:144:     if (buf[0] != UEEC_MAGIC_0 || buf[1] != UEEC_MAGIC_1 || buf[2] != UEEC_MAGIC_2) {
	cmpb	$71, 1(%r12)	#, MEM[(uint8_t *)buf_209 + 1B]
	jne	.L256	#,
# loader.c:144:     if (buf[0] != UEEC_MAGIC_0 || buf[1] != UEEC_MAGIC_1 || buf[2] != UEEC_MAGIC_2) {
	cmpb	$77, 2(%r12)	#, MEM[(uint8_t *)buf_209 + 2B]
	jne	.L256	#,
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	movzbl	3(%r12), %ecx	# MEM[(uint8_t *)buf_209 + 3B], _16
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movzwl	4(%r12), %eax	# MEM <unsigned short> [(char * {ref-all})buf_209 + 4B],
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	shrb	$7, %cl	#, _16
	movb	%cl, 36(%rsp)	# _16, %sfp
	je	.L533	#,
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	rolw	$8, %ax	#, _923
	movzwl	%ax, %esi	# _923, nodes
# loader.c:154:     node_t *node = malloc(sizeof(node_t) * nodes);
	movzwl	%ax, %eax	# _923, _82
# loader.c:154:     node_t *node = malloc(sizeof(node_t) * nodes);
	leaq	(%rax,%rax,2), %rdi	#, _172
	movl	%esi, (%rsp)	# nodes, %sfp
	salq	$2, %rdi	#, tmp681
# loader.c:154:     node_t *node = malloc(sizeof(node_t) * nodes);
	call	malloc@PLT	#
# loader.c:156:     for (unsigned i = 0; i < nodes; i++) {
	movl	(%rsp), %esi	# %sfp, nodes
# loader.c:154:     node_t *node = malloc(sizeof(node_t) * nodes);
	movq	%rax, %rdx	# node, node
# loader.c:156:     for (unsigned i = 0; i < nodes; i++) {
	testl	%esi, %esi	# nodes
	je	.L260	#,
	leal	-1(%rsi), %eax	#, _963
# loader.c:155:     long total_info = 0;
	xorl	%r8d, %r8d	# total_info
# loader.c:151:     size_t off = 8;
	movl	$8, %r14d	#, off
	leaq	(%rax,%rax,2), %r13	#, _964
	addq	%r13, %r13	# tmp700
	leaq	14(%r13), %r15	#, off
	.p2align 6
	.p2align 4
	.p2align 3
.L264:
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movl	(%r12,%r14), %eax	# MEM <unsigned int> [(char * {ref-all})buf_209 + off_213 * 1], _302
# loader.c:47:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap32(v);
	movl	%eax, %ecx	# _302, _303
	shrb	$3, %al	#, _328
	bswap	%ecx		# _303
# loader.c:158:         node[i].machine_type = (v >> 7) & 0x7;
	movl	%ecx, %edi	# _303, _21
# loader.c:159:         node[i].machine = (v >> 10) & 0xFF;
	shrl	$10, %ecx	#, _26
# loader.c:159:         node[i].machine = (v >> 10) & 0xFF;
	andl	$255, %ecx	#, tmp704
# loader.c:158:         node[i].machine_type = (v >> 7) & 0x7;
	shrl	$7, %edi	#, _21
# loader.c:159:         node[i].machine = (v >> 10) & 0xFF;
	movl	%ecx, -12(%rdx,%r14,2)	# tmp704, MEM[(int *)node_597 + -12B + off_213 * 2]
# loader.c:160:         node[i].section_count = ((v >> 27) & 0x1F) + 1;
	movzbl	%al, %ecx	# _328, _28
# loader.c:158:         node[i].machine_type = (v >> 7) & 0x7;
	andl	$7, %edi	#, tmp702
# loader.c:161:         total_info += node[i].section_count - 1; // HEADER ar iTvleba node_info-Si
	movzbl	%al, %eax	# _328, _31
# loader.c:160:         node[i].section_count = ((v >> 27) & 0x1F) + 1;
	addl	$1, %ecx	#, tmp706
# loader.c:158:         node[i].machine_type = (v >> 7) & 0x7;
	movl	%edi, -16(%rdx,%r14,2)	# tmp702, MEM[(int *)node_597 + -16B + off_213 * 2]
# loader.c:161:         total_info += node[i].section_count - 1; // HEADER ar iTvleba node_info-Si
	addq	%rax, %r8	# _31, total_info
# loader.c:160:         node[i].section_count = ((v >> 27) & 0x1F) + 1;
	movl	%ecx, -8(%rdx,%r14,2)	# tmp706, MEM[(int *)node_597 + -8B + off_213 * 2]
# loader.c:163:         off += 2; // format
	addq	$6, %r14	#, off
# loader.c:156:     for (unsigned i = 0; i < nodes; i++) {
	cmpq	%r15, %r14	# off, off
	jne	.L264	#,
# loader.c:167:     info_t *info = malloc(sizeof(info_t) * total_info);
	leaq	0(,%r8,8), %rcx	#, _803
	movl	%esi, 40(%rsp)	# nodes, %sfp
# loader.c:167:     info_t *info = malloc(sizeof(info_t) * total_info);
	movq	%rcx, %rdi	# _803,
	movq	%rdx, 24(%rsp)	# node, %sfp
# loader.c:167:     info_t *info = malloc(sizeof(info_t) * total_info);
	movq	%r8, 16(%rsp)	# total_info, %sfp
# loader.c:167:     info_t *info = malloc(sizeof(info_t) * total_info);
	movq	%rcx, 8(%rsp)	# _803, %sfp
	call	malloc@PLT	#
# loader.c:169:     for (long i = 0; i < total_info; i++) {
	movq	16(%rsp), %r8	# %sfp, total_info
	movq	8(%rsp), %rcx	# %sfp, _803
	movq	24(%rsp), %rdx	# %sfp, node
	movl	40(%rsp), %esi	# %sfp, nodes
# loader.c:167:     info_t *info = malloc(sizeof(info_t) * total_info);
	movq	%rax, (%rsp)	# info, %sfp
# loader.c:169:     for (long i = 0; i < total_info; i++) {
	testq	%r8, %r8	# total_info
	jle	.L266	#,
	leaq	(%rax,%rcx), %r10	#, _484
	movq	%rax, %rdi	# info, ivtmp.322
	leaq	2(%r12,%r14), %r9	#, ivtmp.323
# loader.c:168:     long max_section = 0;
	xorl	%ecx, %ecx	# max_section
	.p2align 6
	.p2align 4
	.p2align 3
.L269:
# loader.c:170:         info[i].n = rd16(buf + off, file_endian); off += 2;
	movzwl	-2(%r9), %r11d	# MEM <unsigned short> [(char * {ref-all})_703 + -2B], _874
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	movl	%r11d, %eax	# _874, _310
	rolw	$8, %ax	#, _310
# loader.c:170:         info[i].n = rd16(buf + off, file_endian); off += 2;
	movzwl	%ax, %r11d	# _310, _310
# loader.c:47:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap32(v);
	movl	(%r9), %eax	# MEM <unsigned int> [(char * {ref-all})_703], MEM <unsigned int> [(char * {ref-all})_703]
# loader.c:170:         info[i].n = rd16(buf + off, file_endian); off += 2;
	movl	%r11d, (%rdi)	# _310, MEM[(int *)_704]
# loader.c:47:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap32(v);
	bswap	%eax		# _306
# loader.c:171:         info[i].s = rd32(buf + off, file_endian); off += 4;
	movl	%eax, 4(%rdi)	# _306, MEM[(int *)_704 + 4B]
# loader.c:172:         if (info[i].s > max_section) max_section = info[i].s;
	cltq
# loader.c:172:         if (info[i].s > max_section) max_section = info[i].s;
	cmpq	%rax, %rcx	# _41, max_section
	cmovl	%rax, %rcx	# max_section,, _41, max_section
# loader.c:169:     for (long i = 0; i < total_info; i++) {
	addq	$8, %rdi	#, ivtmp.322
	addq	$6, %r9	#, ivtmp.323
	cmpq	%r10, %rdi	# _484, ivtmp.322
	jne	.L269	#,
.L520:
# loader.c:174:     long total_sections = max_section + 1;
	leaq	1(%rcx), %r10	#, prephitmp_274
# loader.c:171:         info[i].s = rd32(buf + off, file_endian); off += 4;
	leaq	-3(%r8,%r8,2), %rax	#, _745
	movl	%esi, 56(%rsp)	# nodes, %sfp
# loader.c:177:     long *sec_size = malloc(sizeof(long) * total_sections);
	leaq	0(,%r10,8), %r14	#, _742
	movq	%rdx, 48(%rsp)	# node, %sfp
# loader.c:171:         info[i].s = rd32(buf + off, file_endian); off += 4;
	leaq	20(%r13,%rax,2), %r15	#, off
# loader.c:176:     int *sec_type = malloc(sizeof(int) * total_sections);
	leaq	0(,%r10,4), %rdi	#, _740
	movq	%r8, 40(%rsp)	# total_info, %sfp
# loader.c:174:     long total_sections = max_section + 1;
	movq	%rcx, 24(%rsp)	# max_section, %sfp
# loader.c:176:     int *sec_type = malloc(sizeof(int) * total_sections);
	movq	%r10, 16(%rsp)	# prephitmp_274, %sfp
# loader.c:176:     int *sec_type = malloc(sizeof(int) * total_sections);
	call	malloc@PLT	#
# loader.c:177:     long *sec_size = malloc(sizeof(long) * total_sections);
	movq	%r14, %rdi	# _742,
# loader.c:176:     int *sec_type = malloc(sizeof(int) * total_sections);
	movq	%rax, 8(%rsp)	# sec_type, %sfp
# loader.c:177:     long *sec_size = malloc(sizeof(long) * total_sections);
	call	malloc@PLT	#
# loader.c:178:     long *sec_off = malloc(sizeof(long) * total_sections);
	movq	%r14, %rdi	# _742,
# loader.c:177:     long *sec_size = malloc(sizeof(long) * total_sections);
	movq	%rax, %r13	# sec_size, sec_size
# loader.c:178:     long *sec_off = malloc(sizeof(long) * total_sections);
	call	malloc@PLT	#
# loader.c:179:     for (long s = 0; s < total_sections; s++) {
	movq	16(%rsp), %r10	# %sfp, prephitmp_274
	movq	8(%rsp), %r9	# %sfp, sec_type
	movq	24(%rsp), %rcx	# %sfp, max_section
	movq	40(%rsp), %r8	# %sfp, total_info
# loader.c:178:     long *sec_off = malloc(sizeof(long) * total_sections);
	movq	%rax, %r14	# sec_off, sec_off
# loader.c:179:     for (long s = 0; s < total_sections; s++) {
	testq	%r10, %r10	# prephitmp_274
	movq	48(%rsp), %rdx	# %sfp, node
	movl	56(%rsp), %esi	# %sfp, nodes
	jle	.L271	#,
.L358:
	cmpb	$0, 36(%rsp)	#, %sfp
	jne	.L272	#,
	leaq	(%r12,%r15), %rax	#, ivtmp.292
# loader.c:179:     for (long s = 0; s < total_sections; s++) {
	xorl	%edi, %edi	# s
	.p2align 6
	.p2align 4
	.p2align 3
.L273:
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	movzwl	(%rax), %r15d	# MEM <unsigned short> [(char * {ref-all})_901], MEM <unsigned short> [(char * {ref-all})_901]
	movq	%rdi, %r11	# s, _889
# loader.c:179:     for (long s = 0; s < total_sections; s++) {
	addq	$6, %rax	#, ivtmp.292
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	movl	%r15d, (%r9,%rdi,4)	# MEM <unsigned short> [(char * {ref-all})_901], MEM[(int *)sec_type_34 + _889 * 4]
# loader.c:181:         sec_size[s] = rd16(buf + off, file_endian); off += 2;
	movzwl	-4(%rax), %r15d	# MEM <unsigned short> [(char * {ref-all})_901 + 2B], pretmp_769
	movq	%r15, 0(%r13,%rdi,8)	# pretmp_769, MEM[(long int *)sec_size_45 + _889 * 8]
# loader.c:179:     for (long s = 0; s < total_sections; s++) {
	addq	$1, %rdi	#, s
# loader.c:179:     for (long s = 0; s < total_sections; s++) {
	cmpq	%r11, %rcx	# _889, max_section
	jg	.L273	#,
.L274:
# loader.c:184:     sec_off[0] = 0;
	movq	$0, (%r14)	#, *sec_off_55
# loader.c:185:     for (long s = 1; s < total_sections; s++) sec_off[s] = sec_off[s-1] + sec_size[s-1];
	cmpq	$1, %r10	#, prephitmp_274
	je	.L277	#,
	xorl	%eax, %eax	# ivtmp.279
	xorl	%edi, %edi	# D__lsm0.219
	.p2align 5
	.p2align 4
	.p2align 3
.L278:
# loader.c:185:     for (long s = 1; s < total_sections; s++) sec_off[s] = sec_off[s-1] + sec_size[s-1];
	addq	0(%r13,%rax,8), %rdi	# MEM[(long int *)sec_size_45 + ivtmp.279_920 * 8], D__lsm0.219
# loader.c:185:     for (long s = 1; s < total_sections; s++) sec_off[s] = sec_off[s-1] + sec_size[s-1];
	movq	%rdi, 8(%r14,%rax,8)	# D__lsm0.219, MEM[(long int *)sec_off_55 + 8B + ivtmp.279_920 * 8]
# loader.c:185:     for (long s = 1; s < total_sections; s++) sec_off[s] = sec_off[s-1] + sec_size[s-1];
	addq	$1, %rax	#, ivtmp.279
	cmpq	%rax, %rcx	# ivtmp.279, max_section
	jg	.L278	#,
.L277:
# loader.c:189:     for (unsigned i = 0; i < nodes; i++) {
	testl	%esi, %esi	# nodes
	je	.L279	#,
.L276:
# loader.c:189:     for (unsigned i = 0; i < nodes; i++) {
	xorl	%r10d, %r10d	# i
	.p2align 4
	.p2align 3
.L283:
# loader.c:190:         if (node[i].machine_type == UEEC_MACHINE_TYPE_CPU && node[i].machine == HOST_MACHINE) {
	movl	(%rdx), %ecx	# MEM[(int *)_935],
	testl	%ecx, %ecx	#
	jne	.L280	#,
# loader.c:190:         if (node[i].machine_type == UEEC_MACHINE_TYPE_CPU && node[i].machine == HOST_MACHINE) {
	cmpl	$10, 4(%rdx)	#, MEM[(int *)_935 + 4B]
	je	.L534	#,
.L280:
# loader.c:189:     for (unsigned i = 0; i < nodes; i++) {
	addl	$1, %r10d	#, i
# loader.c:189:     for (unsigned i = 0; i < nodes; i++) {
	addq	$12, %rdx	#, ivtmp.274
	cmpl	%esi, %r10d	# nodes, i
	jne	.L283	#,
.L279:
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:111:   return __fprintf_chk (__stream, __USE_FORTIFY_LEVEL - 1, __fmt,
	movq	stderr(%rip), %rcx	# stderr,
	movl	$17, %edx	#,
	movl	$1, %esi	#,
	leaq	.LC12(%rip), %rdi	#,
	call	fwrite@PLT	#
# loader.c:194:     if (chosen < 0) { fprintf(stderr, "no matching node\n"); return 1; }
	jmp	.L253	#
	.p2align 4,,10
	.p2align 3
.L256:
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:111:   return __fprintf_chk (__stream, __USE_FORTIFY_LEVEL - 1, __fmt,
	movq	stderr(%rip), %rcx	# stderr,
	movl	$14, %edx	#,
	movl	$1, %esi	#,
	leaq	.LC10(%rip), %rdi	#,
	call	fwrite@PLT	#
# loader.c:145:         fprintf(stderr, "invalid magic\n"); return 1;
	jmp	.L253	#
	.p2align 4,,10
	.p2align 3
.L248:
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:111:   return __fprintf_chk (__stream, __USE_FORTIFY_LEVEL - 1, __fmt,
	movq	0(%r13), %rcx	# *argv_283(D), *argv_283(D)
	movq	stderr(%rip), %rdi	# stderr,
	leaq	.LC6(%rip), %rdx	#,
	xorl	%eax, %eax	#
	movl	$2, %esi	#,
	call	__fprintf_chk@PLT	#
# loader.c:132:     if (!path) { fprintf(stderr, "usage: %s [--L=monolithic|scattered] <file.ueec>\n", argv[0]); return 1; }
	jmp	.L253	#
.L533:
# loader.c:154:     node_t *node = malloc(sizeof(node_t) * nodes);
	leaq	(%rax,%rax,2), %rdi	#, _613
	movzwl	%ax, %esi	# _299, nodes
	salq	$2, %rdi	#, tmp673
	movl	%esi, (%rsp)	# nodes, %sfp
# loader.c:154:     node_t *node = malloc(sizeof(node_t) * nodes);
	call	malloc@PLT	#
# loader.c:156:     for (unsigned i = 0; i < nodes; i++) {
	movl	(%rsp), %esi	# %sfp, nodes
# loader.c:154:     node_t *node = malloc(sizeof(node_t) * nodes);
	movq	%rax, %rdx	# node, node
# loader.c:156:     for (unsigned i = 0; i < nodes; i++) {
	testl	%esi, %esi	# nodes
	je	.L260	#,
	leal	-1(%rsi), %eax	#, _692
# loader.c:155:     long total_info = 0;
	xorl	%r8d, %r8d	# total_info
# loader.c:151:     size_t off = 8;
	movl	$8, %ecx	#, off
	leaq	(%rax,%rax,2), %r13	#, _724
	addq	%r13, %r13	# tmp688
	leaq	14(%r13), %r15	#, off
	.p2align 6
	.p2align 4
	.p2align 3
.L262:
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movl	(%r12,%rcx), %eax	# MEM <unsigned int> [(char * {ref-all})buf_209 + off_837 * 1], _832
# loader.c:158:         node[i].machine_type = (v >> 7) & 0x7;
	movl	%eax, %edi	# _832, _829
	shrl	$7, %edi	#, _829
# loader.c:158:         node[i].machine_type = (v >> 7) & 0x7;
	andl	$7, %edi	#, tmp690
	movl	%edi, -16(%rdx,%rcx,2)	# tmp690, MEM[(int *)node_617 + -16B + off_837 * 2]
# loader.c:159:         node[i].machine = (v >> 10) & 0xFF;
	movl	%eax, %edi	# _832, _822
# loader.c:160:         node[i].section_count = ((v >> 27) & 0x1F) + 1;
	shrl	$27, %eax	#,
# loader.c:159:         node[i].machine = (v >> 10) & 0xFF;
	shrl	$10, %edi	#, _822
# loader.c:161:         total_info += node[i].section_count - 1; // HEADER ar iTvleba node_info-Si
	addq	%rax, %r8	# _814, total_info
# loader.c:159:         node[i].machine = (v >> 10) & 0xFF;
	andl	$255, %edi	#, tmp692
	movl	%edi, -12(%rdx,%rcx,2)	# tmp692, MEM[(int *)node_617 + -12B + off_837 * 2]
# loader.c:160:         node[i].section_count = ((v >> 27) & 0x1F) + 1;
	leal	1(%rax), %edi	#, tmp693
	movl	%edi, -8(%rdx,%rcx,2)	# tmp693, MEM[(int *)node_617 + -8B + off_837 * 2]
# loader.c:163:         off += 2; // format
	addq	$6, %rcx	#, off
# loader.c:156:     for (unsigned i = 0; i < nodes; i++) {
	cmpq	%rcx, %r15	# off, off
	jne	.L262	#,
# loader.c:167:     info_t *info = malloc(sizeof(info_t) * total_info);
	leaq	0(,%r8,8), %r14	#, _507
	movl	%esi, 24(%rsp)	# nodes, %sfp
# loader.c:167:     info_t *info = malloc(sizeof(info_t) * total_info);
	movq	%r14, %rdi	# _507,
	movq	%rdx, 16(%rsp)	# node, %sfp
# loader.c:167:     info_t *info = malloc(sizeof(info_t) * total_info);
	movq	%r8, 8(%rsp)	# total_info, %sfp
# loader.c:167:     info_t *info = malloc(sizeof(info_t) * total_info);
	call	malloc@PLT	#
# loader.c:169:     for (long i = 0; i < total_info; i++) {
	movq	8(%rsp), %r8	# %sfp, total_info
	movq	16(%rsp), %rdx	# %sfp, node
# loader.c:167:     info_t *info = malloc(sizeof(info_t) * total_info);
	movq	%rax, (%rsp)	# info, %sfp
# loader.c:169:     for (long i = 0; i < total_info; i++) {
	movl	24(%rsp), %esi	# %sfp, nodes
	testq	%r8, %r8	# total_info
	jle	.L266	#,
	movq	%rax, %r9	# info, ivtmp.313
	leaq	2(%r12,%r15), %rdi	#, ivtmp.314
	leaq	(%rax,%r14), %r10	#, _732
# loader.c:168:     long max_section = 0;
	xorl	%ecx, %ecx	# max_section
	.p2align 6
	.p2align 4
	.p2align 3
.L267:
# loader.c:171:         info[i].s = rd32(buf + off, file_endian); off += 4;
	movslq	(%rdi), %rax	# MEM <unsigned int> [(char * {ref-all})_50],
# loader.c:170:         info[i].n = rd16(buf + off, file_endian); off += 2;
	movzwl	-2(%rdi), %r11d	# MEM <unsigned short> [(char * {ref-all})_50 + -2B], _798
# loader.c:170:         info[i].n = rd16(buf + off, file_endian); off += 2;
	movd	%eax, %xmm1	# _790, _790
# loader.c:170:         info[i].n = rd16(buf + off, file_endian); off += 2;
	movd	%r11d, %xmm0	# _798, _798
# loader.c:172:         if (info[i].s > max_section) max_section = info[i].s;
	cmpq	%rax, %rcx	# _787, max_section
# loader.c:170:         info[i].n = rd16(buf + off, file_endian); off += 2;
	punpckldq	%xmm1, %xmm0	# _790, _960
# loader.c:172:         if (info[i].s > max_section) max_section = info[i].s;
	cmovl	%rax, %rcx	# max_section,, _787, max_section
# loader.c:169:     for (long i = 0; i < total_info; i++) {
	addq	$8, %r9	#, ivtmp.313
	addq	$6, %rdi	#, ivtmp.314
# loader.c:170:         info[i].n = rd16(buf + off, file_endian); off += 2;
	movq	%xmm0, -8(%r9)	# _960, MEM <vector(2) int> [(int *)_747]
# loader.c:169:     for (long i = 0; i < total_info; i++) {
	cmpq	%r10, %r9	# _732, ivtmp.313
	jne	.L267	#,
	jmp	.L520	#
.L534:
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:118:   return __printf_chk (__USE_FORTIFY_LEVEL - 1, __fmt, __va_arg_pack ());
	movl	%r10d, %edx	# i,
	xorl	%eax, %eax	#
	movq	%rbp, %rcx	# load_mode,
	movl	$2, %edi	#,
	leaq	.LC11(%rip), %rsi	#,
	movq	%r8, 24(%rsp)	# total_info, %sfp
	movq	%r9, 16(%rsp)	# sec_type, %sfp
	movl	%r10d, 8(%rsp)	# i, %sfp
	call	__printf_chk@PLT	#
# loader.c:200:     for (long e = 0; e < total_info; e++) {
	movq	24(%rsp), %r8	# %sfp, total_info
	movl	8(%rsp), %r10d	# %sfp, i
	movq	16(%rsp), %r9	# %sfp, sec_type
	testq	%r8, %r8	# total_info
	jle	.L535	#,
	movq	(%rsp), %rax	# %sfp, ivtmp.268
# loader.c:198:     int resident_g[8], resident_type[8], n_resident = 0;
	xorl	%r15d, %r15d	# n_resident
	leaq	(%rax,%r8,8), %rsi	#, _240
# loader.c:199:     int reloc_g[8], n_reloc = 0;
	xorl	%r8d, %r8d	# n_reloc
	jmp	.L286	#
	.p2align 4,,10
	.p2align 3
.L285:
# loader.c:204:         else { resident_type[n_resident] = sec_type[s]; resident_g[n_resident] = s; n_resident++; }
	movslq	%r15d, %rdi	# n_resident, n_resident
# loader.c:204:         else { resident_type[n_resident] = sec_type[s]; resident_g[n_resident] = s; n_resident++; }
	addl	$1, %r15d	#, n_resident
# loader.c:204:         else { resident_type[n_resident] = sec_type[s]; resident_g[n_resident] = s; n_resident++; }
	movl	%ecx, 128(%rsp,%rdi,4)	# _77, resident_type[n_resident_496]
# loader.c:204:         else { resident_type[n_resident] = sec_type[s]; resident_g[n_resident] = s; n_resident++; }
	movl	%edx, 96(%rsp,%rdi,4)	# s, resident_g[n_resident_496]
.L284:
# loader.c:200:     for (long e = 0; e < total_info; e++) {
	addq	$8, %rax	#, ivtmp.268
	cmpq	%rax, %rsi	# ivtmp.268, _240
	je	.L536	#,
.L286:
# loader.c:201:         if (info[e].n != chosen) continue;
	cmpl	%r10d, (%rax)	# i, MEM[(int *)_442]
	jne	.L284	#,
# loader.c:202:         int s = info[e].s;
	movslq	4(%rax), %rcx	# MEM[(int *)_442 + 4B],
	movq	%rcx, %rdx	#,
# loader.c:203:         if (sec_type[s] == UEEC_SECTION_RELOCATION) reloc_g[n_reloc++] = s;
	movl	(%r9,%rcx,4), %ecx	# *_76, _77
# loader.c:203:         if (sec_type[s] == UEEC_SECTION_RELOCATION) reloc_g[n_reloc++] = s;
	cmpl	$5, %ecx	#, _77
	jne	.L285	#,
# loader.c:203:         if (sec_type[s] == UEEC_SECTION_RELOCATION) reloc_g[n_reloc++] = s;
	movslq	%r8d, %rcx	# n_reloc, n_reloc
# loader.c:203:         if (sec_type[s] == UEEC_SECTION_RELOCATION) reloc_g[n_reloc++] = s;
	addl	$1, %r8d	#, n_reloc
# loader.c:203:         if (sec_type[s] == UEEC_SECTION_RELOCATION) reloc_g[n_reloc++] = s;
	movl	%edx, 160(%rsp,%rcx,4)	# s, reloc_g[n_reloc_498]
	jmp	.L284	#
.L536:
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:118:   return __printf_chk (__USE_FORTIFY_LEVEL - 1, __fmt, __va_arg_pack ());
	leaq	.LC13(%rip), %rsi	#,
	movl	%r8d, %ecx	# n_reloc, n_reloc
	movl	%r15d, %edx	# n_resident,
	xorl	%eax, %eax	#
	movl	$2, %edi	#,
	movl	%r8d, 16(%rsp)	# n_reloc, %sfp
	call	__printf_chk@PLT	#
# loader.c:212:     long *local_off_in_mono = malloc(sizeof(long) * n_resident);
	movslq	%r15d, %rax	# n_resident, _723
# loader.c:212:     long *local_off_in_mono = malloc(sizeof(long) * n_resident);
	leaq	0(,%rax,8), %rdi	#, _785
# loader.c:212:     long *local_off_in_mono = malloc(sizeof(long) * n_resident);
	movq	%rax, 40(%rsp)	# _723, %sfp
	call	malloc@PLT	#
# loader.c:214:     if (!strcmp(load_mode, "monolithic")) {
	leaq	.LC3(%rip), %rsi	#,
	movq	%rbp, %rdi	# load_mode,
# loader.c:212:     long *local_off_in_mono = malloc(sizeof(long) * n_resident);
	movq	%rax, (%rsp)	#, %sfp
# loader.c:214:     if (!strcmp(load_mode, "monolithic")) {
	call	strcmp@PLT	#
# loader.c:214:     if (!strcmp(load_mode, "monolithic")) {
	testl	%eax, %eax	# _80
	jne	.L287	#,
# loader.c:216:         for (int i = 0; i < n_resident; i++) {
	testl	%r15d, %r15d	# n_resident
	je	.L288	#,
# loader.c:218:             long padded = ((sec_size[resident_g[i]] + 15) / 16) * 16; // 16-byte alignment
	movslq	96(%rsp), %rax	# resident_g[0], _755
# loader.c:217:             local_off_in_mono[i] = total;
	movq	(%rsp), %rcx	# %sfp, local_off_in_mono
# loader.c:218:             long padded = ((sec_size[resident_g[i]] + 15) / 16) * 16; // 16-byte alignment
	movq	0(%r13,%rax,8), %rax	# *_757, *_757
# loader.c:217:             local_off_in_mono[i] = total;
	movq	$0, (%rcx)	#, *local_off_in_mono_229
# loader.c:218:             long padded = ((sec_size[resident_g[i]] + 15) / 16) * 16; // 16-byte alignment
	leaq	30(%rax), %rdx	#, tmp766
	addq	$15, %rax	#, _759
	cmovs	%rdx, %rax	# tmp766,, _759
	andq	$-16, %rax	#, _759
	movq	%rax, %rsi	# _759, total
# loader.c:216:         for (int i = 0; i < n_resident; i++) {
	cmpl	$1, %r15d	#, n_resident
	je	.L289	#,
# loader.c:217:             local_off_in_mono[i] = total;
	movq	%rax, 8(%rcx)	# total, MEM[(long int *)local_off_in_mono_229 + 8B]
# loader.c:218:             long padded = ((sec_size[resident_g[i]] + 15) / 16) * 16; // 16-byte alignment
	movslq	100(%rsp), %rax	# resident_g[1], _472
# loader.c:218:             long padded = ((sec_size[resident_g[i]] + 15) / 16) * 16; // 16-byte alignment
	movq	0(%r13,%rax,8), %rdx	# *_476, *_476
# loader.c:218:             long padded = ((sec_size[resident_g[i]] + 15) / 16) * 16; // 16-byte alignment
	leaq	30(%rdx), %rax	#, tmp780
	addq	$15, %rdx	#, _478
	cmovns	%rdx, %rax	# tmp780,, _478, _478
	andq	$-16, %rax	#, padded_218
# loader.c:219:             total += padded;
	addq	%rax, %rsi	# padded_218, total
# loader.c:216:         for (int i = 0; i < n_resident; i++) {
	cmpl	$2, %r15d	#, n_resident
	je	.L289	#,
# loader.c:218:             long padded = ((sec_size[resident_g[i]] + 15) / 16) * 16; // 16-byte alignment
	movslq	104(%rsp), %rax	# resident_g[2], _317
# loader.c:217:             local_off_in_mono[i] = total;
	movq	%rsi, 16(%rcx)	# total, MEM[(long int *)local_off_in_mono_229 + 16B]
# loader.c:218:             long padded = ((sec_size[resident_g[i]] + 15) / 16) * 16; // 16-byte alignment
	movq	0(%r13,%rax,8), %rdx	# *_454, *_454
# loader.c:218:             long padded = ((sec_size[resident_g[i]] + 15) / 16) * 16; // 16-byte alignment
	leaq	30(%rdx), %rax	#, tmp796
	addq	$15, %rdx	#, _458
	cmovns	%rdx, %rax	# tmp796,, _458, _458
	andq	$-16, %rax	#, padded_460
# loader.c:219:             total += padded;
	addq	%rax, %rsi	# padded_460, total
# loader.c:216:         for (int i = 0; i < n_resident; i++) {
	cmpl	$3, %r15d	#, n_resident
	je	.L289	#,
# loader.c:218:             long padded = ((sec_size[resident_g[i]] + 15) / 16) * 16; // 16-byte alignment
	movslq	108(%rsp), %rax	# resident_g[3], _855
# loader.c:217:             local_off_in_mono[i] = total;
	movq	%rsi, 24(%rcx)	# total, MEM[(long int *)local_off_in_mono_229 + 24B]
# loader.c:218:             long padded = ((sec_size[resident_g[i]] + 15) / 16) * 16; // 16-byte alignment
	movq	0(%r13,%rax,8), %rdx	# *_856, *_856
# loader.c:218:             long padded = ((sec_size[resident_g[i]] + 15) / 16) * 16; // 16-byte alignment
	leaq	30(%rdx), %rax	#, tmp812
	addq	$15, %rdx	#, _880
	cmovns	%rdx, %rax	# tmp812,, _880, _880
	andq	$-16, %rax	#, padded_882
# loader.c:219:             total += padded;
	addq	%rax, %rsi	# padded_882, total
# loader.c:216:         for (int i = 0; i < n_resident; i++) {
	cmpl	$4, %r15d	#, n_resident
	je	.L289	#,
# loader.c:218:             long padded = ((sec_size[resident_g[i]] + 15) / 16) * 16; // 16-byte alignment
	movslq	112(%rsp), %rax	# resident_g[4], _893
# loader.c:217:             local_off_in_mono[i] = total;
	movq	%rsi, 32(%rcx)	# total, MEM[(long int *)local_off_in_mono_229 + 32B]
# loader.c:218:             long padded = ((sec_size[resident_g[i]] + 15) / 16) * 16; // 16-byte alignment
	movq	0(%r13,%rax,8), %rdx	# *_895, *_895
# loader.c:218:             long padded = ((sec_size[resident_g[i]] + 15) / 16) * 16; // 16-byte alignment
	leaq	30(%rdx), %rax	#, tmp828
	addq	$15, %rdx	#, _897
	cmovns	%rdx, %rax	# tmp828,, _897, _897
	andq	$-16, %rax	#, padded_899
# loader.c:219:             total += padded;
	addq	%rax, %rsi	# padded_899, total
# loader.c:216:         for (int i = 0; i < n_resident; i++) {
	cmpl	$5, %r15d	#, n_resident
	je	.L289	#,
# loader.c:218:             long padded = ((sec_size[resident_g[i]] + 15) / 16) * 16; // 16-byte alignment
	movslq	116(%rsp), %rax	# resident_g[5], _910
# loader.c:217:             local_off_in_mono[i] = total;
	movq	%rsi, 40(%rcx)	# total, MEM[(long int *)local_off_in_mono_229 + 40B]
# loader.c:218:             long padded = ((sec_size[resident_g[i]] + 15) / 16) * 16; // 16-byte alignment
	movq	0(%r13,%rax,8), %rdx	# *_912, *_912
# loader.c:218:             long padded = ((sec_size[resident_g[i]] + 15) / 16) * 16; // 16-byte alignment
	leaq	30(%rdx), %rax	#, tmp844
	addq	$15, %rdx	#, _914
	cmovns	%rdx, %rax	# tmp844,, _914, _914
	andq	$-16, %rax	#, padded_916
# loader.c:219:             total += padded;
	addq	%rax, %rsi	# padded_916, total
# loader.c:216:         for (int i = 0; i < n_resident; i++) {
	cmpl	$6, %r15d	#, n_resident
	je	.L289	#,
# loader.c:218:             long padded = ((sec_size[resident_g[i]] + 15) / 16) * 16; // 16-byte alignment
	movslq	120(%rsp), %rax	# resident_g[6], _927
# loader.c:217:             local_off_in_mono[i] = total;
	movq	%rsi, 48(%rcx)	# total, MEM[(long int *)local_off_in_mono_229 + 48B]
# loader.c:218:             long padded = ((sec_size[resident_g[i]] + 15) / 16) * 16; // 16-byte alignment
	movq	0(%r13,%rax,8), %rdx	# *_929, *_929
# loader.c:218:             long padded = ((sec_size[resident_g[i]] + 15) / 16) * 16; // 16-byte alignment
	leaq	30(%rdx), %rax	#, tmp860
	addq	$15, %rdx	#, _931
	cmovns	%rdx, %rax	# tmp860,, _931, _931
	andq	$-16, %rax	#, padded_933
# loader.c:219:             total += padded;
	addq	%rax, %rsi	# padded_933, total
# loader.c:216:         for (int i = 0; i < n_resident; i++) {
	cmpl	$7, %r15d	#, n_resident
	je	.L289	#,
# loader.c:218:             long padded = ((sec_size[resident_g[i]] + 15) / 16) * 16; // 16-byte alignment
	movslq	124(%rsp), %rax	# resident_g[7], _85
# loader.c:217:             local_off_in_mono[i] = total;
	movq	%rsi, 56(%rcx)	# total, MEM[(long int *)local_off_in_mono_229 + 56B]
# loader.c:218:             long padded = ((sec_size[resident_g[i]] + 15) / 16) * 16; // 16-byte alignment
	movq	0(%r13,%rax,8), %rdx	# *_87, *_87
# loader.c:218:             long padded = ((sec_size[resident_g[i]] + 15) / 16) * 16; // 16-byte alignment
	leaq	30(%rdx), %rax	#, tmp876
	addq	$15, %rdx	#, _89
	cmovns	%rdx, %rax	# tmp876,, _89, _89
	andq	$-16, %rax	#, padded_238
# loader.c:219:             total += padded;
	addq	%rax, %rsi	# padded_238, total
.L289:
# loader.c:221:         mono_mem = mmap(NULL, total, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
	movl	$34, %ecx	#,
	xorl	%r9d, %r9d	#
	movl	$-1, %r8d	#,
	xorl	%edi, %edi	#
	movl	$3, %edx	#,
	movq	%rsi, 56(%rsp)	# total, %sfp
	xorl	%ebp, %ebp	# ivtmp.252
	call	mmap@PLT	#
	movl	%r15d, 64(%rsp)	# n_resident, %sfp
	movq	40(%rsp), %r15	# %sfp, _723
	movq	%rax, %rcx	# mono_mem, mono_mem
	leaq	192(%rsp), %rax	#, tmp1065
	movl	%ebx, 48(%rsp)	# trace_reloc, %sfp
	movq	%rax, 24(%rsp)	# tmp1065, %sfp
	leaq	96(%rsp), %rax	#, tmp1436
	movq	%rcx, %rbx	# mono_mem, mono_mem
	movq	%rax, 8(%rsp)	# tmp1436, %sfp
	.p2align 4
	.p2align 3
.L290:
# loader.c:223:             local_base[i] = (uint8_t *)mono_mem + local_off_in_mono[i];
	movq	(%rsp), %rax	# %sfp, local_off_in_mono
	movq	(%rax,%rbp,8), %rdi	# MEM[(long int *)local_off_in_mono_229 + ivtmp.252_578 * 8], _97
# loader.c:223:             local_base[i] = (uint8_t *)mono_mem + local_off_in_mono[i];
	movq	24(%rsp), %rax	# %sfp, tmp1065
# loader.c:223:             local_base[i] = (uint8_t *)mono_mem + local_off_in_mono[i];
	addq	%rbx, %rdi	# mono_mem, _97
# loader.c:223:             local_base[i] = (uint8_t *)mono_mem + local_off_in_mono[i];
	movq	%rdi, (%rax,%rbp,8)	# _97, MEM[(void * *)&local_base + ivtmp.252_578 * 8]
# loader.c:224:             memcpy(local_base[i], buf + sec_off[resident_g[i]], sec_size[resident_g[i]]);
	movq	8(%rsp), %rax	# %sfp, tmp1061
	movslq	(%rax,%rbp,4), %rax	# MEM[(int *)&resident_g + ivtmp.252_578 * 4], _99
# loader.c:222:         for (int i = 0; i < n_resident; i++) {
	addq	$1, %rbp	#, ivtmp.252
# loader.c:224:             memcpy(local_base[i], buf + sec_off[resident_g[i]], sec_size[resident_g[i]]);
	movq	(%r14,%rax,8), %rsi	# *_104, _107
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movq	0(%r13,%rax,8), %rdx	# *_101, *_101
# loader.c:224:             memcpy(local_base[i], buf + sec_off[resident_g[i]], sec_size[resident_g[i]]);
	addq	%r12, %rsi	# buf, _107
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	call	memcpy@PLT	#
# loader.c:222:         for (int i = 0; i < n_resident; i++) {
	cmpq	%r15, %rbp	# _723, ivtmp.252
	jne	.L290	#,
	movq	%rbx, %rcx	# mono_mem, mono_mem
	movq	56(%rsp), %rsi	# %sfp, total
	movl	48(%rsp), %ebx	# %sfp, trace_reloc
	movl	64(%rsp), %r15d	# %sfp, n_resident
.L291:
# loader.c:238:     for (int i = 0; i < n_resident; ++i) resident_sizes[i] = (size_t)sec_size[resident_g[i]];
	movslq	96(%rsp), %rax	# resident_g[0], _537
# loader.c:238:     for (int i = 0; i < n_resident; ++i) resident_sizes[i] = (size_t)sec_size[resident_g[i]];
	movq	0(%r13,%rax,8), %rax	# *_535, *_535
	movq	%rax, 256(%rsp)	# *_535, resident_sizes[0]
# loader.c:238:     for (int i = 0; i < n_resident; ++i) resident_sizes[i] = (size_t)sec_size[resident_g[i]];
	cmpl	$1, %r15d	#, n_resident
	je	.L297	#,
# loader.c:238:     for (int i = 0; i < n_resident; ++i) resident_sizes[i] = (size_t)sec_size[resident_g[i]];
	movslq	100(%rsp), %rax	# resident_g[1], _509
# loader.c:238:     for (int i = 0; i < n_resident; ++i) resident_sizes[i] = (size_t)sec_size[resident_g[i]];
	movq	0(%r13,%rax,8), %rax	# *_488, *_488
	movq	%rax, 264(%rsp)	# *_488, resident_sizes[1]
# loader.c:238:     for (int i = 0; i < n_resident; ++i) resident_sizes[i] = (size_t)sec_size[resident_g[i]];
	cmpl	$2, %r15d	#, n_resident
	je	.L297	#,
# loader.c:238:     for (int i = 0; i < n_resident; ++i) resident_sizes[i] = (size_t)sec_size[resident_g[i]];
	movslq	104(%rsp), %rax	# resident_g[2], _433
# loader.c:238:     for (int i = 0; i < n_resident; ++i) resident_sizes[i] = (size_t)sec_size[resident_g[i]];
	movq	0(%r13,%rax,8), %rax	# *_429, *_429
	movq	%rax, 272(%rsp)	# *_429, resident_sizes[2]
# loader.c:238:     for (int i = 0; i < n_resident; ++i) resident_sizes[i] = (size_t)sec_size[resident_g[i]];
	cmpl	$3, %r15d	#, n_resident
	je	.L297	#,
# loader.c:238:     for (int i = 0; i < n_resident; ++i) resident_sizes[i] = (size_t)sec_size[resident_g[i]];
	movslq	108(%rsp), %rax	# resident_g[3], _346
# loader.c:238:     for (int i = 0; i < n_resident; ++i) resident_sizes[i] = (size_t)sec_size[resident_g[i]];
	movq	0(%r13,%rax,8), %rax	# *_312, *_312
	movq	%rax, 280(%rsp)	# *_312, resident_sizes[3]
# loader.c:238:     for (int i = 0; i < n_resident; ++i) resident_sizes[i] = (size_t)sec_size[resident_g[i]];
	cmpl	$4, %r15d	#, n_resident
	je	.L297	#,
# loader.c:238:     for (int i = 0; i < n_resident; ++i) resident_sizes[i] = (size_t)sec_size[resident_g[i]];
	movslq	112(%rsp), %rax	# resident_g[4], _264
# loader.c:238:     for (int i = 0; i < n_resident; ++i) resident_sizes[i] = (size_t)sec_size[resident_g[i]];
	movq	0(%r13,%rax,8), %rax	# *_249, *_249
	movq	%rax, 288(%rsp)	# *_249, resident_sizes[4]
# loader.c:238:     for (int i = 0; i < n_resident; ++i) resident_sizes[i] = (size_t)sec_size[resident_g[i]];
	cmpl	$5, %r15d	#, n_resident
	je	.L297	#,
# loader.c:238:     for (int i = 0; i < n_resident; ++i) resident_sizes[i] = (size_t)sec_size[resident_g[i]];
	movslq	116(%rsp), %rax	# resident_g[5], _183
# loader.c:238:     for (int i = 0; i < n_resident; ++i) resident_sizes[i] = (size_t)sec_size[resident_g[i]];
	movq	0(%r13,%rax,8), %rax	# *_179, *_179
	movq	%rax, 296(%rsp)	# *_179, resident_sizes[5]
# loader.c:238:     for (int i = 0; i < n_resident; ++i) resident_sizes[i] = (size_t)sec_size[resident_g[i]];
	cmpl	$6, %r15d	#, n_resident
	je	.L297	#,
# loader.c:238:     for (int i = 0; i < n_resident; ++i) resident_sizes[i] = (size_t)sec_size[resident_g[i]];
	movslq	120(%rsp), %rax	# resident_g[6], _166
# loader.c:238:     for (int i = 0; i < n_resident; ++i) resident_sizes[i] = (size_t)sec_size[resident_g[i]];
	movq	0(%r13,%rax,8), %rax	# *_159, *_159
	movq	%rax, 304(%rsp)	# *_159, resident_sizes[6]
# loader.c:238:     for (int i = 0; i < n_resident; ++i) resident_sizes[i] = (size_t)sec_size[resident_g[i]];
	cmpl	$7, %r15d	#, n_resident
	je	.L297	#,
# loader.c:238:     for (int i = 0; i < n_resident; ++i) resident_sizes[i] = (size_t)sec_size[resident_g[i]];
	movslq	124(%rsp), %rax	# resident_g[7], _122
# loader.c:238:     for (int i = 0; i < n_resident; ++i) resident_sizes[i] = (size_t)sec_size[resident_g[i]];
	movq	0(%r13,%rax,8), %rax	# *_124, *_124
	movq	%rax, 312(%rsp)	# *_124, resident_sizes[7]
.L297:
# loader.c:239:     for (int r = 0; r < n_reloc; ++r) {
	movl	16(%rsp), %edx	# %sfp,
	testl	%edx, %edx	#
	je	.L301	#,
.L295:
# loader.c:210:     void *mono_mem = NULL;
	xorl	%r10d, %r10d	# ivtmp.237
	leaq	160(%rsp), %rax	#, tmp1062
	cmpb	$0, 36(%rsp)	#, %sfp
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:118:   return __printf_chk (__USE_FORTIFY_LEVEL - 1, __fmt, __va_arg_pack ());
	movq	%r12, %r11	# buf, buf
	movq	%rax, 24(%rsp)	# tmp1062, %sfp
	movl	%ebx, %r12d	# trace_reloc, trace_reloc
	movq	%r13, 40(%rsp)	# sec_size, %sfp
	movq	%r14, 56(%rsp)	# sec_off, %sfp
	movq	%rsi, 80(%rsp)	# total, %sfp
	movq	%rcx, 88(%rsp)	# mono_mem, %sfp
	movl	%r15d, 48(%rsp)	# n_resident, %sfp
	jne	.L302	#,
	.p2align 4
	.p2align 3
.L322:
# loader.c:240:         int g = reloc_g[r];
	movq	24(%rsp), %rax	# %sfp, tmp1062
# loader.c:241:         if (process_reloc_section(buf + sec_off[g], (size_t)sec_size[g], file_endian,
	movq	40(%rsp), %rbx	# %sfp, sec_size
# loader.c:240:         int g = reloc_g[r];
	movslq	(%rax,%r10,4), %rax	# MEM[(int *)&reloc_g + ivtmp.237_611 * 4],
# loader.c:241:         if (process_reloc_section(buf + sec_off[g], (size_t)sec_size[g], file_endian,
	movq	(%rbx,%rax,8), %rsi	# *_716, _714
# loader.c:240:         int g = reloc_g[r];
	movl	%eax, 36(%rsp)	# g, %sfp
# loader.c:97:     if (len < 8) return -1;
	cmpq	$7, %rsi	#, _714
	jbe	.L312	#,
# loader.c:241:         if (process_reloc_section(buf + sec_off[g], (size_t)sec_size[g], file_endian,
	movq	56(%rsp), %rcx	# %sfp, sec_off
	movq	(%rcx,%rax,8), %rbx	# *_713, _710
	addq	%r11, %rbx	# buf, _710
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movzwl	4(%rbx), %r8d	# MEM <unsigned short> [(char * {ref-all})_710 + 4B], pretmp_706
# loader.c:241:         if (process_reloc_section(buf + sec_off[g], (size_t)sec_size[g], file_endian,
	movq	%rbx, %rax	# _710, _710
	movl	%r8d, %r9d	# pretmp_706, _690
# loader.c:100:     int target = couple & 31, source = (couple >> 5) & 31;
	movl	%r8d, %edx	# pretmp_706, target
# loader.c:100:     int target = couple & 31, source = (couple >> 5) & 31;
	shrl	$5, %r8d	#, _688
# loader.c:100:     int target = couple & 31, source = (couple >> 5) & 31;
	andl	$31, %edx	#, target
	andl	$31, %r8d	#, _687
	andl	$31, %r9d	#, _690
# loader.c:101:     if (target >= n || source >= n) return -1;
	movl	%edx, %ecx	# target, _685
	cmpl	%edx, %r8d	# target, _687
	cmovge	%r8d, %ecx	# _687,, _685
	cmpl	%ecx, 48(%rsp)	# _685, %sfp
	jle	.L312	#,
# loader.c:98:     unsigned format = rd16(rp, endian), design = rd16(rp+2, endian);
	movzwl	2(%rax), %ebp	# MEM <unsigned short> [(char * {ref-all})_710 + 2B], design
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movzwl	(%rbx), %ebx	# MEM <unsigned short> [(char * {ref-all})_710], _709
# loader.c:102:     rp += 8; len -= 8;
	subq	$8, %rsi	#, len
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movzwl	6(%rax), %ecx	# MEM <unsigned short> [(char * {ref-all})_710 + 6B],
# loader.c:103:     if (design == 0) {
	testl	%ebp, %ebp	# design
	jne	.L537	#,
# loader.c:104:         if (format != 0 || count > len/2) return -1;
	testw	%bx, %bx	# _709
	jne	.L312	#,
# loader.c:104:         if (format != 0 || count > len/2) return -1;
	shrq	%rsi	# _659
# loader.c:104:         if (format != 0 || count > len/2) return -1;
	cmpq	%rcx, %rsi	# _660, _659
	jb	.L312	#,
# loader.c:105:         for (unsigned e = 0; e < count; ++e) {
	testl	%ecx, %ecx	# count
	je	.L308	#,
# loader.c:109:             if (type > 1 || offset > sizes[target] || bytes > sizes[target]-offset) return -1;
	movzwl	%r9w, %esi	# _690, _658
	subl	$1, %ecx	#, _936
	movq	%r10, 64(%rsp)	# ivtmp.237, %sfp
	leaq	8(%rax), %rbp	#, ivtmp.234
	salq	$3, %rsi	#, _657
	movl	%r8d, (%rsp)	# _687, %sfp
	leaq	10(%rax,%rcx,2), %r14	#, _610
# loader.c:55:     void *target_addr = (uint8_t *)local_base[target] + patch_offset;
	leaq	192(%rsp,%rsi), %rbx	#, _655
# loader.c:109:             if (type > 1 || offset > sizes[target] || bytes > sizes[target]-offset) return -1;
	leaq	256(%rsp,%rsi), %r13	#, _656
# loader.c:56:     unsigned long source_base = (unsigned long)local_base[source];
	movl	%r8d, %esi	# _687, _654
	movl	%edx, 8(%rsp)	# target, %sfp
	movq	%rbx, %r15	# _655, _655
	movq	%r11, 72(%rsp)	# buf, %sfp
	leaq	192(%rsp,%rsi,8), %rbx	#, _652
	jmp	.L317	#
	.p2align 4,,10
	.p2align 3
.L314:
# loader.c:109:             if (type > 1 || offset > sizes[target] || bytes > sizes[target]-offset) return -1;
	ja	.L312	#,
	movl	$4, %esi	#, bytes
.L321:
# loader.c:109:             if (type > 1 || offset > sizes[target] || bytes > sizes[target]-offset) return -1;
	movq	0(%r13), %rax	# *_656, _640
# loader.c:107:             size_t offset = v & 0xFFF; unsigned type = v >> 12;
	andl	$4095, %ecx	#, offset
# loader.c:109:             if (type > 1 || offset > sizes[target] || bytes > sizes[target]-offset) return -1;
	cmpq	%rcx, %rax	# offset, _640
	jb	.L312	#,
# loader.c:109:             if (type > 1 || offset > sizes[target] || bytes > sizes[target]-offset) return -1;
	subq	%rcx, %rax	# offset, _639
# loader.c:109:             if (type > 1 || offset > sizes[target] || bytes > sizes[target]-offset) return -1;
	cmpq	%rsi, %rax	# bytes, _639
	jb	.L312	#,
# loader.c:55:     void *target_addr = (uint8_t *)local_base[target] + patch_offset;
	movq	(%r15), %rax	# *_655, target_addr
# loader.c:56:     unsigned long source_base = (unsigned long)local_base[source];
	movq	(%rbx), %rsi	# *_652, source_base
# loader.c:55:     void *target_addr = (uint8_t *)local_base[target] + patch_offset;
	addq	%rcx, %rax	# offset, target_addr
# loader.c:57:     if (type == 1) { // ABS64
	cmpw	$1, %dx	#, _644
	je	.L538	#,
# loader.c:63:         uint32_t patched = (uint32_t)(source_base + addend);
	addl	%esi, (%rax)	# source_base, MEM <unsigned int> [(char * {ref-all})target_addr_637]
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	testl	%r12d, %r12d	# trace_reloc
	je	.L318	#,
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	leaq	.LC0(%rip), %r9	#, iftmp.36_632
.L319:
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:118:   return __printf_chk (__USE_FORTIFY_LEVEL - 1, __fmt, __va_arg_pack ());
	movl	(%rsp), %r8d	# %sfp,
	movl	8(%rsp), %edx	# %sfp,
	movl	$2, %edi	#,
	xorl	%eax, %eax	#
	leaq	.LC2(%rip), %rsi	#,
	call	__printf_chk@PLT	#
.L318:
# loader.c:105:         for (unsigned e = 0; e < count; ++e) {
	addq	$2, %rbp	#, ivtmp.234
	cmpq	%rbp, %r14	# ivtmp.234, _610
	je	.L539	#,
.L317:
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movzwl	0(%rbp), %ecx	# MEM <unsigned short> [(char * {ref-all})_939], _646
# loader.c:107:             size_t offset = v & 0xFFF; unsigned type = v >> 12;
	movl	%ecx, %edx	# _646, _644
	shrw	$12, %dx	#, _644
# loader.c:108:             size_t bytes = type == 1 ? 8 : 4;
	cmpw	$1, %dx	#, _644
	jne	.L314	#,
# loader.c:108:             size_t bytes = type == 1 ? 8 : 4;
	movl	$8, %esi	#, bytes
	jmp	.L321	#
	.p2align 4,,10
	.p2align 3
.L302:
# loader.c:240:         int g = reloc_g[r];
	movq	24(%rsp), %rax	# %sfp, tmp1062
# loader.c:241:         if (process_reloc_section(buf + sec_off[g], (size_t)sec_size[g], file_endian,
	movq	40(%rsp), %rbx	# %sfp, sec_size
# loader.c:240:         int g = reloc_g[r];
	movslq	(%rax,%r10,4), %rax	# MEM[(int *)&reloc_g + ivtmp.247_588 * 4],
# loader.c:241:         if (process_reloc_section(buf + sec_off[g], (size_t)sec_size[g], file_endian,
	movq	(%rbx,%rax,8), %rsi	# *_129, _131
# loader.c:240:         int g = reloc_g[r];
	movl	%eax, 36(%rsp)	# g, %sfp
# loader.c:97:     if (len < 8) return -1;
	cmpq	$7, %rsi	#, _131
	jbe	.L312	#,
# loader.c:241:         if (process_reloc_section(buf + sec_off[g], (size_t)sec_size[g], file_endian,
	movq	56(%rsp), %rbx	# %sfp, sec_off
	movq	(%rbx,%rax,8), %rdi	# *_132, _135
	addq	%r11, %rdi	# buf, _135
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movzwl	4(%rdi), %eax	# MEM <unsigned short> [(char * {ref-all})_135 + 4B], pretmp_860
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	movl	%eax, %ebx	# pretmp_860, _350
	movzbl	%ah, %eax	# pretmp_860, _847
	rolw	$8, %bx	#, _350
	movl	%eax, %r9d	# _847, _359
# loader.c:100:     int target = couple & 31, source = (couple >> 5) & 31;
	andl	$31, %eax	#, target
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	movl	%ebx, %r8d	# _350, _350
	andl	$31, %r9d	#, _359
# loader.c:100:     int target = couple & 31, source = (couple >> 5) & 31;
	shrl	$5, %r8d	#, _361
	andl	$31, %r8d	#, _362
# loader.c:101:     if (target >= n || source >= n) return -1;
	cmpl	%r8d, %eax	# _362, target
	movl	%r8d, %edx	# _362, _364
	cmovge	%eax, %edx	# target,, _364
	cmpl	%edx, 48(%rsp)	# _364, %sfp
	jle	.L312	#,
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	movzwl	2(%rdi), %edx	# MEM <unsigned short> [(char * {ref-all})_135 + 2B], _343
	movzwl	6(%rdi), %ecx	# MEM <unsigned short> [(char * {ref-all})_135 + 6B], _352
# loader.c:102:     rp += 8; len -= 8;
	subq	$8, %rsi	#, len
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movzwl	(%rdi), %ebx	# MEM <unsigned short> [(char * {ref-all})_135], _338
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	rolw	$8, %cx	#, _353
	rolw	$8, %dx	#, _344
	movzwl	%cx, %ebp	# _353,
# loader.c:98:     unsigned format = rd16(rp, endian), design = rd16(rp+2, endian);
	movzwl	%dx, %edx	# _344, design
# loader.c:99:     unsigned couple = rd16(rp+4, endian), count = rd16(rp+6, endian);
	movzwl	%bp, %ecx	# _353, count
# loader.c:103:     if (design == 0) {
	testl	%edx, %edx	# design
	jne	.L326	#,
# loader.c:104:         if (format != 0 || count > len/2) return -1;
	testw	%bx, %bx	# _338
	jne	.L312	#,
# loader.c:104:         if (format != 0 || count > len/2) return -1;
	shrq	%rsi	# _370
# loader.c:104:         if (format != 0 || count > len/2) return -1;
	cmpq	%rbp, %rsi	# _369, _370
	jb	.L312	#,
# loader.c:105:         for (unsigned e = 0; e < count; ++e) {
	testl	%ecx, %ecx	# count
	je	.L327	#,
# loader.c:109:             if (type > 1 || offset > sizes[target] || bytes > sizes[target]-offset) return -1;
	movzwl	%r9w, %edx	# _359, _382
	movl	%eax, (%rsp)	# target, %sfp
	leaq	8(%rdi), %rbp	#, ivtmp.244
	salq	$3, %rdx	#, _383
	movl	%r8d, 8(%rsp)	# _362, %sfp
	leaq	256(%rsp,%rdx), %r13	#, _384
# loader.c:55:     void *target_addr = (uint8_t *)local_base[target] + patch_offset;
	leaq	192(%rsp,%rdx), %rbx	#, _410
# loader.c:56:     unsigned long source_base = (unsigned long)local_base[source];
	movl	%r8d, %edx	# _362, _413
	movq	%r10, 64(%rsp)	# ivtmp.247, %sfp
	leaq	192(%rsp,%rdx,8), %r15	#, _415
	leal	-1(%rcx), %edx	#, _571
	movq	%r11, 72(%rsp)	# buf, %sfp
	movq	%r15, %r14	# _415, _415
	leaq	10(%rdi,%rdx,2), %r15	#, _589
	jmp	.L333	#
	.p2align 4,,10
	.p2align 3
.L542:
# loader.c:109:             if (type > 1 || offset > sizes[target] || bytes > sizes[target]-offset) return -1;
	ja	.L312	#,
	movl	$4, %esi	#, bytes
.L328:
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	rolw	$8, %cx	#, _377
# loader.c:109:             if (type > 1 || offset > sizes[target] || bytes > sizes[target]-offset) return -1;
	movq	0(%r13), %rdx	# *_384, _385
# loader.c:107:             size_t offset = v & 0xFFF; unsigned type = v >> 12;
	andl	$4095, %ecx	#, offset
# loader.c:109:             if (type > 1 || offset > sizes[target] || bytes > sizes[target]-offset) return -1;
	cmpq	%rcx, %rdx	# offset, _385
	jb	.L312	#,
# loader.c:109:             if (type > 1 || offset > sizes[target] || bytes > sizes[target]-offset) return -1;
	subq	%rcx, %rdx	# offset, _386
# loader.c:109:             if (type > 1 || offset > sizes[target] || bytes > sizes[target]-offset) return -1;
	cmpq	%rsi, %rdx	# bytes, _386
	jb	.L312	#,
# loader.c:55:     void *target_addr = (uint8_t *)local_base[target] + patch_offset;
	movq	(%rbx), %rdx	# *_410, target_addr
# loader.c:56:     unsigned long source_base = (unsigned long)local_base[source];
	movq	(%r14), %rsi	# *_415, source_base
# loader.c:55:     void *target_addr = (uint8_t *)local_base[target] + patch_offset;
	addq	%rcx, %rdx	# offset, target_addr
# loader.c:57:     if (type == 1) { // ABS64
	cmpw	$1, %ax	#, _381
	je	.L540	#,
# loader.c:63:         uint32_t patched = (uint32_t)(source_base + addend);
	addl	%esi, (%rdx)	# source_base, MEM <unsigned int> [(char * {ref-all})target_addr_412]
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	leaq	.LC0(%rip), %r9	#, iftmp.36_425
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	testl	%r12d, %r12d	# trace_reloc
	je	.L331	#,
.L330:
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:118:   return __printf_chk (__USE_FORTIFY_LEVEL - 1, __fmt, __va_arg_pack ());
	movl	8(%rsp), %r8d	# %sfp,
	movl	(%rsp), %edx	# %sfp,
	movl	$2, %edi	#,
	xorl	%eax, %eax	#
	leaq	.LC2(%rip), %rsi	#,
	call	__printf_chk@PLT	#
.L331:
# loader.c:105:         for (unsigned e = 0; e < count; ++e) {
	addq	$2, %rbp	#, ivtmp.244
	cmpq	%r15, %rbp	# _589, ivtmp.244
	je	.L541	#,
.L333:
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movzwl	0(%rbp), %ecx	# MEM <unsigned short> [(char * {ref-all})_561], _375
# loader.c:107:             size_t offset = v & 0xFFF; unsigned type = v >> 12;
	movl	%ecx, %eax	# _375, _36
	shrb	$4, %al	#, _36
	movzbl	%al, %eax	# _36, _381
# loader.c:108:             size_t bytes = type == 1 ? 8 : 4;
	cmpw	$1, %ax	#, _381
	jne	.L542	#,
# loader.c:108:             size_t bytes = type == 1 ? 8 : 4;
	movl	$8, %esi	#, bytes
	jmp	.L328	#
	.p2align 4,,10
	.p2align 3
.L540:
# loader.c:59:         uint64_t patched = source_base + addend;
	addq	%rsi, (%rdx)	# source_base, MEM <unsigned long> [(char * {ref-all})target_addr_412]
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	testl	%r12d, %r12d	# trace_reloc
	je	.L331	#,
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	leaq	.LC1(%rip), %r9	#, iftmp.36_425
	jmp	.L330	#
	.p2align 4,,10
	.p2align 3
.L538:
# loader.c:59:         uint64_t patched = source_base + addend;
	addq	%rsi, (%rax)	# source_base, MEM <unsigned long> [(char * {ref-all})target_addr_637]
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	testl	%r12d, %r12d	# trace_reloc
	je	.L318	#,
# loader.c:66:     if (trace) printf("  RELOC: local[%d]+0x%zx = local[%d] + addend (type=%s)\n",
	leaq	.LC1(%rip), %r9	#, iftmp.36_632
	jmp	.L319	#
	.p2align 4,,10
	.p2align 3
.L326:
# loader.c:114:     if (design != 1 && design != 2) return -1;
	subl	$1, %edx	#, _390
# loader.c:114:     if (design != 1 && design != 2) return -1;
	cmpl	$1, %edx	#, _390
	ja	.L312	#,
# loader.c:102:     rp += 8; len -= 8;
	addq	$8, %rdi	#, rp
# loader.c:115:     switch (format) {
	cmpw	$256, %bx	#, _338
	je	.L334	#,
	cmpw	$512, %bx	#, _338
	je	.L335	#,
	testw	%bx, %bx	# _338
	jne	.L312	#,
# loader.c:116:         case 0: return process_blocks16(rp,len,endian,count,base,target,source,sizes[target],trace);
	subq	$8, %rsp	#,
	.cfi_def_cfa_offset 408
# loader.c:116:         case 0: return process_blocks16(rp,len,endian,count,base,target,source,sizes[target],trace);
	movzwl	%r9w, %r9d	# _359, _391
# loader.c:116:         case 0: return process_blocks16(rp,len,endian,count,base,target,source,sizes[target],trace);
	movl	$1, %edx	#,
	pushq	%r12	# trace_reloc
	.cfi_def_cfa_offset 416
	pushq	272(%rsp,%r9,8)	# *_393
	.cfi_def_cfa_offset 424
	movl	%eax, %r9d	# target,
	pushq	%r8	# _362
	.cfi_def_cfa_offset 432
	leaq	224(%rsp), %r8	#,
	movq	%r10, 32(%rsp)	# ivtmp.247, %sfp
	movq	%r11, 40(%rsp)	# buf, %sfp
	call	process_blocks16	#
	movq	32(%rsp), %r10	# %sfp, ivtmp.247
	movq	40(%rsp), %r11	# %sfp, buf
	addq	$32, %rsp	#,
	.cfi_def_cfa_offset 400
.L336:
# loader.c:241:         if (process_reloc_section(buf + sec_off[g], (size_t)sec_size[g], file_endian,
	testl	%eax, %eax	# _405
	jne	.L312	#,
.L327:
# loader.c:239:     for (int r = 0; r < n_reloc; ++r) {
	addq	$1, %r10	#, ivtmp.247
	cmpl	%r10d, 16(%rsp)	# ivtmp.247, %sfp
	jg	.L302	#,
	movq	40(%rsp), %r13	# %sfp, sec_size
	movq	80(%rsp), %rsi	# %sfp, total
	movq	88(%rsp), %rcx	# %sfp, mono_mem
	movl	48(%rsp), %r15d	# %sfp, n_resident
.L301:
# loader.c:250:     if (mono_mem) {
	testq	%rcx, %rcx	# mono_mem
	je	.L355	#,
.L356:
# loader.c:252:         mprotect(mono_mem, total_mono_size, PROT_READ | PROT_EXEC | PROT_WRITE);
	movl	$7, %edx	#,
	movq	%rcx, %rdi	# mono_mem,
	call	mprotect@PLT	#
# loader.c:258:         if (resident_type[i] == UEEC_SECTION_CODE && !entry) entry = local_base[i];
	cmpl	$1, 128(%rsp)	#, resident_type[0]
	je	.L337	#,
# loader.c:255:     for (int i = 0; i < n_resident; i++) {
	xorl	%ebx, %ebx	# entry
	cmpl	$1, %r15d	#, n_resident
	je	.L300	#,
.L338:
# loader.c:258:         if (resident_type[i] == UEEC_SECTION_CODE && !entry) entry = local_base[i];
	cmpl	$1, 132(%rsp)	#, resident_type[1]
	jne	.L340	#,
# loader.c:258:         if (resident_type[i] == UEEC_SECTION_CODE && !entry) entry = local_base[i];
	testq	%rbx, %rbx	# entry
	cmove	200(%rsp), %rbx	# local_base[1],, entry
.L340:
# loader.c:255:     for (int i = 0; i < n_resident; i++) {
	cmpl	$2, %r15d	#, n_resident
	je	.L350	#,
# loader.c:258:         if (resident_type[i] == UEEC_SECTION_CODE && !entry) entry = local_base[i];
	cmpl	$1, 136(%rsp)	#, resident_type[2]
	jne	.L341	#,
# loader.c:258:         if (resident_type[i] == UEEC_SECTION_CODE && !entry) entry = local_base[i];
	testq	%rbx, %rbx	# entry
	cmove	208(%rsp), %rbx	# local_base[2],, entry
.L341:
# loader.c:255:     for (int i = 0; i < n_resident; i++) {
	cmpl	$3, %r15d	#, n_resident
	je	.L350	#,
# loader.c:258:         if (resident_type[i] == UEEC_SECTION_CODE && !entry) entry = local_base[i];
	cmpl	$1, 140(%rsp)	#, resident_type[3]
	jne	.L342	#,
# loader.c:258:         if (resident_type[i] == UEEC_SECTION_CODE && !entry) entry = local_base[i];
	testq	%rbx, %rbx	# entry
	cmove	216(%rsp), %rbx	# local_base[3],, entry
.L342:
# loader.c:255:     for (int i = 0; i < n_resident; i++) {
	cmpl	$4, %r15d	#, n_resident
	je	.L350	#,
# loader.c:258:         if (resident_type[i] == UEEC_SECTION_CODE && !entry) entry = local_base[i];
	cmpl	$1, 144(%rsp)	#, resident_type[4]
	jne	.L343	#,
# loader.c:258:         if (resident_type[i] == UEEC_SECTION_CODE && !entry) entry = local_base[i];
	testq	%rbx, %rbx	# entry
	cmove	224(%rsp), %rbx	# local_base[4],, entry
.L343:
# loader.c:255:     for (int i = 0; i < n_resident; i++) {
	cmpl	$5, %r15d	#, n_resident
	je	.L350	#,
# loader.c:258:         if (resident_type[i] == UEEC_SECTION_CODE && !entry) entry = local_base[i];
	cmpl	$1, 148(%rsp)	#, resident_type[5]
	jne	.L344	#,
# loader.c:258:         if (resident_type[i] == UEEC_SECTION_CODE && !entry) entry = local_base[i];
	testq	%rbx, %rbx	# entry
	cmove	232(%rsp), %rbx	# local_base[5],, entry
.L344:
# loader.c:255:     for (int i = 0; i < n_resident; i++) {
	cmpl	$6, %r15d	#, n_resident
	je	.L350	#,
# loader.c:258:         if (resident_type[i] == UEEC_SECTION_CODE && !entry) entry = local_base[i];
	cmpl	$1, 152(%rsp)	#, resident_type[6]
	jne	.L345	#,
# loader.c:258:         if (resident_type[i] == UEEC_SECTION_CODE && !entry) entry = local_base[i];
	testq	%rbx, %rbx	# entry
	cmove	240(%rsp), %rbx	# local_base[6],, entry
.L345:
# loader.c:255:     for (int i = 0; i < n_resident; i++) {
	cmpl	$7, %r15d	#, n_resident
	je	.L350	#,
# loader.c:258:         if (resident_type[i] == UEEC_SECTION_CODE && !entry) entry = local_base[i];
	cmpl	$1, 156(%rsp)	#, resident_type[7]
	jne	.L350	#,
# loader.c:258:         if (resident_type[i] == UEEC_SECTION_CODE && !entry) entry = local_base[i];
	testq	%rbx, %rbx	# entry
	cmove	248(%rsp), %rbx	# local_base[7],, entry
.L350:
# loader.c:260:     if (!entry) { fprintf(stderr, "no CODE section found\n"); return 1; }
	testq	%rbx, %rbx	# entry
	je	.L300	#,
# loader.c:262:     fflush(stdout);
	movq	stdout(%rip), %rdi	# stdout,
	call	fflush@PLT	#
# loader.c:271:     fn();
	call	*%rbx	# entry
# loader.c:273:     return 1;
	jmp	.L253	#
.L311:
	movq	%r11, 8(%rsp)	# buf, %sfp
# loader.c:116:         case 0: return process_blocks16(rp,len,endian,count,base,target,source,sizes[target],trace);
	movzwl	%r9w, %r9d	# _690, _666
# loader.c:116:         case 0: return process_blocks16(rp,len,endian,count,base,target,source,sizes[target],trace);
	subq	$8, %rsp	#,
	.cfi_def_cfa_offset 408
	movq	%r10, 8(%rsp)	# ivtmp.237, %sfp
	pushq	%r12	# trace_reloc
	.cfi_def_cfa_offset 416
	pushq	272(%rsp,%r9,8)	# *_664
	.cfi_def_cfa_offset 424
	movl	%edx, %r9d	# target,
	xorl	%edx, %edx	#
	pushq	%r8	# _687
	.cfi_def_cfa_offset 432
	leaq	224(%rsp), %r8	#,
	call	process_blocks16	#
	movq	32(%rsp), %r10	# %sfp, ivtmp.237
	movq	40(%rsp), %r11	# %sfp, buf
	addq	$32, %rsp	#,
	.cfi_def_cfa_offset 400
.L313:
# loader.c:241:         if (process_reloc_section(buf + sec_off[g], (size_t)sec_size[g], file_endian,
	testl	%eax, %eax	# _673
	jne	.L312	#,
.L308:
# loader.c:239:     for (int r = 0; r < n_reloc; ++r) {
	addq	$1, %r10	#, ivtmp.237
	cmpl	%r10d, 16(%rsp)	# ivtmp.237, %sfp
	jg	.L322	#,
	movq	88(%rsp), %rcx	# %sfp, mono_mem
	movq	40(%rsp), %r13	# %sfp, sec_size
	movq	80(%rsp), %rsi	# %sfp, total
	movl	48(%rsp), %r15d	# %sfp, n_resident
# loader.c:250:     if (mono_mem) {
	testq	%rcx, %rcx	# mono_mem
	jne	.L356	#,
.L355:
	leaq	128(%rsp), %rbp	#, ivtmp.226
	movslq	%r15d, %rax	# n_resident, _948
	leaq	96(%rsp), %r14	#, ivtmp.228
# loader.c:255:     for (int i = 0; i < n_resident; i++) {
	xorl	%ebx, %ebx	# entry
	leaq	192(%rsp), %r12	#, ivtmp.229
	leaq	0(%rbp,%rax,4), %r15	#, _946
	jmp	.L349	#
.L347:
# loader.c:256:         if (!mono_mem) mprotect(local_base[i], sec_size[resident_g[i]],
	movslq	(%r14), %rax	# MEM[(int *)_884], _765
# loader.c:256:         if (!mono_mem) mprotect(local_base[i], sec_size[resident_g[i]],
	movq	(%r12), %rdi	# MEM[(void * *)_444], MEM[(void * *)_444]
	movl	$1, %edx	#,
	movq	0(%r13,%rax,8), %rsi	# *_767, *_767
	call	mprotect@PLT	#
.L348:
# loader.c:255:     for (int i = 0; i < n_resident; i++) {
	addq	$4, %rbp	#, ivtmp.226
	addq	$4, %r14	#, ivtmp.228
	addq	$8, %r12	#, ivtmp.229
	cmpq	%rbp, %r15	# ivtmp.226, _946
	je	.L350	#,
.L349:
# loader.c:256:         if (!mono_mem) mprotect(local_base[i], sec_size[resident_g[i]],
	cmpl	$1, 0(%rbp)	#, MEM[(int *)_950]
	jne	.L347	#,
# loader.c:256:         if (!mono_mem) mprotect(local_base[i], sec_size[resident_g[i]],
	movslq	(%r14), %rax	# MEM[(int *)_945], _141
# loader.c:256:         if (!mono_mem) mprotect(local_base[i], sec_size[resident_g[i]],
	movq	(%r12), %rcx	# MEM[(void * *)_944], _146
	movl	$5, %edx	#,
	movq	0(%r13,%rax,8), %rsi	# *_143, *_143
	movq	%rcx, %rdi	# _146,
	movq	%rcx, (%rsp)	# _146, %sfp
	call	mprotect@PLT	#
# loader.c:258:         if (resident_type[i] == UEEC_SECTION_CODE && !entry) entry = local_base[i];
	testq	%rbx, %rbx	# entry
	cmove	(%rsp), %rbx	# entry,, %sfp, entry
	jmp	.L348	#
	.p2align 4,,10
	.p2align 3
.L537:
# loader.c:114:     if (design != 1 && design != 2) return -1;
	subl	$1, %ebp	#, _679
# loader.c:114:     if (design != 1 && design != 2) return -1;
	cmpl	$1, %ebp	#, _679
	ja	.L312	#,
# loader.c:102:     rp += 8; len -= 8;
	leaq	8(%rax), %rdi	#, rp
# loader.c:115:     switch (format) {
	cmpw	$1, %bx	#, _709
	je	.L309	#,
	cmpw	$2, %bx	#, _709
	je	.L310	#,
	testw	%bx, %bx	# _709
	je	.L311	#,
	.p2align 4
	.p2align 3
.L312:
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:111:   return __fprintf_chk (__stream, __USE_FORTIFY_LEVEL - 1, __fmt,
	movl	36(%rsp), %ecx	# %sfp,
	movq	stderr(%rip), %rdi	# stderr,
	leaq	.LC16(%rip), %rdx	#,
	xorl	%eax, %eax	#
	movl	$2, %esi	#,
	call	__fprintf_chk@PLT	#
# loader.c:244:             return 1;
	jmp	.L253	#
.L272:
# loader.c:179:     for (long s = 0; s < total_sections; s++) {
	movq	%r8, 8(%rsp)	# total_info, %sfp
	xorl	%r11d, %r11d	# s
	leaq	(%r12,%r15), %r8	#, ivtmp.302
	.p2align 6
	.p2align 4
	.p2align 3
.L275:
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	movzwl	(%r8), %edi	# MEM <unsigned short> [(char * {ref-all})_465], _864
	movq	%r11, %r15	# s, _464
# loader.c:179:     for (long s = 0; s < total_sections; s++) {
	addq	$6, %r8	#, ivtmp.302
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	movl	%edi, %eax	# _864, _318
	rolw	$8, %ax	#, _318
# loader.c:180:         sec_type[s] = rd16(buf + off, file_endian); off += 2;
	movzwl	%ax, %edi	# _318, _318
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	movzwl	-4(%r8), %eax	# MEM <unsigned short> [(char * {ref-all})_465 + 2B], _313
# loader.c:180:         sec_type[s] = rd16(buf + off, file_endian); off += 2;
	movl	%edi, (%r9,%r11,4)	# _318, MEM[(int *)sec_type_34 + _464 * 4]
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	rolw	$8, %ax	#, _314
# loader.c:181:         sec_size[s] = rd16(buf + off, file_endian); off += 2;
	movzwl	%ax, %eax	# _314, _314
	movq	%rax, 0(%r13,%r11,8)	# _314, MEM[(long int *)sec_size_45 + _464 * 8]
# loader.c:179:     for (long s = 0; s < total_sections; s++) {
	addq	$1, %r11	#, s
# loader.c:179:     for (long s = 0; s < total_sections; s++) {
	cmpq	%r15, %rcx	# _464, max_section
	jg	.L275	#,
	movq	8(%rsp), %r8	# %sfp, total_info
	jmp	.L274	#
.L310:
	movq	%r11, 8(%rsp)	# buf, %sfp
# loader.c:118:         case 2: return process_blocks64(rp,len,endian,count,base,target,source,sizes[target],trace);
	movzwl	%r9w, %r9d	# _690, _678
# loader.c:118:         case 2: return process_blocks64(rp,len,endian,count,base,target,source,sizes[target],trace);
	subq	$8, %rsp	#,
	.cfi_def_cfa_offset 408
	movq	%r10, 8(%rsp)	# ivtmp.237, %sfp
	pushq	%r12	# trace_reloc
	.cfi_def_cfa_offset 416
	pushq	272(%rsp,%r9,8)	# *_676
	.cfi_def_cfa_offset 424
	movl	%edx, %r9d	# target,
	xorl	%edx, %edx	#
	pushq	%r8	# _687
	.cfi_def_cfa_offset 432
	leaq	224(%rsp), %r8	#,
	call	process_blocks64	#
	addq	$32, %rsp	#,
	.cfi_def_cfa_offset 400
	movq	(%rsp), %r10	# %sfp, ivtmp.237
	movq	8(%rsp), %r11	# %sfp, buf
	jmp	.L313	#
.L539:
	movq	64(%rsp), %r10	# %sfp, ivtmp.237
	movq	72(%rsp), %r11	# %sfp, buf
	jmp	.L308	#
.L541:
	movq	64(%rsp), %r10	# %sfp, ivtmp.247
	movq	72(%rsp), %r11	# %sfp, buf
	jmp	.L327	#
.L309:
	movq	%r11, 8(%rsp)	# buf, %sfp
# loader.c:117:         case 1: return process_blocks32(rp,len,endian,count,base,target,source,sizes[target],trace);
	movzwl	%r9w, %r9d	# _690, _672
# loader.c:117:         case 1: return process_blocks32(rp,len,endian,count,base,target,source,sizes[target],trace);
	subq	$8, %rsp	#,
	.cfi_def_cfa_offset 408
	movq	%r10, 8(%rsp)	# ivtmp.237, %sfp
	pushq	%r12	# trace_reloc
	.cfi_def_cfa_offset 416
	pushq	272(%rsp,%r9,8)	# *_670
	.cfi_def_cfa_offset 424
	movl	%edx, %r9d	# target,
	xorl	%edx, %edx	#
	pushq	%r8	# _687
	.cfi_def_cfa_offset 432
	leaq	224(%rsp), %r8	#,
	call	process_blocks32	#
	addq	$32, %rsp	#,
	.cfi_def_cfa_offset 400
	movq	(%rsp), %r10	# %sfp, ivtmp.237
	movq	8(%rsp), %r11	# %sfp, buf
	jmp	.L313	#
.L335:
	movq	%r11, 8(%rsp)	# buf, %sfp
# loader.c:118:         case 2: return process_blocks64(rp,len,endian,count,base,target,source,sizes[target],trace);
	movzwl	%r9w, %r9d	# _359, _401
# loader.c:118:         case 2: return process_blocks64(rp,len,endian,count,base,target,source,sizes[target],trace);
	subq	$8, %rsp	#,
	.cfi_def_cfa_offset 408
	movl	$1, %edx	#,
	movq	%r10, 8(%rsp)	# ivtmp.247, %sfp
	pushq	%r12	# trace_reloc
	.cfi_def_cfa_offset 416
	pushq	272(%rsp,%r9,8)	# *_403
	.cfi_def_cfa_offset 424
	movl	%eax, %r9d	# target,
	pushq	%r8	# _362
	.cfi_def_cfa_offset 432
	leaq	224(%rsp), %r8	#,
	call	process_blocks64	#
	addq	$32, %rsp	#,
	.cfi_def_cfa_offset 400
	movq	8(%rsp), %r11	# %sfp, buf
	movq	(%rsp), %r10	# %sfp, ivtmp.247
	jmp	.L336	#
.L334:
	movq	%r11, 8(%rsp)	# buf, %sfp
# loader.c:117:         case 1: return process_blocks32(rp,len,endian,count,base,target,source,sizes[target],trace);
	movzwl	%r9w, %r9d	# _359, _396
# loader.c:117:         case 1: return process_blocks32(rp,len,endian,count,base,target,source,sizes[target],trace);
	subq	$8, %rsp	#,
	.cfi_def_cfa_offset 408
	movl	$1, %edx	#,
	movq	%r10, 8(%rsp)	# ivtmp.247, %sfp
	pushq	%r12	# trace_reloc
	.cfi_def_cfa_offset 416
	pushq	272(%rsp,%r9,8)	# *_398
	.cfi_def_cfa_offset 424
	movl	%eax, %r9d	# target,
	pushq	%r8	# _362
	.cfi_def_cfa_offset 432
	leaq	224(%rsp), %r8	#,
	call	process_blocks32	#
	addq	$32, %rsp	#,
	.cfi_def_cfa_offset 400
	movq	(%rsp), %r10	# %sfp, ivtmp.247
	movq	8(%rsp), %r11	# %sfp, buf
	jmp	.L336	#
.L287:
# loader.c:227:     } else if (!strcmp(load_mode, "scattered")) {
	leaq	.LC14(%rip), %rsi	#,
	movq	%rbp, %rdi	# load_mode,
	call	strcmp@PLT	#
# loader.c:227:     } else if (!strcmp(load_mode, "scattered")) {
	testl	%eax, %eax	# _108
	jne	.L293	#,
# loader.c:228:         for (int i = 0; i < n_resident; i++) {
	testl	%r15d, %r15d	# n_resident
	je	.L292	#,
	movq	40(%rsp), %rax	# %sfp, _723
	movl	%ebx, 24(%rsp)	# trace_reloc, %sfp
	leaq	192(%rsp), %rbp	#, ivtmp.263
	movq	%r12, (%rsp)	# buf, %sfp
	leaq	96(%rsp,%rax,4), %rax	#, _295
	movl	%r15d, 40(%rsp)	# n_resident, %sfp
	leaq	96(%rsp), %r15	#, ivtmp.262
	movq	%rax, 8(%rsp)	# _295, %sfp
	.p2align 4
	.p2align 3
.L294:
# loader.c:229:             local_base[i] = mmap(NULL, sec_size[resident_g[i]], PROT_READ | PROT_WRITE,
	movslq	(%r15), %r12	# MEM[(int *)_151], _110
# loader.c:229:             local_base[i] = mmap(NULL, sec_size[resident_g[i]], PROT_READ | PROT_WRITE,
	xorl	%r9d, %r9d	#
	movl	$-1, %r8d	#,
	xorl	%edi, %edi	#
	movl	$34, %ecx	#,
	movl	$3, %edx	#,
# loader.c:228:         for (int i = 0; i < n_resident; i++) {
	addq	$4, %r15	#, ivtmp.262
	addq	$8, %rbp	#, ivtmp.263
# loader.c:229:             local_base[i] = mmap(NULL, sec_size[resident_g[i]], PROT_READ | PROT_WRITE,
	movq	0(%r13,%r12,8), %rbx	# *_112, _114
	movq	%rbx, %rsi	# _114,
	call	mmap@PLT	#
# loader.c:231:             memcpy(local_base[i], buf + sec_off[resident_g[i]], sec_size[resident_g[i]]);
	movq	(%rsp), %rsi	# %sfp, _119
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movq	%rbx, %rdx	# _114,
# loader.c:231:             memcpy(local_base[i], buf + sec_off[resident_g[i]], sec_size[resident_g[i]]);
	addq	(%r14,%r12,8), %rsi	# *_116, _119
# loader.c:229:             local_base[i] = mmap(NULL, sec_size[resident_g[i]], PROT_READ | PROT_WRITE,
	movq	%rax, -8(%rbp)	# _115, MEM[(void * *)_171]
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movq	%rax, %rdi	# _115,
	call	memcpy@PLT	#
# loader.c:228:         for (int i = 0; i < n_resident; i++) {
	cmpq	%r15, 8(%rsp)	# ivtmp.262, %sfp
	jne	.L294	#,
# loader.c:211:     long total_mono_size = 0;
	movl	24(%rsp), %ebx	# %sfp, trace_reloc
	movl	40(%rsp), %r15d	# %sfp, n_resident
	xorl	%esi, %esi	# total
# loader.c:210:     void *mono_mem = NULL;
	xorl	%ecx, %ecx	# mono_mem
# loader.c:211:     long total_mono_size = 0;
	movq	(%rsp), %r12	# %sfp, buf
	jmp	.L291	#
.L271:
# loader.c:184:     sec_off[0] = 0;
	movq	$0, (%rax)	#, *sec_off_224
	jmp	.L276	#
.L260:
# loader.c:167:     info_t *info = malloc(sizeof(info_t) * total_info);
	xorl	%edi, %edi	#
	movq	%rdx, 8(%rsp)	# node, %sfp
# loader.c:151:     size_t off = 8;
	movl	$8, %r15d	#, off
# loader.c:167:     info_t *info = malloc(sizeof(info_t) * total_info);
	call	malloc@PLT	#
	movq	8(%rsp), %rdx	# %sfp, node
	xorl	%esi, %esi	# nodes
# loader.c:155:     long total_info = 0;
	xorl	%r8d, %r8d	# total_info
# loader.c:167:     info_t *info = malloc(sizeof(info_t) * total_info);
	movq	%rax, (%rsp)	# info, %sfp
.L266:
# loader.c:176:     int *sec_type = malloc(sizeof(int) * total_sections);
	movl	$4, %edi	#,
	movl	%esi, 40(%rsp)	# nodes, %sfp
	movq	%rdx, 24(%rsp)	# node, %sfp
	movq	%r8, 16(%rsp)	# total_info, %sfp
	call	malloc@PLT	#
# loader.c:177:     long *sec_size = malloc(sizeof(long) * total_sections);
	movl	$8, %edi	#,
# loader.c:176:     int *sec_type = malloc(sizeof(int) * total_sections);
	movq	%rax, 8(%rsp)	# sec_type, %sfp
# loader.c:177:     long *sec_size = malloc(sizeof(long) * total_sections);
	call	malloc@PLT	#
# loader.c:178:     long *sec_off = malloc(sizeof(long) * total_sections);
	movl	$8, %edi	#,
# loader.c:177:     long *sec_size = malloc(sizeof(long) * total_sections);
	movq	%rax, %r13	# sec_size, sec_size
# loader.c:178:     long *sec_off = malloc(sizeof(long) * total_sections);
	call	malloc@PLT	#
	movq	8(%rsp), %r9	# %sfp, sec_type
	movl	40(%rsp), %esi	# %sfp, nodes
	xorl	%ecx, %ecx	# max_section
	movq	16(%rsp), %r8	# %sfp, total_info
	movq	24(%rsp), %rdx	# %sfp, node
	movq	%rax, %r14	# sec_off, sec_off
	movl	$1, %r10d	#, prephitmp_274
	jmp	.L358	#
.L535:
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:118:   return __printf_chk (__USE_FORTIFY_LEVEL - 1, __fmt, __va_arg_pack ());
	xorl	%ecx, %ecx	#
	xorl	%edx, %edx	#
	leaq	.LC13(%rip), %rsi	#,
	movl	$2, %edi	#,
	xorl	%eax, %eax	#
	call	__printf_chk@PLT	#
# loader.c:214:     if (!strcmp(load_mode, "monolithic")) {
	leaq	.LC3(%rip), %rsi	#,
	movq	%rbp, %rdi	# load_mode,
	call	strcmp@PLT	#
	movl	%eax, 16(%rsp)	# n_reloc, %sfp
# loader.c:214:     if (!strcmp(load_mode, "monolithic")) {
	testl	%eax, %eax	# n_reloc
	jne	.L527	#,
.L288:
# loader.c:221:         mono_mem = mmap(NULL, total, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
	movl	$34, %ecx	#,
	xorl	%esi, %esi	#
	xorl	%r9d, %r9d	#
	movl	$-1, %r8d	#,
	movl	$3, %edx	#,
	xorl	%edi, %edi	#
# loader.c:239:     for (int r = 0; r < n_reloc; ++r) {
	xorl	%r15d, %r15d	# n_resident
# loader.c:221:         mono_mem = mmap(NULL, total, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
	call	mmap@PLT	#
# loader.c:239:     for (int r = 0; r < n_reloc; ++r) {
	xorl	%esi, %esi	# total
# loader.c:221:         mono_mem = mmap(NULL, total, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
	movq	%rax, %rcx	# mono_mem, mono_mem
# loader.c:239:     for (int r = 0; r < n_reloc; ++r) {
	movl	16(%rsp), %eax	# %sfp,
	testl	%eax, %eax	#
	jne	.L295	#,
# loader.c:250:     if (mono_mem) {
	testq	%rcx, %rcx	# mono_mem
	je	.L300	#,
# loader.c:252:         mprotect(mono_mem, total_mono_size, PROT_READ | PROT_EXEC | PROT_WRITE);
	movl	$7, %edx	#,
	xorl	%esi, %esi	#
	movq	%rcx, %rdi	# mono_mem,
	call	mprotect@PLT	#
.L300:
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:111:   return __fprintf_chk (__stream, __USE_FORTIFY_LEVEL - 1, __fmt,
	movq	stderr(%rip), %rcx	# stderr,
	movl	$22, %edx	#,
	movl	$1, %esi	#,
	leaq	.LC17(%rip), %rdi	#,
	call	fwrite@PLT	#
# loader.c:260:     if (!entry) { fprintf(stderr, "no CODE section found\n"); return 1; }
	jmp	.L253	#
.L527:
# loader.c:227:     } else if (!strcmp(load_mode, "scattered")) {
	leaq	.LC14(%rip), %rsi	#,
	movq	%rbp, %rdi	# load_mode,
	call	strcmp@PLT	#
# loader.c:227:     } else if (!strcmp(load_mode, "scattered")) {
	testl	%eax, %eax	# n_reloc
	je	.L300	#,
.L293:
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:111:   return __fprintf_chk (__stream, __USE_FORTIFY_LEVEL - 1, __fmt,
	movq	stderr(%rip), %rdi	# stderr,
	movq	%rbp, %rcx	# load_mode,
	movl	$2, %esi	#,
	xorl	%eax, %eax	#
	leaq	.LC15(%rip), %rdx	#,
	call	__fprintf_chk@PLT	#
# loader.c:234:         fprintf(stderr, "unknown --L mode: %s\n", load_mode); return 1;
	jmp	.L253	#
.L337:
# loader.c:258:         if (resident_type[i] == UEEC_SECTION_CODE && !entry) entry = local_base[i];
	movq	192(%rsp), %rbx	# local_base[0], entry
# loader.c:255:     for (int i = 0; i < n_resident; i++) {
	cmpl	$1, %r15d	#, n_resident
	jne	.L338	#,
	jmp	.L350	#
.L292:
# loader.c:211:     long total_mono_size = 0;
	xorl	%esi, %esi	# total
# loader.c:210:     void *mono_mem = NULL;
	xorl	%ecx, %ecx	# mono_mem
# loader.c:239:     for (int r = 0; r < n_reloc; ++r) {
	cmpl	$0, 16(%rsp)	#, %sfp
	jne	.L295	#,
	jmp	.L300	#
.L532:
# loader.c:274: }
	call	__stack_chk_fail@PLT	#
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.type	loader_main.cold, @function
loader_main.cold:
.LFSB62:
.L517:
	.cfi_def_cfa_offset 400
	.cfi_offset 3, -56
	.cfi_offset 6, -48
	.cfi_offset 12, -40
	.cfi_offset 13, -32
	.cfi_offset 14, -24
	.cfi_offset 15, -16
# loader.c:135:     if (!f) { perror("fopen"); return 1; }
	leaq	.LC8(%rip), %rdi	#,
	call	perror@PLT	#
	jmp	.L253	#
	.cfi_endproc
.LFE62:
	.text
	.size	loader_main, .-loader_main
	.section	.text.unlikely
	.size	loader_main.cold, .-loader_main.cold
.LCOLDE18:
	.text
.LHOTE18:
	.section	.rodata.str1.8
	.align 8
.LC19:
	.string	"count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc"
	.align 8
.LC20:
	.string	"%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n"
	.section	.rodata.str1.1
.LC21:
	.string	"bench.c"
	.section	.rodata.str1.8
	.align 8
.LC22:
	.string	"rc==0&&!memcmp(m,expected,len)"
	.section	.text.unlikely
.LCOLDB23:
	.section	.text.startup,"ax",@progbits
.LHOTB23:
	.p2align 4
	.globl	main
	.type	main, @function
main:
.LFB67:
	.cfi_startproc
	endbr64	
	pushq	%r15	#
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14	#
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	$4, %r14d	#, ivtmp_618
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	pushq	%r13	#
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12	#
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp	#
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx	#
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$328, %rsp	#,
	.cfi_def_cfa_offset 384
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%fs:40, %rdi	# MEM[(<address-space-1> long unsigned int *)40B],
	movq	%rdi, 312(%rsp)	#, D.6340
	leaq	.LC19(%rip), %rdi	#,
	call	puts@PLT	#
	leaq	256(%rsp), %rax	#, tmp773
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	$16, 48(%rsp)	#, %sfp
	movq	%rax, (%rsp)	# tmp773, %sfp
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	leaq	248(%rsp), %rax	#, tmp796
	movq	%rax, 136(%rsp)	# tmp796, %sfp
.L544:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movslq	48(%rsp), %r15	# %sfp,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	$8, 52(%rsp)	#, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	$3, %r13d	#, ivtmp_60
	movq	%r15, 184(%rsp)	# _560, %sfp
	leal	-1(%r15), %r12d	#, _561
.L626:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movslq	52(%rsp), %rax	# %sfp,
	movq	184(%rsp), %rdi	# %sfp, _3
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	$512, 28(%rsp)	#, %sfp
	movl	%r13d, 232(%rsp)	# ivtmp_60, %sfp
	movl	%r12d, %r13d	# _561, _561
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	imulq	%rax, %rdi	# _2, _3
	movq	%rax, 224(%rsp)	# _2, %sfp
	movq	%rax, %rbx	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	imull	%r12d, %ebx	# _561, _5
	movl	%r14d, %r12d	# ivtmp_618, ivtmp_618
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	leaq	8(%rdi), %rbp	#, len
	movq	%rbp, %xmm2	# len, _478
	punpcklqdq	%xmm2, %xmm2	# _478
	movaps	%xmm2, 208(%rsp)	# _478, %sfp
.L624:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	28(%rsp), %edi	# %sfp, page
	movl	%ebx, %eax	# _5, tmp740
	movl	%ebx, 236(%rsp)	# _5, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	$0, 168(%rsp)	#, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cltd
	idivl	%edi	# page
	movl	%ebx, %eax	# _5, _7
	subl	%edx, %eax	# tmp739, _7
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cltq
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cmpq	$65535, %rax	#, maxbase_94
	seta	199(%rsp)	#, %sfp
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	cmpl	$4096, %edi	#, page
	setne	198(%rsp)	#, %sfp
	movzbl	198(%rsp), %eax	# %sfp, tmp745
	addl	$1, %eax	#, tmp745
	movb	%al, 198(%rsp)	# tmp745, %sfp
.L622:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	48(%rsp), %r9d	# %sfp, n
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	$0, 56(%rsp)	#, %sfp
	movl	%r13d, 200(%rsp)	# _561, %sfp
	movl	%r12d, 204(%rsp)	# ivtmp_618, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	testl	%r9d, %r9d	# n
	jle	.L545	#,
.L691:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	52(%rsp), %r10d	# %sfp, stride
	movl	28(%rsp), %r8d	# %sfp, page
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	xorl	%ecx, %ecx	# ivtmp.472
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	xorl	%edi, %edi	# i
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	xorl	%esi, %esi	# maxdelta
	.p2align 5
	.p2align 4
	.p2align 3
.L546:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	%ecx, %eax	# ivtmp.472, tmp534
	cltd
	idivl	%r8d	# page
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cmpl	%edx, %esi	# _9, maxdelta
	cmovb	%edx, %esi	# maxdelta,, _9, maxdelta
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	addl	$1, %edi	#, i
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	addl	%r10d, %ecx	# stride, ivtmp.472
	cmpl	%r9d, %edi	# n, i
	jne	.L546	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cmpl	$4095, %esi	#, maxdelta
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	$2, %eax	#, tmp538
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	$24, %esi	#,
	movq	184(%rsp), %rdi	# %sfp,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	seta	%cl	#, _11
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	orb	199(%rsp), %cl	# %sfp, _12
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	$1, %ebx	#, blocks
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	sall	%cl, %eax	# _12, tmp538
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	%ecx, %r14d	# _12, _158
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	%eax, 64(%rsp)	# tmp538, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	call	calloc@PLT	#
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%rbp, %rsi	# len,
	movl	$1, %edi	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%rax, 176(%rsp)	# table, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	call	calloc@PLT	#
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%rbp, %rsi	# len,
	movl	$1, %edi	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%rax, 8(%rsp)	# m, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	call	calloc@PLT	#
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	$1, %edi	#,
	movq	%rbp, %rsi	# len,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%rax, 40(%rsp)	# init, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	call	calloc@PLT	#
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	48(%rsp), %r9d	# %sfp, n
	movl	52(%rsp), %r10d	# %sfp, stride
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	xorl	%ecx, %ecx	# ivtmp.468
	movq	%rax, 32(%rsp)	# expected, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	28(%rsp), %r8d	# %sfp, page
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	$1, %edi	#, i
.L548:
	movl	%ecx, %eax	# ivtmp.468, ivtmp.468
	addl	%r10d, %ecx	# stride, ivtmp.468
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cltd
	idivl	%r8d	# page
	movl	%eax, %esi	# ivtmp.468, _590
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	%ecx, %eax	# ivtmp.468, _596
	cltd
	idivl	%r8d	# page
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cmpl	%eax, %esi	# _596, _590
	setne	%al	#, tmp777
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	addl	$1, %edi	#, i
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movzbl	%al, %eax	# tmp777, tmp777
	addl	%eax, %ebx	# tmp777, blocks
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cmpl	%r9d, %edi	# n, i
	jne	.L548	#,
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movl	%ebx, %r10d	# blocks, _584
	movzbl	%bh, %ebx	# blocks, _588
.L627:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	8(%rsp), %xmm0	# %sfp, _635
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movl	168(%rsp), %edi	# %sfp,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movdqa	208(%rsp), %xmm3	# %sfp, _478
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movq	176(%rsp), %rax	# %sfp, table
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	punpcklqdq	%xmm0, %xmm0	# _635
	movaps	%xmm0, 272(%rsp)	# _635, MEM <vector(2) long unsigned int> [(void * *)&base]
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movaps	%xmm3, 288(%rsp)	# _478, MEM <vector(2) long unsigned int> [(long unsigned int *)&sizes]
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	testl	%edi, %edi	#
	jne	.L549	#,
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movb	%r14b, (%rax)	# _158, *table_359
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	leaq	1(%rax), %r9	#, _603
	movl	$3, %edi	#, prephitmp_601
	movl	$2, %r8d	#, prephitmp_599
	movl	$5, %ecx	#, prephitmp_597
	movl	$4, %esi	#, prephitmp_595
	movl	$7, %eax	#, prephitmp_593
	movl	$6, %edx	#, prephitmp_591
.L550:
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movb	$0, (%r9)	#, *prephitmp_604
	movq	176(%rsp), %r15	# %sfp, table
	movzbl	198(%rsp), %r9d	# %sfp, tmp745
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	addq	$8, %r15	#, ivtmp.402
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movb	%r9b, -8(%r15,%r8)	# tmp745, *_428
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	48(%rsp), %r8d	# %sfp, n
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movb	$0, -8(%r15,%rdi)	#, *_440
	movb	$32, -8(%r15,%rsi)	#, *_404
	movb	$0, -8(%r15,%rcx)	#, *_416
	movb	%r10b, -8(%r15,%rdx)	# _584, *_380
	movb	%bl, -8(%r15,%rax)	# _588, *_392
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	64(%rsp), %ebx	# %sfp, w
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movq	%r15, 72(%rsp)	# ivtmp.402, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	leal	0(,%rbx,8), %eax	#, _709
	movl	%eax, 60(%rsp)	# _709, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	testl	%r8d, %r8d	# n
	jle	.L632	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	subl	$4, %eax	#, _34
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movslq	28(%rsp), %r10	# %sfp, _615
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	$0, 120(%rsp)	#, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	%eax, 88(%rsp)	# _34, %sfp
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movslq	%ebx, %rax	# w, _608
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	52(%rsp), %r9d	# %sfp, stride
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movq	%rax, 16(%rsp)	# _608, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	56(%rsp), %eax	# %sfp, _403
	movq	%r15, 104(%rsp)	# p, %sfp
	movq	224(%rsp), %r13	# %sfp, _2
	xorl	$1, %eax	#, _403
	movq	%r10, 160(%rsp)	# _615, %sfp
	movl	%eax, 96(%rsp)	# _403, %sfp
	.p2align 4
	.p2align 3
.L574:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	120(%rsp), %eax	# %sfp, i
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	28(%rsp), %edi	# %sfp, page
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	leal	1(%rax), %r12d	#, j
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	imull	%r9d, %eax	# stride, _20
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cltd
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movslq	%eax, %rbx	# _20,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	idivl	%edi	# page
	movl	%ebx, %ecx	# _20, _22
	subl	%edx, %ecx	# tmp557, _22
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movslq	%ecx, %rcx	# _22, idx
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cmpl	%r8d, %r12d	# n, j
	jge	.L633	#,
	movq	160(%rsp), %r10	# %sfp, _615
	leal	(%rbx,%r9), %esi	#, ivtmp.462
	jmp	.L553	#
	.p2align 5
	.p2align 4,,10
	.p2align 3
.L554:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	addl	$1, %r12d	#, j
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	addl	%r9d, %esi	# stride, ivtmp.462
	cmpl	%r8d, %r12d	# n, j
	je	.L674	#,
.L553:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	%esi, %eax	# ivtmp.462, _24
	cltd
	idivl	%edi	# page
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cltq
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	imulq	%r10, %rax	# _615, _27
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cmpq	%rcx, %rax	# idx, _27
	je	.L554	#,
.L674:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	%r12d, %eax	# j, _616
	subl	120(%rsp), %eax	# %sfp, _616
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cltq
.L552:
	movl	168(%rsp), %esi	# %sfp,
	testl	%esi, %esi	#
	je	.L557	#,
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movl	64(%rsp), %r15d	# %sfp, w
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movq	104(%rsp), %rdi	# %sfp, p
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	leal	-1(%r15), %esi	#, _751
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movslq	%esi, %rdx	# _751, iftmp.52_47
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movb	$0, (%rdi,%rdx)	#, *_202
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	leal	-2(%r15), %edx	#, _653
	movl	%edx, 112(%rsp)	# _653, %sfp
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movslq	%edx, %rdx	# _653, iftmp.52_804
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movb	%ch, (%rdi,%rdx)	# idx, *_805
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	cmpl	$2, %r15d	#, w
	je	.L558	#,
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movq	%rcx, %rdx	# idx, _76
	shrq	$16, %rdx	#, _76
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movb	%dl, 1(%rdi)	# _76, MEM[(uint8_t *)p_437 + 1B]
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movq	%rcx, %rdx	# idx, _201
	shrq	$24, %rdx	#, _201
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movb	%dl, (%rdi)	# _201, *p_437
.L558:
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movslq	%esi, %rsi	# _751, iftmp.52_740
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movq	104(%rsp), %rdx	# %sfp, p
	addq	16(%rsp), %rdx	# %sfp, p
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movb	%al, (%rdx,%rsi)	# _619, *_737
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movslq	112(%rsp), %rsi	# %sfp, iftmp.52_744
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movb	%ah, (%rdx,%rsi)	# _619, *_745
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	cmpl	$2, 64(%rsp)	#, %sfp
	je	.L556	#,
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movq	%rax, %rsi	# _619, _694
	shrq	$24, %rax	#, _190
	shrq	$16, %rsi	#, _694
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movb	%al, (%rdx)	# _190, *_456
	movb	%sil, 1(%rdx)	# _694, MEM[(uint8_t *)_456 + 1B]
.L556:
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movq	16(%rsp), %rax	# %sfp, _608
	addq	%rdx, %rax	# _456, p
	movq	%rax, 104(%rsp)	# p, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cmpl	120(%rsp), %r12d	# %sfp, j
	jle	.L562	#,
	movq	%rax, %r14	# p, _222
	movq	40(%rsp), %rax	# %sfp, init
	movq	32(%rsp), %rdi	# %sfp, expected
	movl	%r12d, 124(%rsp)	# j, %sfp
	movq	8(%rsp), %rsi	# %sfp, m
	movl	%r8d, 172(%rsp)	# n, %sfp
	leaq	(%rbx,%rax), %r10	#, ivtmp.445
	addq	%rcx, %rax	# idx, _332
	leaq	(%rdi,%rbx), %r15	#, ivtmp.446
	movslq	120(%rsp), %rdi	# %sfp, ivtmp.449
	movq	%rax, 80(%rsp)	# _332, %sfp
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movslq	112(%rsp), %rax	# %sfp, iftmp.52_651
	movq	%r10, %r12	# ivtmp.445, ivtmp.445
	movq	%rbp, 112(%rsp)	# len, %sfp
	leaq	1(%rsi,%rdi), %rbp	#, ivtmp.450
	movq	%rax, 128(%rsp)	# iftmp.52_651, %sfp
	movl	%r9d, 192(%rsp)	# stride, %sfp
	jmp	.L573	#
	.p2align 4,,10
	.p2align 3
.L682:
	movq	112(%rsp), %rax	# %sfp, len
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movq	136(%rsp), %rsi	# %sfp,
	movl	$8, %edx	#,
	movq	%r12, %rdi	# ivtmp.445,
	cmpq	%rbx, %rax	# ivtmp.444, len
	movq	%rax, %rcx	# len, _121
	cmovb	%rbx, %rcx	# _121,, ivtmp.444, _121
	subq	%rbx, %rcx	# ivtmp.444, _262
	movq	%rcx, 144(%rsp)	# _262, %sfp
	call	__memcpy_chk@PLT	#
	movq	(%rsp), %rsi	# %sfp,
	movl	$8, %edx	#,
	movq	144(%rsp), %rcx	# %sfp, _262
.L681:
	movq	%r15, %rdi	# ivtmp.446,
	call	__memcpy_chk@PLT	#
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	152(%rsp), %r8	# %sfp, _284
	cmpl	%r8d, 124(%rsp)	# _284, %sfp
	jle	.L571	#,
	addq	%r13, %rbx	# _2, ivtmp.444
	addq	%r13, %r12	# _2, ivtmp.445
	addq	%r13, %r15	# _2, ivtmp.446
	addq	$1, %rbp	#, ivtmp.450
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	addq	16(%rsp), %r14	# %sfp, _222
	movq	%r8, %rdi	# _284, ivtmp.449
.L573:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	%edi, %edx	# ivtmp.449, _181
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movzbl	88(%rsp), %ecx	# %sfp, tmp1024
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%r12, %rax	# ivtmp.445, _31
	subq	80(%rsp), %rax	# %sfp, _31
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	andl	$1, %edx	#, _181
	orl	96(%rsp), %edx	# %sfp, _80
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movslq	%edx, %rsi	# _80, _32
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	salq	%cl, %rsi	# tmp1024, _35
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movq	128(%rsp), %rcx	# %sfp, iftmp.52_651
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	orq	%rsi, %rax	# _35, _36
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movq	16(%rsp), %rsi	# %sfp, _608
	movb	%al, -1(%r14,%rsi)	# _36, MEM[(uint8_t *)p_434 + -1B + _608 * 1]
	movq	%r14, %rsi	# _222, _222
	movb	%ah, (%rsi,%rcx)	# _36, MEM[(uint8_t *)p_434 + iftmp.52_651 * 1]
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	cmpl	$2, 64(%rsp)	#, %sfp
	je	.L569	#,
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movq	%rax, %rcx	# _36, _802
	shrq	$24, %rax	#, _214
	shrq	$16, %rcx	#, _802
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movb	%al, (%r14)	# _214, MEM[(uint8_t *)p_434]
	movb	%cl, 1(%r14)	# _802, MEM[(uint8_t *)p_434 + 1B]
.L569:
	leaq	1(%rdi), %r8	#, _284
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%rbp, 256(%rsp)	# ivtmp.450, MEM[(long unsigned int *)_211]
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%r8, 248(%rsp)	# _284, a
	movq	%r8, 152(%rsp)	# _284, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	testl	%edx, %edx	# _80
	jne	.L682	#,
	movq	112(%rsp), %rax	# %sfp, len
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	addl	$1, %edi	#, tmp612
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	leaq	240(%rsp), %rsi	#, tmp614
	movl	$4, %edx	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	%edi, 240(%rsp)	# tmp612, aa
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movq	%r12, %rdi	# ivtmp.445,
	cmpq	%rbx, %rax	# ivtmp.444, len
	movq	%rax, %rcx	# len, _707
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	%ebp, 244(%rsp)	# ivtmp.450, vv
	cmovb	%rbx, %rcx	# _707,, ivtmp.444, _707
	subq	%rbx, %rcx	# ivtmp.444, _367
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movq	%rcx, 144(%rsp)	# _367, %sfp
	call	__memcpy_chk@PLT	#
	movq	144(%rsp), %rcx	# %sfp, _367
	movl	$4, %edx	#,
	leaq	244(%rsp), %rsi	#, tmp615
	jmp	.L681	#
.L566:
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movl	152(%rsp), %r8d	# %sfp, n
	movl	172(%rsp), %r9d	# %sfp, stride
	movq	%r12, %r13	# _2, _2
.L677:
	movl	124(%rsp), %r12d	# %sfp, j
	movq	16(%rsp), %rbx	# %sfp, _608
	movq	104(%rsp), %rdx	# %sfp, p
	movq	112(%rsp), %rbp	# %sfp, len
	movl	%r12d, %eax	# j, _204
	subl	120(%rsp), %eax	# %sfp, _204
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	%r12d, 120(%rsp)	# j, %sfp
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	subl	$1, %eax	#, _352
	addq	%rbx, %rdx	# _608, p
	imulq	%rbx, %rax	# _608, _351
	addq	%rdx, %rax	# _366, p
	movq	%rax, 104(%rsp)	# p, %sfp
.L562:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cmpl	120(%rsp), %r8d	# %sfp, n
	jg	.L574	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	104(%rsp), %r15	# %sfp, p
	subq	176(%rsp), %r15	# %sfp, p
	movq	%r15, 16(%rsp)	# p, %sfp
.L551:
	movl	168(%rsp), %ecx	# %sfp,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	xorl	%r14d, %r14d	# rep
	testl	%ecx, %ecx	#
	jne	.L634	#,
# loader.c:102:     rp += 8; len -= 8;
	movq	16(%rsp), %rax	# %sfp, _659
# loader.c:109:             if (type > 1 || offset > sizes[target] || bytes > sizes[target]-offset) return -1;
	movq	176(%rsp), %r15	# %sfp, table
# loader.c:102:     rp += 8; len -= 8;
	subq	$8, %rax	#, len
	movq	%rax, 96(%rsp)	# len, %sfp
# loader.c:104:         if (format != 0 || count > len/2) return -1;
	shrq	%rax	# _501
	movq	%rax, 88(%rsp)	# _501, %sfp
# loader.c:109:             if (type > 1 || offset > sizes[target] || bytes > sizes[target]-offset) return -1;
	leaq	288(%rsp), %rax	#, tmp784
	movq	%rax, 80(%rsp)	# tmp784, %sfp
	jmp	.L598	#
	.p2align 4,,10
	.p2align 3
.L576:
# loader.c:97:     if (len < 8) return -1;
	cmpq	$7, 16(%rsp)	#, %sfp
	jbe	.L581	#,
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movzwl	4(%r15), %eax	# MEM <unsigned short> [(char * {ref-all})table_359 + 4B], pretmp_537
	movl	%eax, %edx	# pretmp_537, _529
# loader.c:100:     int target = couple & 31, source = (couple >> 5) & 31;
	movl	%eax, %r9d	# pretmp_537, target
# loader.c:100:     int target = couple & 31, source = (couple >> 5) & 31;
	shrl	$5, %eax	#, _527
# loader.c:100:     int target = couple & 31, source = (couple >> 5) & 31;
	andl	$31, %r9d	#, target
	andl	$31, %eax	#,
	andl	$31, %edx	#, _529
# loader.c:101:     if (target >= n || source >= n) return -1;
	movl	%r9d, %ecx	# target, _524
	cmpl	%r9d, %eax	# target, _526
	cmovge	%eax, %ecx	# _526,, _524
	cmpl	$1, %ecx	#, _524
	jg	.L581	#,
# loader.c:98:     unsigned format = rd16(rp, endian), design = rd16(rp+2, endian);
	movzwl	2(%r15), %edi	# MEM <unsigned short> [(char * {ref-all})table_359 + 2B], design
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movzwl	(%r15), %r8d	# MEM <unsigned short> [(char * {ref-all})table_359], _538
	movzwl	6(%r15), %ecx	# MEM <unsigned short> [(char * {ref-all})table_359 + 6B],
# loader.c:103:     if (design == 0) {
	testl	%edi, %edi	# design
	je	.L582	#,
# loader.c:114:     if (design != 1 && design != 2) return -1;
	subl	$1, %edi	#, _521
# loader.c:114:     if (design != 1 && design != 2) return -1;
	cmpl	$1, %edi	#, _521
	ja	.L581	#,
# loader.c:115:     switch (format) {
	cmpw	$1, %r8w	#, _538
	je	.L583	#,
	cmpw	$2, %r8w	#, _538
	je	.L584	#,
	testw	%r8w, %r8w	# _538
	jne	.L661	#,
# loader.c:116:         case 0: return process_blocks16(rp,len,endian,count,base,target,source,sizes[target],trace);
	subq	$8, %rsp	#,
	.cfi_def_cfa_offset 392
# loader.c:116:         case 0: return process_blocks16(rp,len,endian,count,base,target,source,sizes[target],trace);
	movzwl	%dx, %edx	# _529, _508
# loader.c:116:         case 0: return process_blocks16(rp,len,endian,count,base,target,source,sizes[target],trace);
	pushq	$0	#
	.cfi_def_cfa_offset 400
	pushq	304(%rsp,%rdx,8)	# *_506
	.cfi_def_cfa_offset 408
	xorl	%edx, %edx	#
	pushq	%rax	# _526
	.cfi_def_cfa_offset 416
	movq	128(%rsp), %rsi	# %sfp,
	movq	104(%rsp), %rdi	# %sfp,
	leaq	304(%rsp), %r8	#,
	call	process_blocks16	#
	movl	%eax, 96(%rsp)	# rc, %sfp
	addq	$32, %rsp	#,
	.cfi_def_cfa_offset 384
	.p2align 4
	.p2align 3
.L580:
# bench.c:6: static uint64_t now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000+t.tv_nsec;}
	movq	(%rsp), %rsi	# %sfp,
	movl	$1, %edi	#,
	call	clock_gettime@PLT	#
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	64(%rsp), %edx	# %sfp,
# bench.c:6: static uint64_t now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000+t.tv_nsec;}
	imulq	$1000000000, 256(%rsp), %rcx	#, MEM[(struct timespec *)_211].tv_sec, _546
# bench.c:6: static uint64_t now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000+t.tv_nsec;}
	addq	264(%rsp), %rcx	# MEM[(struct timespec *)_211].tv_nsec, _543
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	subq	%r13, %rcx	# _553, elapsed
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	testl	%edx, %edx	#
	jne	.L683	#,
.L578:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	32(%rsp), %rsi	# %sfp,
	movq	8(%rsp), %rdi	# %sfp,
	movq	%rbp, %rdx	# len,
	movq	%rcx, 64(%rsp)	# elapsed, %sfp
	call	memcmp@PLT	#
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	testl	%eax, %eax	# tmp811
	jne	.L613	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	64(%rsp), %rcx	# %sfp, elapsed
	testq	%rcx, %rcx	# elapsed
	js	.L595	#,
	pxor	%xmm0, %xmm0	# _383
	cvtsi2sdq	%rcx, %xmm0	# elapsed, _383
.L596:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	48(%rsp), %edx	# %sfp, n
	pxor	%xmm1, %xmm1	# _377
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:118:   return __printf_chk (__USE_FORTIFY_LEVEL - 1, __fmt, __va_arg_pack ());
	subq	$8, %rsp	#,
	.cfi_def_cfa_offset 392
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	addl	$1, %ebx	#, ivtmp.391
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:118:   return __printf_chk (__USE_FORTIFY_LEVEL - 1, __fmt, __va_arg_pack ());
	pushq	24(%rsp)	# %sfp
	.cfi_def_cfa_offset 400
	leaq	.LC20(%rip), %rsi	#,
	movl	$2, %edi	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cvtsi2sdl	%edx, %xmm1	# n, _377
	divsd	%xmm1, %xmm0	# _377, _376
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:118:   return __printf_chk (__USE_FORTIFY_LEVEL - 1, __fmt, __va_arg_pack ());
	pushq	%r12	# _808
	.cfi_def_cfa_offset 408
	pushq	%r14	# rep
	.cfi_def_cfa_offset 416
	movl	88(%rsp), %eax	# %sfp, mix
	pushq	%rax	# mix
	.cfi_def_cfa_offset 424
	movl	$1, %eax	#,
	pushq	$0	#
	.cfi_def_cfa_offset 432
	movl	108(%rsp), %r9d	# %sfp,
	movl	76(%rsp), %r8d	# %sfp,
	movl	100(%rsp), %ecx	# %sfp,
	call	__printf_chk@PLT	#
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	leal	2(%r14), %eax	#, _655
	addq	$48, %rsp	#,
	.cfi_def_cfa_offset 384
	cmpl	%eax, %ebx	# _655, ivtmp.391
	jne	.L597	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	addl	$1, %r14d	#, rep
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cmpl	$101, %r14d	#, rep
	je	.L684	#,
.L598:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	%r14d, %ebx	# rep, ivtmp.391
.L597:
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movq	40(%rsp), %rsi	# %sfp,
	movq	8(%rsp), %rdi	# %sfp,
	movq	%rbp, %rcx	# len,
	movq	%rbp, %rdx	# len,
	movl	%ebx, %r12d	# ivtmp.391, _808
	call	__memcpy_chk@PLT	#
# bench.c:6: static uint64_t now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000+t.tv_nsec;}
	movq	(%rsp), %rsi	# %sfp,
	movl	$1, %edi	#,
	andl	$1, %r12d	#, _808
	call	clock_gettime@PLT	#
# bench.c:6: static uint64_t now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000+t.tv_nsec;}
	imulq	$1000000000, 256(%rsp), %rax	#, MEM[(struct timespec *)_211].tv_sec, _556
# bench.c:6: static uint64_t now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000+t.tv_nsec;}
	addq	264(%rsp), %rax	# MEM[(struct timespec *)_211].tv_nsec, _556
	movq	%rax, %r13	# _556, _553
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	testl	%r12d, %r12d	# _808
	jne	.L576	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	80(%rsp), %r8	# %sfp,
	movq	16(%rsp), %rsi	# %sfp,
	xorl	%edx, %edx	#
	movq	%r15, %rdi	# table,
	leaq	272(%rsp), %rcx	#, tmp635
	call	generic.constprop.0	#
	movl	%eax, 64(%rsp)	# rc, %sfp
	jmp	.L580	#
	.p2align 4,,10
	.p2align 3
.L595:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%rcx, %rax	# elapsed, tmp669
	andl	$1, %ecx	#, tmp670
	pxor	%xmm0, %xmm0	# tmp668
	shrq	%rax	# tmp669
	orq	%rcx, %rax	# tmp670, tmp669
	cvtsi2sdq	%rax, %xmm0	# tmp669, tmp668
	addsd	%xmm0, %xmm0	# tmp668, _383
	jmp	.L596	#
	.p2align 4,,10
	.p2align 3
.L582:
# loader.c:104:         if (format != 0 || count > len/2) return -1;
	testw	%r8w, %r8w	# _538
	jne	.L581	#,
# loader.c:104:         if (format != 0 || count > len/2) return -1;
	cmpq	%rcx, 88(%rsp)	# _502, %sfp
	jb	.L581	#,
# loader.c:105:         for (unsigned e = 0; e < count; ++e) {
	testl	%ecx, %ecx	# count
	je	.L664	#,
# loader.c:109:             if (type > 1 || offset > sizes[target] || bytes > sizes[target]-offset) return -1;
	movq	80(%rsp), %rdi	# %sfp, tmp784
	movzwl	%dx, %edx	# _529, _491
# loader.c:56:     unsigned long source_base = (unsigned long)local_base[source];
	leaq	272(%rsp,%rax,8), %r8	#, _485
	leal	-1(%rcx), %eax	#, _293
# loader.c:109:             if (type > 1 || offset > sizes[target] || bytes > sizes[target]-offset) return -1;
	salq	$3, %rdx	#, _490
	leaq	(%rdi,%rdx), %rsi	#, _489
# loader.c:55:     void *target_addr = (uint8_t *)local_base[target] + patch_offset;
	leaq	272(%rsp,%rdx), %r9	#, _488
	movq	72(%rsp), %rdx	# %sfp, ivtmp.383
	leaq	10(%r15,%rax,2), %rdi	#, _213
	jmp	.L591	#
	.p2align 4,,10
	.p2align 3
.L588:
# loader.c:109:             if (type > 1 || offset > sizes[target] || bytes > sizes[target]-offset) return -1;
	ja	.L581	#,
	movl	$4, %r10d	#, bytes
.L594:
# loader.c:109:             if (type > 1 || offset > sizes[target] || bytes > sizes[target]-offset) return -1;
	movq	(%rsi), %r11	# *_489, _473
# loader.c:107:             size_t offset = v & 0xFFF; unsigned type = v >> 12;
	andl	$4095, %eax	#, offset
# loader.c:109:             if (type > 1 || offset > sizes[target] || bytes > sizes[target]-offset) return -1;
	cmpq	%rax, %r11	# offset, _473
	jb	.L581	#,
# loader.c:109:             if (type > 1 || offset > sizes[target] || bytes > sizes[target]-offset) return -1;
	subq	%rax, %r11	# offset, _472
# loader.c:109:             if (type > 1 || offset > sizes[target] || bytes > sizes[target]-offset) return -1;
	cmpq	%r10, %r11	# bytes, _472
	jb	.L581	#,
# loader.c:56:     unsigned long source_base = (unsigned long)local_base[source];
	movq	(%r8), %r10	# *_485, source_base
# loader.c:55:     void *target_addr = (uint8_t *)local_base[target] + patch_offset;
	addq	(%r9), %rax	# *_488, target_addr
# loader.c:57:     if (type == 1) { // ABS64
	cmpw	$1, %cx	#, _477
	je	.L685	#,
# loader.c:105:         for (unsigned e = 0; e < count; ++e) {
	addq	$2, %rdx	#, ivtmp.383
# loader.c:63:         uint32_t patched = (uint32_t)(source_base + addend);
	addl	%r10d, (%rax)	# source_base, MEM <unsigned int> [(char * {ref-all})target_addr_470]
# loader.c:105:         for (unsigned e = 0; e < count; ++e) {
	cmpq	%rdx, %rdi	# ivtmp.383, _213
	je	.L664	#,
.L591:
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movzwl	(%rdx), %eax	# MEM <unsigned short> [(char * {ref-all})_272], _479
# loader.c:107:             size_t offset = v & 0xFFF; unsigned type = v >> 12;
	movl	%eax, %ecx	# _479, _477
	shrw	$12, %cx	#, _477
# loader.c:108:             size_t bytes = type == 1 ? 8 : 4;
	cmpw	$1, %cx	#, _477
	jne	.L588	#,
# loader.c:108:             size_t bytes = type == 1 ? 8 : 4;
	movl	$8, %r10d	#, bytes
	jmp	.L594	#
	.p2align 4,,10
	.p2align 3
.L685:
# loader.c:105:         for (unsigned e = 0; e < count; ++e) {
	addq	$2, %rdx	#, ivtmp.383
# loader.c:59:         uint64_t patched = source_base + addend;
	addq	%r10, (%rax)	# source_base, MEM <unsigned long> [(char * {ref-all})target_addr_470]
# loader.c:105:         for (unsigned e = 0; e < count; ++e) {
	cmpq	%rdx, %rdi	# ivtmp.383, _213
	jne	.L591	#,
.L664:
# bench.c:6: static uint64_t now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000+t.tv_nsec;}
	movq	(%rsp), %rsi	# %sfp,
	movl	$1, %edi	#,
	call	clock_gettime@PLT	#
# bench.c:6: static uint64_t now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000+t.tv_nsec;}
	imulq	$1000000000, 256(%rsp), %rcx	#, MEM[(struct timespec *)_211].tv_sec, _781
# bench.c:6: static uint64_t now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000+t.tv_nsec;}
	addq	264(%rsp), %rcx	# MEM[(struct timespec *)_211].tv_nsec, _766
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	subq	%r13, %rcx	# _553, elapsed
	jmp	.L578	#
	.p2align 4,,10
	.p2align 3
.L583:
# loader.c:117:         case 1: return process_blocks32(rp,len,endian,count,base,target,source,sizes[target],trace);
	subq	$8, %rsp	#,
	.cfi_def_cfa_offset 392
# loader.c:117:         case 1: return process_blocks32(rp,len,endian,count,base,target,source,sizes[target],trace);
	movzwl	%dx, %edx	# _529, _514
# loader.c:117:         case 1: return process_blocks32(rp,len,endian,count,base,target,source,sizes[target],trace);
	pushq	$0	#
	.cfi_def_cfa_offset 400
	pushq	304(%rsp,%rdx,8)	# *_512
	.cfi_def_cfa_offset 408
	xorl	%edx, %edx	#
	pushq	%rax	# _526
	.cfi_def_cfa_offset 416
	movq	128(%rsp), %rsi	# %sfp,
	movq	104(%rsp), %rdi	# %sfp,
	leaq	304(%rsp), %r8	#,
	call	process_blocks32	#
	movl	%eax, 96(%rsp)	# rc, %sfp
	addq	$32, %rsp	#,
	.cfi_def_cfa_offset 384
	jmp	.L580	#
	.p2align 4,,10
	.p2align 3
.L584:
# loader.c:118:         case 2: return process_blocks64(rp,len,endian,count,base,target,source,sizes[target],trace);
	subq	$8, %rsp	#,
	.cfi_def_cfa_offset 392
# loader.c:118:         case 2: return process_blocks64(rp,len,endian,count,base,target,source,sizes[target],trace);
	movzwl	%dx, %edx	# _529, _520
# loader.c:118:         case 2: return process_blocks64(rp,len,endian,count,base,target,source,sizes[target],trace);
	pushq	$0	#
	.cfi_def_cfa_offset 400
	pushq	304(%rsp,%rdx,8)	# *_518
	.cfi_def_cfa_offset 408
	xorl	%edx, %edx	#
	pushq	%rax	# _526
	.cfi_def_cfa_offset 416
	movq	128(%rsp), %rsi	# %sfp,
	movq	104(%rsp), %rdi	# %sfp,
	leaq	304(%rsp), %r8	#,
	call	process_blocks64	#
	movl	%eax, 96(%rsp)	# rc, %sfp
	addq	$32, %rsp	#,
	.cfi_def_cfa_offset 384
	jmp	.L580	#
.L557:
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movq	104(%rsp), %rdi	# %sfp, p
	movb	$0, (%rdi)	#, *p_437
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movb	%ch, 1(%rdi)	# idx, MEM[(uint8_t *)p_437 + 1B]
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	cmpl	$2, 64(%rsp)	#, %sfp
	je	.L559	#,
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movq	%rcx, %rdx	# idx, _268
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movl	%eax, 4(%rdi)	# _619, MEM <unsigned int> [(uint8_t *)p_437 + 4B]
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	shrq	$16, %rdx	#, _268
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movb	%dl, 2(%rdi)	# _268, MEM[(uint8_t *)p_437 + 2B]
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movq	%rcx, %rdx	# idx, _671
	shrq	$24, %rdx	#, _671
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movb	%dl, 3(%rdi)	# _671, MEM[(uint8_t *)p_437 + 3B]
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	leaq	4(%rdi), %rdx	#, _43
.L560:
	movq	16(%rsp), %rax	# %sfp, _608
	addq	%rdx, %rax	# _43, p
	movq	%rax, 104(%rsp)	# p, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cmpl	120(%rsp), %r12d	# %sfp, j
	jle	.L562	#,
	movq	32(%rsp), %rdi	# %sfp, expected
	movq	%rax, %r14	# p, _626
	movq	40(%rsp), %rax	# %sfp, init
	movq	%rbp, 112(%rsp)	# len, %sfp
	movslq	120(%rsp), %rsi	# %sfp, ivtmp.431
	movl	%r12d, 124(%rsp)	# j, %sfp
	movq	%r13, %r12	# _2, _2
	leaq	(%rdi,%rbx), %r15	#, ivtmp.429
	movq	8(%rsp), %rdi	# %sfp, m
	leaq	(%rbx,%rax), %r10	#, ivtmp.428
	addq	%rcx, %rax	# idx, _332
	movq	%rax, 80(%rsp)	# _332, %sfp
	movq	%r10, %r13	# ivtmp.428, ivtmp.428
	movl	%r8d, 152(%rsp)	# n, %sfp
	leaq	1(%rdi,%rsi), %rbp	#, ivtmp.432
	movl	%r9d, 172(%rsp)	# stride, %sfp
	jmp	.L568	#
	.p2align 4,,10
	.p2align 3
.L686:
	movq	112(%rsp), %rax	# %sfp, len
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	addl	$1, %esi	#, tmp592
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movl	$4, %edx	#,
	movq	%r13, %rdi	# ivtmp.428,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	%esi, 240(%rsp)	# tmp592, aa
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	leaq	240(%rsp), %rsi	#, tmp594
	cmpq	%rbx, %rax	# ivtmp.426, len
	movq	%rax, %rcx	# len, _611
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	%ebp, 244(%rsp)	# ivtmp.432, vv
	cmovb	%rbx, %rcx	# _611,, ivtmp.426, _611
	subq	%rbx, %rcx	# ivtmp.426, _605
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movq	%rcx, 128(%rsp)	# _605, %sfp
	call	__memcpy_chk@PLT	#
	movq	128(%rsp), %rcx	# %sfp, _605
	movl	$4, %edx	#,
	leaq	244(%rsp), %rsi	#, tmp595
.L679:
	movq	%r15, %rdi	# ivtmp.429,
	call	__memcpy_chk@PLT	#
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	144(%rsp), %r8	# %sfp, _762
	cmpl	%r8d, 124(%rsp)	# _762, %sfp
	jle	.L566	#,
	addq	%r12, %rbx	# _2, ivtmp.426
	addq	%r12, %r13	# _2, ivtmp.428
	addq	%r12, %r15	# _2, ivtmp.429
	addq	$1, %rbp	#, ivtmp.432
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	addq	16(%rsp), %r14	# %sfp, _626
	movq	%r8, %rsi	# _762, ivtmp.431
.L568:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	%esi, %edx	# ivtmp.431, _649
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movzbl	88(%rsp), %ecx	# %sfp, tmp1009
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%r13, %rax	# ivtmp.428, _645
	subq	80(%rsp), %rax	# %sfp, _645
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	andl	$1, %edx	#, _649
	orl	96(%rsp), %edx	# %sfp, _648
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movslq	%edx, %rdi	# _648, _644
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	salq	%cl, %rdi	# tmp1009, _643
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	orq	%rdi, %rax	# _643, _642
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movq	%r14, %rdi	# _626, _626
	movb	%al, (%r14)	# _642, MEM[(uint8_t *)p_650]
	movb	%ah, 1(%rdi)	# _642, MEM[(uint8_t *)p_650 + 1B]
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	cmpl	$2, 64(%rsp)	#, %sfp
	je	.L564	#,
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movq	%rax, %rcx	# _642, _85
	shrq	$24, %rax	#, _636
	shrq	$16, %rcx	#, _85
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movb	%al, 3(%r14)	# _636, MEM[(uint8_t *)p_650 + 3B]
	movb	%cl, 2(%r14)	# _85, MEM[(uint8_t *)p_650 + 2B]
.L564:
	leaq	1(%rsi), %r8	#, _762
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%rbp, 256(%rsp)	# ivtmp.432, MEM[(long unsigned int *)_211]
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%r8, 248(%rsp)	# _762, a
	movq	%r8, 144(%rsp)	# _762, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	testl	%edx, %edx	# _648
	je	.L686	#,
	movq	112(%rsp), %rax	# %sfp, len
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movq	136(%rsp), %rsi	# %sfp,
	movl	$8, %edx	#,
	movq	%r13, %rdi	# ivtmp.428,
	cmpq	%rbx, %rax	# ivtmp.426, len
	movq	%rax, %rcx	# len, _577
	cmovb	%rbx, %rcx	# _577,, ivtmp.426, _577
	subq	%rbx, %rcx	# ivtmp.426, _576
	movq	%rcx, 128(%rsp)	# _576, %sfp
	call	__memcpy_chk@PLT	#
	movq	(%rsp), %rsi	# %sfp,
	movl	$8, %edx	#,
	movq	128(%rsp), %rcx	# %sfp, _576
	jmp	.L679	#
.L571:
	movl	172(%rsp), %r8d	# %sfp, n
	movl	192(%rsp), %r9d	# %sfp, stride
	jmp	.L677	#
.L559:
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movw	%ax, 2(%rdi)	# _619, MEM <unsigned short> [(uint8_t *)p_437 + 2B]
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	leaq	2(%rdi), %rdx	#, _43
	jmp	.L560	#
.L634:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	leaq	288(%rsp), %rax	#, tmp788
# loader.c:104:         if (format != 0 || count > len/2) return -1;
	movq	176(%rsp), %r15	# %sfp, table
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%rax, 80(%rsp)	# tmp788, %sfp
# loader.c:102:     rp += 8; len -= 8;
	movq	16(%rsp), %rax	# %sfp, _659
	subq	$8, %rax	#, len
	movq	%rax, 96(%rsp)	# len, %sfp
# loader.c:104:         if (format != 0 || count > len/2) return -1;
	shrq	%rax	# _296
	movq	%rax, 88(%rsp)	# _296, %sfp
	.p2align 4
	.p2align 3
.L575:
# loader.c:109:             if (type > 1 || offset > sizes[target] || bytes > sizes[target]-offset) return -1;
	movl	%r14d, %ebx	# rep, ivtmp.410
.L617:
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movq	40(%rsp), %rsi	# %sfp,
	movq	8(%rsp), %rdi	# %sfp,
	movq	%rbp, %rcx	# len,
	movq	%rbp, %rdx	# len,
	movl	%ebx, %r12d	# ivtmp.410, _378
	call	__memcpy_chk@PLT	#
# bench.c:6: static uint64_t now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000+t.tv_nsec;}
	movq	(%rsp), %rsi	# %sfp,
	movl	$1, %edi	#,
	andl	$1, %r12d	#, _378
	call	clock_gettime@PLT	#
# bench.c:6: static uint64_t now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000+t.tv_nsec;}
	imulq	$1000000000, 256(%rsp), %rax	#, MEM[(struct timespec *)_211].tv_sec, _225
# bench.c:6: static uint64_t now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000+t.tv_nsec;}
	addq	264(%rsp), %rax	# MEM[(struct timespec *)_211].tv_nsec, _225
	movq	%rax, %r13	# _225, _228
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	testl	%r12d, %r12d	# _378
	je	.L600	#,
# loader.c:97:     if (len < 8) return -1;
	cmpq	$7, 16(%rsp)	#, %sfp
	jbe	.L581	#,
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movzwl	4(%r15), %eax	# MEM <unsigned short> [(char * {ref-all})table_359 + 4B], pretmp_701
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	movl	%eax, %ecx	# pretmp_701, _276
	movzbl	%ah, %eax	# pretmp_701, _691
	rolw	$8, %cx	#, _276
	movl	%eax, %esi	# _691, _285
# loader.c:100:     int target = couple & 31, source = (couple >> 5) & 31;
	andl	$31, %eax	#, _691
# loader.c:100:     int target = couple & 31, source = (couple >> 5) & 31;
	shrl	$5, %ecx	#, _287
# loader.c:100:     int target = couple & 31, source = (couple >> 5) & 31;
	movl	%eax, %r9d	# _691, target
	andl	$31, %esi	#, _285
	andl	$31, %ecx	#,
# loader.c:101:     if (target >= n || source >= n) return -1;
	cmpl	%ecx, %eax	# _288, target
	movl	%ecx, %eax	# _288, _290
	cmovge	%r9d, %eax	# target,, _290
	cmpl	$1, %eax	#, _290
	jg	.L581	#,
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	movzwl	2(%r15), %eax	# MEM <unsigned short> [(char * {ref-all})table_359 + 2B], _269
	movzwl	6(%r15), %edx	# MEM <unsigned short> [(char * {ref-all})table_359 + 6B], _278
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movzwl	(%r15), %edi	# MEM <unsigned short> [(char * {ref-all})table_359], _264
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	rolw	$8, %dx	#, _279
	rolw	$8, %ax	#, _270
	movzwl	%dx, %r8d	# _279,
# loader.c:98:     unsigned format = rd16(rp, endian), design = rd16(rp+2, endian);
	movzwl	%ax, %eax	# _270, design
# loader.c:99:     unsigned couple = rd16(rp+4, endian), count = rd16(rp+6, endian);
	movzwl	%r8w, %edx	# _279, count
# loader.c:103:     if (design == 0) {
	testl	%eax, %eax	# design
	jne	.L601	#,
# loader.c:104:         if (format != 0 || count > len/2) return -1;
	testw	%di, %di	# _264
	jne	.L581	#,
# loader.c:104:         if (format != 0 || count > len/2) return -1;
	cmpq	%r8, 88(%rsp)	# _295, %sfp
	jb	.L581	#,
# loader.c:105:         for (unsigned e = 0; e < count; ++e) {
	testl	%edx, %edx	# count
	je	.L666	#,
# loader.c:109:             if (type > 1 || offset > sizes[target] || bytes > sizes[target]-offset) return -1;
	movq	80(%rsp), %rdi	# %sfp, tmp788
	movzwl	%si, %esi	# _285, _308
# loader.c:56:     unsigned long source_base = (unsigned long)local_base[source];
	leaq	272(%rsp,%rcx,8), %r8	#, _341
	movq	72(%rsp), %rcx	# %sfp, ivtmp.402
# loader.c:109:             if (type > 1 || offset > sizes[target] || bytes > sizes[target]-offset) return -1;
	leaq	0(,%rsi,8), %rax	#, _309
	leaq	(%rdi,%rax), %rsi	#, _310
# loader.c:55:     void *target_addr = (uint8_t *)local_base[target] + patch_offset;
	leaq	272(%rsp,%rax), %r9	#, _336
	leal	-1(%rdx), %eax	#, _679
	leaq	10(%r15,%rax,2), %rdi	#, _722
	jmp	.L606	#
	.p2align 4,,10
	.p2align 3
.L688:
# loader.c:109:             if (type > 1 || offset > sizes[target] || bytes > sizes[target]-offset) return -1;
	ja	.L581	#,
	movl	$4, %r10d	#, bytes
.L603:
# loader.c:43:     return (file_endian == UEEC_HOST_ENDIAN) ? v : __builtin_bswap16(v);
	rolw	$8, %ax	#, _303
# loader.c:109:             if (type > 1 || offset > sizes[target] || bytes > sizes[target]-offset) return -1;
	movq	(%rsi), %r11	# *_310, _311
# loader.c:107:             size_t offset = v & 0xFFF; unsigned type = v >> 12;
	andl	$4095, %eax	#, offset
# loader.c:109:             if (type > 1 || offset > sizes[target] || bytes > sizes[target]-offset) return -1;
	cmpq	%rax, %r11	# offset, _311
	jb	.L581	#,
# loader.c:109:             if (type > 1 || offset > sizes[target] || bytes > sizes[target]-offset) return -1;
	subq	%rax, %r11	# offset, _312
# loader.c:109:             if (type > 1 || offset > sizes[target] || bytes > sizes[target]-offset) return -1;
	cmpq	%r10, %r11	# bytes, _312
	jb	.L581	#,
# loader.c:56:     unsigned long source_base = (unsigned long)local_base[source];
	movq	(%r8), %r10	# *_341, source_base
# loader.c:55:     void *target_addr = (uint8_t *)local_base[target] + patch_offset;
	addq	(%r9), %rax	# *_336, target_addr
# loader.c:57:     if (type == 1) { // ABS64
	cmpw	$1, %dx	#, _307
	je	.L687	#,
# loader.c:105:         for (unsigned e = 0; e < count; ++e) {
	addq	$2, %rcx	#, ivtmp.402
# loader.c:63:         uint32_t patched = (uint32_t)(source_base + addend);
	addl	%r10d, (%rax)	# source_base, MEM <unsigned int> [(char * {ref-all})target_addr_338]
# loader.c:105:         for (unsigned e = 0; e < count; ++e) {
	cmpq	%rdi, %rcx	# _722, ivtmp.402
	je	.L666	#,
.L606:
# /usr/include/x86_64-linux-gnu/bits/string_fortified.h:29:   return __builtin___memcpy_chk (__dest, __src, __len,
	movzwl	(%rcx), %eax	# MEM <unsigned short> [(char * {ref-all})_652], _301
# loader.c:107:             size_t offset = v & 0xFFF; unsigned type = v >> 12;
	movl	%eax, %edx	# _301, _673
	shrb	$4, %dl	#, _673
	movzbl	%dl, %edx	# _673, _307
# loader.c:108:             size_t bytes = type == 1 ? 8 : 4;
	cmpw	$1, %dx	#, _307
	jne	.L688	#,
# loader.c:108:             size_t bytes = type == 1 ? 8 : 4;
	movl	$8, %r10d	#, bytes
	jmp	.L603	#
	.p2align 4,,10
	.p2align 3
.L687:
# loader.c:105:         for (unsigned e = 0; e < count; ++e) {
	addq	$2, %rcx	#, ivtmp.402
# loader.c:59:         uint64_t patched = source_base + addend;
	addq	%r10, (%rax)	# source_base, MEM <unsigned long> [(char * {ref-all})target_addr_338]
# loader.c:105:         for (unsigned e = 0; e < count; ++e) {
	cmpq	%rdi, %rcx	# _722, ivtmp.402
	jne	.L606	#,
.L666:
# bench.c:6: static uint64_t now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000+t.tv_nsec;}
	movq	(%rsp), %rsi	# %sfp,
	movl	$1, %edi	#,
	call	clock_gettime@PLT	#
# bench.c:6: static uint64_t now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000+t.tv_nsec;}
	imulq	$1000000000, 256(%rsp), %rcx	#, MEM[(struct timespec *)_211].tv_sec, _699
# bench.c:6: static uint64_t now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000+t.tv_nsec;}
	addq	264(%rsp), %rcx	# MEM[(struct timespec *)_211].tv_nsec, _439
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	subq	%r13, %rcx	# _228, elapsed
	jmp	.L612	#
	.p2align 4,,10
	.p2align 3
.L600:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	80(%rsp), %r8	# %sfp,
	movq	16(%rsp), %rsi	# %sfp,
	movl	$1, %edx	#,
	movq	%r15, %rdi	# table,
	leaq	272(%rsp), %rcx	#, tmp716
	call	generic.constprop.0	#
	movl	%eax, 64(%rsp)	# rc, %sfp
.L611:
# bench.c:6: static uint64_t now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000+t.tv_nsec;}
	movq	(%rsp), %rsi	# %sfp,
	movl	$1, %edi	#,
	call	clock_gettime@PLT	#
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	64(%rsp), %eax	# %sfp,
# bench.c:6: static uint64_t now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000+t.tv_nsec;}
	imulq	$1000000000, 256(%rsp), %rcx	#, MEM[(struct timespec *)_211].tv_sec, _231
# bench.c:6: static uint64_t now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000+t.tv_nsec;}
	addq	264(%rsp), %rcx	# MEM[(struct timespec *)_211].tv_nsec, _234
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	subq	%r13, %rcx	# _228, elapsed
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	testl	%eax, %eax	#
	jne	.L613	#,
.L612:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	32(%rsp), %rsi	# %sfp,
	movq	8(%rsp), %rdi	# %sfp,
	movq	%rbp, %rdx	# len,
	movq	%rcx, 64(%rsp)	# elapsed, %sfp
	call	memcmp@PLT	#
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	testl	%eax, %eax	# tmp816
	jne	.L613	#,
	movq	64(%rsp), %rcx	# %sfp, elapsed
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	testq	%rcx, %rcx	# elapsed
	js	.L615	#,
	pxor	%xmm0, %xmm0	# _52
	cvtsi2sdq	%rcx, %xmm0	# elapsed, _52
.L616:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	48(%rsp), %edx	# %sfp, n
	pxor	%xmm1, %xmm1	# _53
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:118:   return __printf_chk (__USE_FORTIFY_LEVEL - 1, __fmt, __va_arg_pack ());
	subq	$8, %rsp	#,
	.cfi_def_cfa_offset 392
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	addl	$1, %ebx	#, ivtmp.410
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:118:   return __printf_chk (__USE_FORTIFY_LEVEL - 1, __fmt, __va_arg_pack ());
	pushq	24(%rsp)	# %sfp
	.cfi_def_cfa_offset 400
	leaq	.LC20(%rip), %rsi	#,
	movl	$2, %edi	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cvtsi2sdl	%edx, %xmm1	# n, _53
	divsd	%xmm1, %xmm0	# _53, _54
# /usr/include/x86_64-linux-gnu/bits/stdio2.h:118:   return __printf_chk (__USE_FORTIFY_LEVEL - 1, __fmt, __va_arg_pack ());
	pushq	%r12	# _378
	.cfi_def_cfa_offset 408
	pushq	%r14	# rep
	.cfi_def_cfa_offset 416
	movl	88(%rsp), %eax	# %sfp, mix
	pushq	%rax	# mix
	.cfi_def_cfa_offset 424
	movl	$1, %eax	#,
	pushq	$1	#
	.cfi_def_cfa_offset 432
	movl	108(%rsp), %r9d	# %sfp,
	movl	76(%rsp), %r8d	# %sfp,
	movl	100(%rsp), %ecx	# %sfp,
	call	__printf_chk@PLT	#
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	leal	2(%r14), %eax	#, _274
	addq	$48, %rsp	#,
	.cfi_def_cfa_offset 384
	cmpl	%ebx, %eax	# ivtmp.410, _274
	jne	.L617	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	addl	$1, %r14d	#, rep
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cmpl	$101, %r14d	#, rep
	jne	.L575	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	176(%rsp), %rdi	# %sfp,
	call	free@PLT	#
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	8(%rsp), %rdi	# %sfp,
	call	free@PLT	#
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	40(%rsp), %rdi	# %sfp,
	call	free@PLT	#
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	32(%rsp), %rdi	# %sfp,
	call	free@PLT	#
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cmpl	$1, 56(%rsp)	#, %sfp
	jne	.L619	#,
	movl	236(%rsp), %ebx	# %sfp, _5
	movl	200(%rsp), %r13d	# %sfp, _561
	movl	204(%rsp), %r12d	# %sfp, ivtmp_618
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cmpl	$512, 28(%rsp)	#, %sfp
	je	.L689	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	sall	$2, 28(%rsp)	#, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cmpl	$16384, 28(%rsp)	#, %sfp
	jle	.L624	#,
	movl	%r12d, %r14d	# ivtmp_618, ivtmp_618
	movl	%r13d, %r12d	# _561, _561
	movl	232(%rsp), %r13d	# %sfp, ivtmp_60
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	sall	$3, 52(%rsp)	#, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	subl	$1, %r13d	#, ivtmp_60
	jne	.L626	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	sall	$2, 48(%rsp)	#, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	subl	$1, %r14d	#, ivtmp_618
	jne	.L544	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	312(%rsp), %rax	# D.6340, tmp821
	subq	%fs:40, %rax	# MEM[(<address-space-1> long unsigned int *)40B], tmp821
	jne	.L690	#,
	addq	$328, %rsp	#,
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	xorl	%eax, %eax	#
	popq	%rbx	#
	.cfi_def_cfa_offset 48
	popq	%rbp	#
	.cfi_def_cfa_offset 40
	popq	%r12	#
	.cfi_def_cfa_offset 32
	popq	%r13	#
	.cfi_def_cfa_offset 24
	popq	%r14	#
	.cfi_def_cfa_offset 16
	popq	%r15	#
	.cfi_def_cfa_offset 8
	ret	
	.p2align 4,,10
	.p2align 3
.L615:
	.cfi_restore_state
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%rcx, %rax	# elapsed, tmp728
	andl	$1, %ecx	#, tmp729
	pxor	%xmm0, %xmm0	# tmp727
	shrq	%rax	# tmp728
	orq	%rcx, %rax	# tmp729, tmp728
	cvtsi2sdq	%rax, %xmm0	# tmp728, tmp727
	addsd	%xmm0, %xmm0	# tmp727, _52
	jmp	.L616	#
	.p2align 4,,10
	.p2align 3
.L601:
# loader.c:114:     if (design != 1 && design != 2) return -1;
	subl	$1, %eax	#, _316
# loader.c:114:     if (design != 1 && design != 2) return -1;
	cmpl	$1, %eax	#, _316
	ja	.L581	#,
# loader.c:115:     switch (format) {
	cmpw	$256, %di	#, _264
	je	.L608	#,
	cmpw	$512, %di	#, _264
	je	.L609	#,
	testw	%di, %di	# _264
	jne	.L610	#,
# loader.c:116:         case 0: return process_blocks16(rp,len,endian,count,base,target,source,sizes[target],trace);
	subq	$8, %rsp	#,
	.cfi_def_cfa_offset 392
# loader.c:116:         case 0: return process_blocks16(rp,len,endian,count,base,target,source,sizes[target],trace);
	movzwl	%si, %esi	# _285, _317
# loader.c:116:         case 0: return process_blocks16(rp,len,endian,count,base,target,source,sizes[target],trace);
	pushq	$0	#
	.cfi_def_cfa_offset 400
	pushq	304(%rsp,%rsi,8)	# *_319
	.cfi_def_cfa_offset 408
	pushq	%rcx	# _288
	.cfi_def_cfa_offset 416
	movl	%edx, %ecx	# count,
	movl	$1, %edx	#,
	movq	128(%rsp), %rsi	# %sfp,
	movq	104(%rsp), %rdi	# %sfp,
	leaq	304(%rsp), %r8	#,
	call	process_blocks16	#
	movl	%eax, 96(%rsp)	# rc, %sfp
	addq	$32, %rsp	#,
	.cfi_def_cfa_offset 384
	jmp	.L611	#
	.p2align 4,,10
	.p2align 3
.L609:
# loader.c:118:         case 2: return process_blocks64(rp,len,endian,count,base,target,source,sizes[target],trace);
	subq	$8, %rsp	#,
	.cfi_def_cfa_offset 392
# loader.c:118:         case 2: return process_blocks64(rp,len,endian,count,base,target,source,sizes[target],trace);
	movzwl	%si, %esi	# _285, _327
# loader.c:118:         case 2: return process_blocks64(rp,len,endian,count,base,target,source,sizes[target],trace);
	pushq	$0	#
	.cfi_def_cfa_offset 400
	pushq	304(%rsp,%rsi,8)	# *_329
	.cfi_def_cfa_offset 408
	pushq	%rcx	# _288
	.cfi_def_cfa_offset 416
	movl	%edx, %ecx	# count,
	movl	$1, %edx	#,
	movq	128(%rsp), %rsi	# %sfp,
	movq	104(%rsp), %rdi	# %sfp,
	leaq	304(%rsp), %r8	#,
	call	process_blocks64	#
	movl	%eax, 96(%rsp)	# rc, %sfp
	addq	$32, %rsp	#,
	.cfi_def_cfa_offset 384
	jmp	.L611	#
	.p2align 4,,10
	.p2align 3
.L608:
# loader.c:117:         case 1: return process_blocks32(rp,len,endian,count,base,target,source,sizes[target],trace);
	subq	$8, %rsp	#,
	.cfi_def_cfa_offset 392
# loader.c:117:         case 1: return process_blocks32(rp,len,endian,count,base,target,source,sizes[target],trace);
	movzwl	%si, %esi	# _285, _322
# loader.c:117:         case 1: return process_blocks32(rp,len,endian,count,base,target,source,sizes[target],trace);
	pushq	$0	#
	.cfi_def_cfa_offset 400
	pushq	304(%rsp,%rsi,8)	# *_324
	.cfi_def_cfa_offset 408
	pushq	%rcx	# _288
	.cfi_def_cfa_offset 416
	movl	%edx, %ecx	# count,
	movl	$1, %edx	#,
	movq	128(%rsp), %rsi	# %sfp,
	movq	104(%rsp), %rdi	# %sfp,
	leaq	304(%rsp), %r8	#,
	call	process_blocks32	#
	movl	%eax, 96(%rsp)	# rc, %sfp
	addq	$32, %rsp	#,
	.cfi_def_cfa_offset 384
	jmp	.L611	#
.L619:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	48(%rsp), %r9d	# %sfp, n
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	$1, 56(%rsp)	#, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	testl	%r9d, %r9d	# n
	jg	.L691	#,
.L545:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movzbl	199(%rsp), %ecx	# %sfp, _10
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	184(%rsp), %rdi	# %sfp,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	$2, %eax	#, tmp754
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	xorl	%ebx, %ebx	# _588
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	$24, %esi	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	sall	%cl, %eax	# _10, tmp754
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	%ecx, %r14d	# _10, _158
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	%eax, 64(%rsp)	# tmp754, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	call	calloc@PLT	#
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%rbp, %rsi	# len,
	movl	$1, %edi	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%rax, 176(%rsp)	# table, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	call	calloc@PLT	#
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%rbp, %rsi	# len,
	movl	$1, %edi	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%rax, 8(%rsp)	# m, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	call	calloc@PLT	#
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%rbp, %rsi	# len,
	movl	$1, %edi	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	%rax, 40(%rsp)	# init, %sfp
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	call	calloc@PLT	#
	xorl	%r10d, %r10d	# _584
	movq	%rax, 32(%rsp)	# expected, %sfp
	jmp	.L627	#
.L684:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	176(%rsp), %rdi	# %sfp,
	call	free@PLT	#
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	8(%rsp), %rdi	# %sfp,
	call	free@PLT	#
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	40(%rsp), %rdi	# %sfp,
	call	free@PLT	#
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	32(%rsp), %rdi	# %sfp,
	call	free@PLT	#
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	cmpl	$1, 56(%rsp)	#, %sfp
	jne	.L619	#,
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	200(%rsp), %r13d	# %sfp, _561
	movl	204(%rsp), %r12d	# %sfp, ivtmp_618
	movl	$1, 168(%rsp)	#, %sfp
	jmp	.L622	#
.L549:
# bench.c:7: static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
	movb	%r14b, 1(%rax)	# _158, MEM[(uint8_t *)table_359 + 1B]
	movq	%rax, %r9	# table, _603
	movl	$2, %edi	#, prephitmp_601
	movl	$3, %r8d	#, prephitmp_599
	movl	$4, %ecx	#, prephitmp_597
	movl	$5, %esi	#, prephitmp_595
	movl	$6, %eax	#, prephitmp_593
	movl	$7, %edx	#, prephitmp_591
	jmp	.L550	#
.L633:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	$1, %eax	#, _619
	jmp	.L552	#
.L632:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movq	$8, 16(%rsp)	#, %sfp
	jmp	.L551	#
.L689:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	movl	$4096, 28(%rsp)	#, %sfp
	jmp	.L624	#
.L690:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	call	__stack_chk_fail@PLT	#
.L683:
	jmp	.L613	#
	.cfi_endproc
	.section	.text.unlikely
	.cfi_startproc
	.type	main.cold, @function
main.cold:
.LFSB67:
.L661:
	.cfi_def_cfa_offset 384
	.cfi_offset 3, -56
	.cfi_offset 6, -48
	.cfi_offset 12, -40
	.cfi_offset 13, -32
	.cfi_offset 14, -24
	.cfi_offset 15, -16
# bench.c:6: static uint64_t now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000+t.tv_nsec;}
	movq	(%rsp), %rsi	# %sfp,
	movl	$1, %edi	#,
	call	clock_gettime@PLT	#
.L613:
# bench.c:11: int main(void){puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?process_reloc_section(table,z,en,base,sizes,2,0):generic(table,z,en,base,sizes,2,0);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx	#,
	movl	$11, %edx	#,
	leaq	.LC21(%rip), %rsi	#,
	leaq	.LC22(%rip), %rdi	#,
	call	__assert_fail@PLT	#
.L581:
# bench.c:6: static uint64_t now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000+t.tv_nsec;}
	movq	(%rsp), %rsi	# %sfp,
	movl	$1, %edi	#,
	call	clock_gettime@PLT	#
	jmp	.L613	#
.L610:
	movq	(%rsp), %rsi	# %sfp,
	movl	$1, %edi	#,
	call	clock_gettime@PLT	#
	jmp	.L613	#
	.cfi_endproc
.LFE67:
	.section	.text.startup
	.size	main, .-main
	.section	.text.unlikely
	.size	main.cold, .-main.cold
.LCOLDE23:
	.section	.text.startup
.LHOTE23:
	.section	.rodata
	.type	__PRETTY_FUNCTION__.0, @object
	.size	__PRETTY_FUNCTION__.0, 5
__PRETTY_FUNCTION__.0:
	.string	"main"
	.ident	"GCC: (Ubuntu 15.2.0-16ubuntu1) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
	.section	.note.gnu.property,"a"
	.align 8
	.long	1f - 0f
	.long	4f - 1f
	.long	5
0:
	.string	"GNU"
1:
	.align 8
	.long	0xc0000002
	.long	3f - 2f
2:
	.long	0x3
3:
	.align 8
4:
