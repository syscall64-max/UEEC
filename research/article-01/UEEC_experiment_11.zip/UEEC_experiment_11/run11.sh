#!/bin/bash
set -euo pipefail

mkdir -p runs

for run in $(seq -w 1 20); do
    phase=$((10#$run % 2))

    if [ "$phase" -eq 0 ]; then
        levels=(2 3)
    else
        levels=(3 2)
    fi

    for o in "${levels[@]}"; do
        file="runs/O${o}_run${run}.csv"

        echo "Run $run/20 | O$o | phase=$phase"

        taskset -c 5 "./bench11_O$o" "$phase" \
            > "$file"

        lines=$(wc -l < "$file")

        if [ "$lines" -ne 29089 ]; then
            echo "ERROR: unexpected row count: $lines"
            exit 1
        fi

        echo "PASS: $lines lines"
    done
done

echo "ALL 40 RUNS COMPLETED"
