
#define main loader_main_v1
#include "loader_v1.c"
#undef main

int run_v1(
    const uint8_t *table,
    size_t len,
    unsigned endian,
    void **base,
    const size_t *sizes
) {
    return process_reloc_section(
        table, len, endian, base, sizes, 2, 0
    );
}
