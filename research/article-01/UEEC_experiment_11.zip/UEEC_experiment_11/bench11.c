
#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int run_v1(const uint8_t *, size_t, unsigned,
           void **, const size_t *);

int run_v3(const uint8_t *, size_t, unsigned,
           void **, const size_t *);

#include <assert.h>
#include <time.h>
static uint64_t now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000+t.tv_nsec;}
static void put(uint8_t **p,uint64_t v,int w,int endian){for(int i=0;i<w;i++)(*p)[endian?w-1-i:i]=(uint8_t)(v>>(8*i));*p+=w;}
int main(int argc,char **argv){int phase=argc>1?atoi(argv[1]):0;puts("count,stride,page,width,endian,mixed,repeat,variant,bytes,ns_per_reloc");for(int n=16;n<=1024;n*=4)for(int stride=8;stride<=512;stride*=8)for(int page=512;page<=16384;page*= (page==512?8:4))for(int en=0;en<2;en++)for(int mix=0;mix<2;mix++){size_t len=(size_t)n*stride+8;unsigned fmt=0;uint64_t maxbase=((n-1)*stride/page)*page;unsigned maxdelta=0;for(int i=0;i<n;i++){unsigned d=(i*stride)%page;if(d>maxdelta)maxdelta=d;}if(maxbase>65535||maxdelta>4095)fmt=1;int w=2<<fmt;uint8_t *table=calloc(n,24),*p=table,*m=calloc(1,len),*init=calloc(1,len),*expected=calloc(1,len);void *base[]={m,m};size_t sizes[]={len,len};unsigned blocks=0;for(int i=0;i<n;i++)if(i==0||i*stride/page!=(i-1)*stride/page)blocks++;put(&p,fmt,2,en);put(&p,page==4096?1:2,2,en);put(&p,32,2,en);put(&p,blocks,2,en);for(int i=0;i<n;){int j=i+1;uint64_t idx=(i*stride/page)*page;while(j<n&&(uint64_t)(j*stride/page)*page==idx)j++;put(&p,idx,w,en);put(&p,j-i,w,en);for(;i<j;i++){unsigned type=!mix||i%2;size_t off=i*stride;put(&p,(off-idx)|((uint64_t)type<<(8*w-4)),w,en);uint64_t a=i+1,v=(uintptr_t)m+a; if(type){memcpy(init+off,&a,8);memcpy(expected+off,&v,8);}else{uint32_t aa=a,vv=v;memcpy(init+off,&aa,4);memcpy(expected+off,&vv,4);}}}size_t z=p-table;for(int rep=0;rep<=100;rep++)for(int k=0;k<2;k++){int opt=(rep+k+phase)%2;memcpy(m,init,len);uint64_t t=now();int rc=opt?run_v3(table,z,en,base,sizes):run_v1(table,z,en,base,sizes);uint64_t elapsed=now()-t;assert(rc==0&&!memcmp(m,expected,len));printf("%d,%d,%d,%d,%d,%d,%d,%d,%zu,%.4f\n",n,stride,page,w*8,en,mix,rep,opt,z,(double)elapsed/n);}free(table);free(m);free(init);free(expected);}return 0;}
