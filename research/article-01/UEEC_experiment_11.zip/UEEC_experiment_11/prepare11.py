from pathlib import Path

for version in ('v1', 'v3'):
    wrapper = f'''
#define main loader_main_{version}
#include "loader_{version}.c"
#undef main

int run_{version}(
    const uint8_t *table,
    size_t len,
    unsigned endian,
    void **base,
    const size_t *sizes
) {{
    return process_reloc_section(
        table, len, endian, base, sizes, 2, 0
    );
}}
'''
    Path(f'wrapper_{version}.c').write_text(wrapper)

s = Path('bench.c').read_text()

start = s.index('#include <assert.h>')
end = s.index('static uint64_t readw')
main = s.index('int main(void)')

headers = '''
#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int run_v1(const uint8_t *, size_t, unsigned,
           void **, const size_t *);

int run_v3(const uint8_t *, size_t, unsigned,
           void **, const size_t *);

'''

s = headers + s[start:end] + s[main:]

old = (
    'int rc=opt?'
    'process_reloc_section(table,z,en,base,sizes,2,0)'
    ':generic(table,z,en,base,sizes,2,0);'
)

new = (
    'int rc=opt?'
    'run_v3(table,z,en,base,sizes)'
    ':run_v1(table,z,en,base,sizes);'
)

assert s.count(old) == 1
s = s.replace(old, new)

# Alternate the initial variant between independent runs.
s = s.replace(
    'int main(void){',
    'int main(int argc,char **argv){'
    'int phase=argc>1?atoi(argv[1]):0;'
)

s = s.replace(
    'int opt=(rep+k)%2;',
    'int opt=(rep+k+phase)%2;'
)

Path('bench11.c').write_text(s)

print('Generated wrapper_v1.c')
print('Generated wrapper_v3.c')
print('Generated bench11.c')
