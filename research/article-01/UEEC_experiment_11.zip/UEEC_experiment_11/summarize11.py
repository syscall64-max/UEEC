from pathlib import Path
import pandas as pd

keys = [
    'count', 'stride', 'page',
    'width', 'endian', 'mixed'
]

results = []

for f in sorted(Path('runs').glob('*.csv')):
    x = pd.read_csv(f)
    x = x[x.repeat > 0]

    p = x.groupby(
        keys + ['variant']
    ).ns_per_reloc.median().unstack()

    p.columns = ['V1_ns', 'V3_ns']
    p['speedup'] = p.V1_ns / p.V3_ns

    p = p.reset_index()
    p['optimization'] = f.stem.split('_')[0]
    p['run'] = int(f.stem.split('run')[1])

    results.append(p)

data = pd.concat(results, ignore_index=True)
data.to_csv('process_results.csv', index=False)

runs = data.groupby(
    ['optimization', 'run']
).speedup.agg(
    minimum='min',
    median='median',
    maximum='max'
).reset_index()

runs.to_csv('process_summary.csv', index=False)

print('=== INDEPENDENT PROCESS RESULTS ===')
print(runs.to_string(index=False))

print('\n=== OVERALL STATISTICS ===')

for opt, group in runs.groupby('optimization'):
    s = group['median']

    print('\nOptimization:', opt)
    print('Independent processes:', len(s))
    print('Minimum:', s.min())
    print('Median:', s.median())
    print('Maximum:', s.max())
    print('Standard deviation:', s.std())
    print('Q1:', s.quantile(0.25))
    print('Q3:', s.quantile(0.75))
    print('Faster processes:', (s > 1).sum())

configs = data.groupby(
    ['optimization'] + keys
).speedup.agg(
    minimum='min',
    median='median',
    maximum='max',
    std='std'
).reset_index()

configs.to_csv('configuration_summary.csv', index=False)

print('\n=== CONFIGURATION STATISTICS ===')

for opt, group in configs.groupby('optimization'):
    print('\nOptimization:', opt)
    print('Configurations:', len(group))
    print('Faster configurations:',
          (group['median'] > 1).sum())
    print('Median speedup:', group['median'].median())

    for key in ['width', 'endian', 'mixed', 'page']:
        print('\nGrouped by:', key)
        print(group.groupby(key)['median'].agg(
            ['count', 'min', 'median', 'max']
        ).to_string())
